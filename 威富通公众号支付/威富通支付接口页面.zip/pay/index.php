<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>微信支付</title>
    <link href="css/pay.css" rel="stylesheet" type="text/css"/>
    <link href="css/sprite.css" rel="stylesheet" type="text/css"/>
    <script type="text/javascript" src="js/jquery-2.1.0.min.js"></script>
    <script type="text/javascript" src="js/pay.js"></script>
    	<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1, user-scalable=no">
		<meta name="apple-mobile-web-app-capable" content="yes">
</head>
<style>
	
</style>
<body>
	<header class="header">
		在线付款
	</header>
<div id="pay_platform">
 <div class="form_wrap" id="orderInfo">
      <input name="out_trade_no" value="<?php echo time().rand(); ?>" type="hidden">
       	<div style="margin:20px;">
       	  <input name="total_fee" type="radio" value="0.01">金额10元
          <input name="total_fee" type="radio" value="20">金额20元	
       	</div>
        <div class="form_list">
            <span class="list_val submit btn btn_blue">确定</span>
        </div>
    </div>
    </div>
</body>
</html>