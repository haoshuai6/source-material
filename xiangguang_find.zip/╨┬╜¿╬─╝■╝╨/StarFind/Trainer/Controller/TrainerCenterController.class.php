<?php
namespace Trainer\Controller;

use Common\BaseClass\Error;
use Common\BaseClass\StarfindController;
use Common\BaseClass\OrderStatus;

class TrainerCenterController extends StarfindController
{
	//个人中心
	public function trainerHome(){

		//网站公告
		$newsList = D('Article')->select(array('article_class_id'=>D('ArticleClass')->getArticleClassInfo('TRAINER_NEWS')));

		//机构资料
		$trainerInfo = D('Trainer')->thinkfind(session($this->Config("SESSION_TRAINER_ID")));

		$trainer_type = intval(session($this->Config("SESSION_TRAINER_TYPE")));
		$tplArray = array('newsList'=>$newsList,'trainerInfo'=>$trainerInfo,'trainer_type'=>$trainer_type);
		$this->assign($tplArray);

		$this->display();
	}

	//资料修改
	public function trainerInfo(){
		$trainerInfo = D('Trainer')->thinkfind(session($this->Config("SESSION_TRAINER_ID")));
		$this->assign('trainerInfo',$trainerInfo);
		$this->display();
	}

	public function ajaxUpdateTrainer(){
		$error = new Error();

		if(IS_POST){
			$update_array = array();
			$update_array['avator'] = I('post.avator','','trim');
			$update_array['demo'] = I('post.demo','','trim');
			$update_array['service_phone'] = I('post.service_phone','','trim');
			$update_array['id'] = session($this->Config("SESSION_TRAINER_ID"));

			D('Trainer')->save($update_array);

			$error->setError(0, "资料修改成功",$update_array);
		}else{
			$trainerInfo = D('Trainer')->thinkfind(session($this->Config("SESSION_TRAINER_ID")));
			$error->setError(101, "服务当前不可用，请稍后再试",$trainerInfo);
		}

		$this->ajaxReturn($error->getResult());
	}

	//订单管理
	public function trainerOrder(){
		$status = I('get.status','all','trim');

		$orderStatus = new OrderStatus($this->getConfig());

		$map = array();
		$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));

		switch($status){
			case 'waitpay':
				$map['state_order'] = 10;
				$map['state_verify'] = 2;
				break;
			case 'waitconfirm':
				$map['state_order'] = 15;
				$map['payment_string'] = 'OFFLINE';
				break;
			case 'refund':
				break;
		}

		$page_num = $this->Config("PAGE_LIST_NUM");

		$orderList = D('Order')->where($map)->field('id,sn_order,state_order,trainer_id,title_trainer,buyer_id,buyer_name,buyer_mobile,amount_lesson,amount_order,state_verify,payment_string,state_lock,createtime')->limit('0,'.$page_num)->select();

		if(!empty($orderList) && is_array($orderList)){
			foreach($orderList as $k=>$order){
				//判断订单状态
				$orderList[$k]['state_option'] = $orderStatus->getTrainerOperate(array('state_order'=>$order['state_order'],'payment_string'=>$order['payment_string'],'state_verify'=>$order['state_verify'],'state_lock'=>$order['state_lock'],'state_delete'=>$order['state_delete'],'state_refund'=>$order['state_refund'],'state_evaluation'=>$order['state_evaluation']));

				$orderList[$k]['order_lesson'] = D('OrderLesson')->where(array('order_id'=>$order['id']))->field('id,order_id,lesson_id,buy_numbers,title,image,price,lesson_nums')->select();
			}
		}

		$this->assign('status',$status);
		$this->assign('orderList',$orderList);
		$this->display();
	}

	//ajax线下付款确认订单
	public function ajaxConfirmOrder(){
		$order_id = I('get.order_id',0,'intval');
		$state_verify = I('get.state_verify',0,'intval');
		$error = new Error();

		if($order_id > 0){
			$trainer_id = intval(session($this->Config("SESSION_TRAINER_ID")));
			$orderInfo = D('Order')->getOrder($order_id);
			if($orderInfo['trainer_id'] == $trainer_id){
				$update_array = array();
				$update_array['id'] = $order_id;
				$update_array['state_verify'] = $state_verify;

				if($state_verify == 2){
					$update_array['state_order'] = 0;
				}

				D('Order')->save($update_array);

				$error->setError(0, "操作成功");
			}else{
				$error->setError(101, "数据错误");
			}
		}else{
			$error->setError(101, "数据错误");
		}
		$this->ajaxReturn($error->getResult());
	}

	//ajax审核订单
	public function ajaxVerifyOrder(){
		$order_id = I('get.order_id',0,'intval');
		$state_verify = I('get.state_verify',0,'intval');
		$error = new Error();

		if($order_id > 0){
			$trainer_id = intval(session($this->Config("SESSION_TRAINER_ID")));
			$orderInfo = D('Order')->getOrder($order_id);
			if($orderInfo['trainer_id'] == $trainer_id){
				$update_array = array();
				$update_array['id'] = $order_id;
				$update_array['state_verify'] = $state_verify;

				if($state_verify == 2){
					$update_array['state_order'] = 0;
				}

				D('Order')->save($update_array);

				$error->setError(0, "操作成功");
			}else{
				$error->setError(101, "数据错误");
			}
		}else{
			$error->setError(101, "数据错误");
		}
		$this->ajaxReturn($error->getResult());
	}

	//ajax加载订单
	public function ajaxTrainerOrder(){
		$orderStatus = new OrderStatus($this->getConfig());
		$error = new Error();

		if(IS_GET){
			$page_num = $this->Config("PAGE_LIST_NUM");
			$page = I('get.page');
			$start_num = intval($page)*$page_num;

			$map = array();
			$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));

			$status = I('get.status','all','trim');
			switch($status){
				case 'waitpay':
					$map['state_order'] = 10;
					$map['state_verify'] = 2;
					break;
				case 'waitconfirm':
					$map['state_order'] = 15;
					$map['payment_string'] = 'OFFLINE';
					break;
				case 'refund':
					break;
			}

			$orderList = D('Order')->where($map)->field('id,sn_order,state_order,trainer_id,title_trainer,buyer_id,buyer_name,buyer_mobile,amount_lesson,amount_order,state_verify,payment_string,state_lock,createtime')->limit($start_num.','.$page_num)->select();

			if(!empty($orderList) && is_array($orderList)){
				foreach($orderList as $k=>$order){
					//判断订单状态
					$orderList[$k]['state_option'] = $orderStatus->getTrainerOperate(array('state_order'=>$order['state_order'],'payment_string'=>$order['payment_string'],'state_verify'=>$order['state_verify'],'state_lock'=>$order['state_lock'],'state_delete'=>$order['state_delete'],'state_refund'=>$order['state_refund'],'state_evaluation'=>$order['state_evaluation']));

					$orderList[$k]['order_lesson'] = D('OrderLesson')->where(array('order_id'=>$order['id']))->field('id,order_id,lesson_id,buy_numbers,title,image,price,lesson_nums')->select();
				}
			}

			$error->setError(0, "加载成功",$orderList);
		}

		$this->ajaxReturn($error->getResult());
	}

	//评价管理
	public function trainerEvaluation(){
		$page_num = $this->Config("PAGE_LIST_NUM");
		$type = I('get.type','all','trim');

		$map = array();
		$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));

		switch($type){
			case 'good':
				$map['evaluate_score'] = intval($this->Config("EVALUATE_GOOD"));
				break;
			case 'middle':
				$map['evaluate_score'] = intval($this->Config("EVALUATE_MIDDLE"));
				break;
			case 'bad':
				$map['evaluate_score'] = intval($this->Config("EVALUATE_BAD"));
				break;
		}

		$evaluationList = D('Evaluate')->where($map)->field('id,user_name,user_avator,lesson_name,evaluate_score,createtime,evaluate')->limit('0,'.$page_num)->select();

		if(!empty($evaluationList) && is_array($evaluationList)){
			foreach($evaluationList as $k=>$v){
				$lesson_name_array = unserialize($v['lesson_name']);
				foreach($lesson_name_array as $key=>$name){
					if($key != 0){
						$evaluationList[$k]['lesson_name'] .= '/'.$name['lesson_name'];
					}else{
						$evaluationList[$k]['lesson_name'] = $name['lesson_name'];
					}
				}

			}
		}

		$mapCount = array();
		$mapCount['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));

		//评论统计
		$all_num = D('Evaluate')->where($mapCount)->count();

		$mapCount['evaluate_score'] = $this->Config("EVALUATE_GOOD");
		$good_num = D('Evaluate')->where($mapCount)->count();

		$mapCount['evaluate_score'] = $this->Config("EVALUATE_MIDDLE");
		$middle_num = D('Evaluate')->where($mapCount)->count();

		$mapCount['evaluate_score'] = $this->Config("EVALUATE_BAD");
		$bad_num = D('Evaluate')->where($mapCount)->count();

		$tplArray = array('evaluationList'=>$evaluationList,'all_num'=>$all_num,'good_num'=>$good_num,'middle_num'=>$middle_num,'bad_num'=>$bad_num,'type'=>$type);
		$this->assign($tplArray);
		$this->display();
	}

	//ajax选择评价类型
	public function ajaxEvaluation(){
		$error = new Error();

		if(IS_GET){
			$page_num = $this->Config("PAGE_LIST_NUM");
			$page = I('get.page');
			$start_num = intval($page)*$page_num;

			$map = array();
			$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));

			$evaluation_score = I('get.evaluation_type');
			if(!empty($evaluation_score)){
				switch($evaluation_score){
					case 1:
						$map['evaluation_score'] = $this->Config("EVALUATE_GOOD");
						break;
					case 2:
						$map['evaluation_score'] = $this->Config("EVALUATE_MIDDLE");
						break;
					case 3:
						$map['evaluation_score'] = $this->Config("EVALUATE_BAD");
						break;
				}
			}

			$evaluationList = D('Evaluate')->where($map)->field('id,user_name,user_avator,lesson_name,evaluate_score,createtime,evaluate')->limit($start_num.','.$page_num)->select();
			if(!empty($evaluationList) && is_array($evaluationList)){
				foreach($evaluationList as $k=>$v){
					$lesson_name_array = unserialize($v['lesson_name']);
					foreach($lesson_name_array as $key=>$name){
						if($key != 0){
							$evaluationList[$k]['lesson_name'] .= '/'.$name['lesson_name'];
						}else{
							$evaluationList[$k]['lesson_name'] = $name['lesson_name'];
						}
					}

				}
			}
			$error->setError(0, "加载成功",$evaluationList);
		}else{
			$trainerInfo = D('Trainer')->thinkfind(session($this->Config("SESSION_TRAINER_ID")));
			$error->setError(101, "服务当前不可用，请稍后再试",$trainerInfo);
		}

		$this->ajaxReturn($error->getResult());
	}

	public function ajaxEvaluationReply(){
		$error = new Error();

		$content = I('post.content','','trim');
		if(empty($content)){
			$error->setError(101, "回复内容不能为空");
		}else{

			$error->setError(0, "回复成功",$content);
		}

		$this->ajaxReturn($error->getResult());
	}

	//课程管理
	public function trainerLessons(){
		$page_num = $this->Config("PAGE_LIST_NUM");
		$class_id = I('get.class_id',1,'intval');

		//课程分类
		$lessonClass = D('LessonClass')->loadLessonClass(true);
		$subClass = D('LessonClass')->getLessonClassSubList($class_id);

		$map = array();
		$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));
		$map['lesson_class_id'] = array('in',$subClass);
		
		$lessonList = D('Lesson')->where($map)->field('id,lesson_class_id,image,title,lesson_nums,price_market,price')->limit('0,'.$page_num)->select();

		$this->assign('class_id',$class_id);
		$this->assign('lessonList',$lessonList);
		$this->assign('lessonClass',$lessonClass);
		$this->display();
	}

	//ajax加载课程
	public function ajaxTrainerLessons(){
		$error = new Error();

		if(IS_GET){
			$page_num = $this->Config("PAGE_LIST_NUM");
			$page = I('get.page',0,'intval');
			$start_num = intval($page)*$page_num;

			$class_id = I('get.class_id',1,'intval');
			$lessonClass = D('LessonClass')->loadLessonClass(true);
			$subClass = D('LessonClass')->getLessonClassSubList($class_id);

			$map = array();
			$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));
			$map['lesson_class_id'] = array('in',$subClass);
			

			$lessonList = D('Lesson')->where($map)->field('id,lesson_class_id,image,title,lesson_nums,price_market,price')->limit($start_num.','.$page_num)->select();

			if(!empty($lessonList) && is_array($lessonList)){
				foreach($lessonList as $k=>$lesson){
					$lessonList[$k]['info_url'] = U('TrainerCenter/trainerLessonAdd',array('teacher_id'=>$lesson['id'],'type'=>'check'));
					$lessonList[$k]['edit_url'] = U('TrainerCenter/trainerLessonAdd',array('teacher_id'=>$lesson['id']));

					if(empty($lesson['image'])){
						$lessonList[$k]['image'] = __ROOT__.'/Public/images/icon-course.jpg';
					}else{
						$lessonList[$k]['image'] = __ROOT__.$lesson['image'];
					}
				}
			}

			$error->setError('0','加载成功',$lessonList);
		}else{
			$error->setError('101','服务器错误');
		}

		$this->ajaxReturn($error->getResult());
	}

	//添加或编辑或查看课程
	public function trainerLessonsAdd(){
		$lesson_id = I('get.lesson_id',0,'intval');
		$type = I('get.type','','trim');

		$lessonClass = D('LessonClass')->loadLessonClass(true);
		$lessonClassStr = '[';
		if(!empty($lessonClass) && is_array($lessonClass)){
			foreach($lessonClass as $lesson){
				$lessonClassStr .= "{title:'".$lesson['name']."',";
				$lessonClassStr .= "value:".$lesson['id']."},";
			}
		}
		$lessonClassStr .= ']';

		//优惠券适用范围
		$buy_voucher = array();
		$buy_voucher[0] = array('id'=>$this->Config("LESSON_VOUCHER_ALL"),'title'=>'全部可用');
		$buy_voucher[1] = array('id'=>$this->Config("LESSON_VOUCHER_NONE"),'title'=>'全部不可用');
		$buy_voucher[2] = array('id'=>$this->Config("LESSON_VOUCHER_TRAINER"),'title'=>'自己发送的');
		$buy_voucher[3] = array('id'=>$this->Config("LESSON_VOUCHER_SYSTEM"),'title'=>'站点发送的');

		//授课地址
		$map = array();
		$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));
		$addressList = D('TrainerAddress')->where($map)->field('id,title,area_info')->select();
		$addressListStr = '[';
		if(!empty($addressList) && is_array($addressList)){
			foreach($addressList as $address){
				$addressListStr .= "{title:'".$address['title'].$address['area_info']."',";
				$addressListStr .= "value:".$address['id']."},";
			}
		}
		$addressListStr .= ']';

		//授课老师
		$map = array();
		$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));
		$teacherList = D('OrgTeacher')->where($map)->field('id,title')->select();
		$teacherListStr = '[';
		if(!empty($teacherList) && is_array($teacherList)){
			foreach($teacherList as $teacher){
				$teacherListStr .= "{title:'".$teacher['title']."',";
				$teacherListStr .= "value:".$teacher['id']."},";
			}
		}
		$teacherListStr .= ']';

		if($lesson_id > 0){
			$lessonInfo1 = D('Lesson')->getLesson($lesson_id);
			$lessonInfo2 = D('LessonInfo')->getLessonInfo($lesson_id);
			$lessonInfo = array_merge($lessonInfo1,$lessonInfo2);

			$lesson_teacher = D('LessonOrgTeacher')->getTeacherArrayByLessonId($lesson_id);

			$lesson_teacher_ids = array();

			if(!empty($lesson_teacher) && is_array($lesson_teacher)){
				foreach($lesson_teacher as $teacher){
					$lesson_teacher_ids[] = $teacher['org_teacher_id'];
				}
			}

			$lesson_teacher_ids_str = implode(',',$lesson_teacher_ids);
			$lessonInfo['lesson_teacher_ids'] = $lesson_teacher_ids_str;

			$lesson_teacher_titles = '';

			$org_teacher = D('OrgTeacher')->getTeacherInfo($lesson_teacher_ids);
			if(!empty($org_teacher) && is_array($org_teacher)){
				foreach($org_teacher as $teacher){
					$lesson_teacher_titles .= $teacher['title'].',';
				}
			}

			$lessonInfo['lesson_teacher_titles'] = substr($lesson_teacher_titles,-1);

			if(empty($type)){
				$meta_title = '编辑课程';
			}else{
				$meta_title = '查看课程';
			}

		}else{
			$lessonInfo = array();
			$meta_title = '添加课程';
		}

		$tplArray = array('lessonInfo'=>$lessonInfo,'lessonClassStr'=>$lessonClassStr,'buy_voucher'=>$buy_voucher,'addressListStr'=>$addressListStr,'teacherListStr'=>$teacherListStr,'meta_title'=>$meta_title,'type'=>$type);
		$this->assign($tplArray);
		$this->display();
	}

	/*
	 * ajax读取二级分类
	 * */
	public function ajaxLessonsClass(){
		$error = new Error();

		$parent_classid = I('post.class_id');
		if(empty($parent_classid)){
			$error->setError('101','数据错误');
		}else{
			$lessonClass = D('LessonClass')->loadLessonClass(true);
			if(empty($lessonClass[$parent_classid]['sub'])){
				$error->setError('102','数据错误');
			}else{
				$lessonClassStr = '[';
				foreach($lessonClass[$parent_classid]['sub'] as $class_id=>$lesson){
					$lessonClassStr .= "{title:'".$lesson['name']."',";
					$lessonClassStr .= "value:".$class_id."},";
				}
				$lessonClassStr .= ']';

				$error->setError(0,'请求成功',$lessonClassStr);
			}
		}

		$this->ajaxReturn($error->getResult());
	}

	//ajax添加或编辑或查看课程
	public function ajaxTrainerLessonsAdd(){
		$error = new Error();

		if(IS_POST){
			$lesson_class_id = I('post.lesson_class_id',0,'intval');
			$title = I('post.title','','trim');
			$lesson_nums = I('post.lesson_nums',1,'intval');
			$lesson_hour = I('post.lesson_hour',0,'intval');
			$price = I('post.price',0.00,'floatval');
			$price_market = I('post.price_market',0.00,'floatval');
			$maxbuy_nums = I('post.maxbuy_nums',0,'intval');
			$buy_point = I('post.buy_point',0.00,'floatval');
			$buy_voucher = I('post.buy_voucher',0,'intval');
			$canpayoffline = I('post.canpayoffline',0,'intval');
			$lesson_trial = I('post.lesson_trial','','trim');
			$lesson_age = I('post.lesson_age','','trim');
			$lesson_interval = I('post.lesson_interval','','trim');
			$lesson_members = I('post.lesson_members',0,'intval');
			$lesson_time = I('post.lesson_time','','trim');
			$image = I('post.image','','trim');
			$lesson_content = I('post.lesson_content','','trim');
			$teacher_ids = I('post.teacher_id','','trim');
			$address_ids = I('post.address_id','','trim');

			if(empty($lesson_class_id) || empty($title) || empty($price) || empty($teacher_ids) || empty($address_ids)){
				$error->setError('102','请补充完整资料');
			}else {
				$lesson_id = I('post.lesson_id', 0, 'intval');
				$trainer_id = intval(session($this->Config("SESSION_TRAINER_ID")));

				if($lesson_id > 0){
					$update_array = array();
					$update_array['id'] = $lesson_id;
					$update_array['trainer_id'] = $trainer_id;
					$update_array['lesson_class_id'] = $lesson_class_id;
					$update_array['title'] = $title;
					$update_array['startyear'] = $startyear;
					$update_array['graduate'] = $graduate;
					$update_array['avator'] = $avator;
					$update_array['image'] = $image;
					$update_array['content'] = $content;

					D('OrgTeacher')->save($update_array);
					$error->setError('0','老师信息编辑成功');
				}else{
					$insert_lesson = array();
					$insert_lesson['lesson_class_id'] = $lesson_class_id;
					$insert_lesson['title'] = $title;
					$insert_lesson['trainer_id'] = $trainer_id;
					$insert_lesson['image'] = $image;
					$insert_lesson['price'] = $price;
					$insert_lesson['price_market'] = $price_market;
					$insert_lesson['maxbuy_nums'] = $maxbuy_nums;
					$insert_lesson['lesson_nums'] = $lesson_nums;
					$insert_lesson['buy_point'] = $buy_point;
					$insert_lesson['buy_voucher'] = $buy_voucher;
					$insert_lesson['canpayoffline'] = $canpayoffline;

					$lesson_id = D('Lesson')->add($insert_lesson);

					$insert_lesson_info = array();
					$insert_lesson_info['lesson_id'] = $lesson_id;
					$insert_lesson_info['lesson_hour'] = $lesson_hour;
					$insert_lesson_info['lesson_age'] = $lesson_age;
					$insert_lesson_info['lesson_time'] = $lesson_time;
					$insert_lesson_info['lesson_interval'] = $lesson_interval;
					$insert_lesson_info['lesson_members'] = $lesson_members;
					$insert_lesson_info['lesson_trial'] = $lesson_trial;
					$insert_lesson_info['lesson_content'] = $lesson_content;
					$lesson_info_id = D('LessonInfo')->add($insert_lesson_info);

					$addressList = explode(',',$address_ids);

					foreach($addressList as $address_id){
						D('LessonAddress')->addTrainerLessonAddress($trainer_id,$address_id,$lesson_id);
					}

					$teacherList = explode(',',$teacher_ids);

					foreach($teacherList as $teacher_id){
						D('LessonOrgTeacher')-> addTrainerOrgTeacher($lesson_id,$teacher_id);
					}

					$error->setError('0','课程信息添加成功');
				}
			}
		}else{
			$error->setError('101','提交信息错误');
		}

		$this->ajaxReturn($error->getResult());
	}

	//删除课程
	public function ajaxTrainerLessonsDelete(){
		$lesson_id = I('get.lesson_id',0,'intval');

		$error = new Error();

		if($lesson_id > 0){
			$lesson_info = D('Lesson')->getLesson($lesson_id);

			$trainer_id = intval(session($this->Config("SESSION_TRAINER_ID")));
			if(empty($lesson_info) || $lesson_info['trainer_id'] != $trainer_id){
				$error->setError('101','数据错误');
			}else{
				D('Lesson')->delete($lesson_id);
				D('LessonInfo')->where(array('lesson_id'=>$lesson_id))->delete();
				D('LessonAddress')->where(array('lesson_id'=>$lesson_id))->delete();
				D('LessonOrgTeacher')->where(array('lesson_id'=>$lesson_id))->delete();

				$error->setError('0','删除成功');
			}
		}else{
			$error->setError('101','数据错误');
		}

		$this->ajaxReturn($error->getResult());
	}

	//机构老师
	public function trainerTeacher(){
		$page_num = $this->Config("PAGE_LIST_NUM");
		$class = I('get.class',1,'intval');

		//课程分类
		$lessonClass = D('LessonClass')->loadLessonClass(true);
		$subClass = D('LessonClass')->getLessonClassSubList($class);
		$subClass[] = $class;

		$map = array();
		$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));
		$map['lesson_class_id'] = array('in',$subClass);

		$teacherList = D('OrgTeacher')->where($map)->field('id,title,avator,startyear,graduate')->limit('0,'.$page_num)->select();

		$this->assign('class',$class);
		$this->assign('teacherList',$teacherList);
		$this->assign('lessonClass',$lessonClass);
		$this->display();
	}

	public function ajaxTrainerTeacher(){
		$error = new Error();

		if(IS_GET){
			$page_num = $this->Config("PAGE_LIST_NUM");
			$page = I('get.page',0,'intval');
			$start_num = intval($page)*$page_num;

			$class = I('get.class',1,'intval');
			$subClass = D('LessonClass')->getLessonClassSubList($class);
			$subClass[] = $class;

			$map = array();
			$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));
			$map['lesson_class_id'] = array('in',$subClass);

			$teacherList = D('OrgTeacher')->where($map)->field('id,title,avator,startyear,graduate')->limit($start_num.','.$page_num)->select();

			if(!empty($teacherList) && is_array($teacherList)){
				foreach($teacherList as $k=>$teacher){
					$teacherList[$k]['info_url'] = U('TrainerCenter/trainerTeacherInfo',array('teacher_id'=>$teacher['id']));
					$teacherList[$k]['edit_url'] = U('TrainerCenter/trainerTeacherAdd',array('teacher_id'=>$teacher['id']));
					$teacherList[$k]['startyearcount'] = getExperienceYears($teacher['graduate']);

					if(empty($teacher['avator'])){
						$teacherList[$k]['avator'] = __ROOT__.'/Public/images/icon-people.jpg';
					}else{
						$teacherList[$k]['avator'] = __ROOT__.$teacher['avator'];
					}
				}
			}

			$error->setError('0','加载成功',$teacherList);
		}else{
			$error->setError('101','服务器错误');
		}

		$this->ajaxReturn($error->getResult());
	}

	//老师详情
	public function trainerTeacherInfo(){
		$teacher_id = I('get.teacher_id',0,'intval');

		if(empty($teacher_id)){
			redirect(U('TrainerCenter/trainerTeacher'));
		}else {
			$teacherInfo = D('OrgTeacher')->find($teacher_id);

			if(empty($teacherInfo) || $teacherInfo['trainer_id'] != intval(session($this->Config("SESSION_TRAINER_ID")))){
				redirect(U('TrainerCenter/trainerTeacher'));
			}
		}

		$teacherInfo['lesson_class_name'] = D('LessonClass')->getFieldById($teacherInfo['lesson_class_id'],'title');

		$this->assign('teacherInfo',$teacherInfo);
		$this->display();
	}

	//修改或添加老师
	public function trainerTeacherAdd(){
		$teacher_id = I('get.teacher_id',0,'intval');

		if($teacher_id > 0){
			$teacherInfo = D('OrgTeacher')->find($teacher_id);
			if(!empty($teacherInfo) && $teacherInfo['trainer_id'] == intval(session($this->Config("SESSION_TRAINER_ID")))){
				$teacherInfo['lesson_class_name'] = D('LessonClass')->getFieldById($teacherInfo['lesson_class_id'],'title');
				$this->assign('teacherInfo',$teacherInfo);
				$this->meta_title = '修改老师';
			}else{
				$this->meta_title = '添加老师';
			}
		}else{
			$this->meta_title = '添加老师';
		}

		//课程分类
		$lessonClass = D('LessonClass')->loadLessonClass(true);

		if(!empty($lessonClass) && is_array($lessonClass)){
			$classStr = '';
			foreach($lessonClass as $class_id=>$class){
				$classStr .= '{title:"'.$class['name'].'",';
				$classStr .= 'value:'.$class_id.',},';
			}
		}

		$this->assign('classStr',$classStr);
		$this->display();
	}

	public function ajaxTrainerTeacherAdd(){
		$error = new Error();

		if(IS_POST){
			$lesson_class_id = I('post.lesson_class_id',0,'intval');
			$title = I('post.title','','trim');
			$startyear = I('post.startyear',0,'intval');
			$graduate = I('post.graduate','','trim');
			$avator = I('post.avator','','trim');
			$image = I('post.image','','trim');
			$content = I('post.content','','trim');
			
			if(empty($lesson_class_id) || empty($title) || empty($startyear) || empty($graduate) || empty($avator) || empty($image) || empty($content)){
				$error->setError('102','请补充完整资料');
			}else {
				$teacher_id = I('post.teacher_id', 0, 'intval');
				$trainer_id = intval(session($this->Config("SESSION_TRAINER_ID")));

				if($teacher_id > 0){
					$update_array = array();
					$update_array['id'] = $teacher_id;
					$update_array['trainer_id'] = $trainer_id;
					$update_array['lesson_class_id'] = $lesson_class_id;
					$update_array['title'] = $title;
					$update_array['startyear'] = $startyear;
					$update_array['graduate'] = $graduate;
					$update_array['avator'] = $avator;
					$update_array['image'] = $image;
					$update_array['content'] = $content;

					D('OrgTeacher')->save($update_array);
					$error->setError('0','老师信息编辑成功');
				}else{
					$insert_array = array();
					$insert_array['trainer_id'] = $trainer_id;
					$insert_array['lesson_class_id'] = $lesson_class_id;
					$insert_array['title'] = $title;
					$insert_array['startyear'] = $startyear;
					$insert_array['graduate'] = $graduate;
					$insert_array['avator'] = $avator;
					$insert_array['image'] = $image;
					$insert_array['content'] = $content;

					D('OrgTeacher')->add($insert_array);
					$error->setError('0','老师信息添加成功');
				}
			}
		}else{
			$error->setError('101','提交信息错误');
		}

		$this->ajaxReturn($error->getResult());
	}


	//ajax上传
	public function ajaxUpload(){
		
		$upload = new \Think\Upload();
		$upload->maxSize = 5242880;  //上传文件最大为5M
		$upload->exts = array('jpg', 'gif', 'png', 'jpeg');

		$upload->rootPath = './Uploads/';
		$upload->savePath  = 'org_teacher/'.date('Ymd').'/';
		$upload->subName = '';

		$file_name = I('post.filename','','trim');
		$info = $upload->uploadOne($_FILES[$file_name]);
		if(!$info){
			$return['status'] = 0;
			$return['info'] = $upload->getError();
		}else{
			$return['status'] = 1;
			$info['file_url'] = __ROOT__.$upload->rootPath.$upload->savePath.$info['savename'];
			$info['file'] = $upload->rootPath.$upload->savePath.$info['savename'];
			$return = array_merge($return,$info);
		}

		$this->ajaxReturn($return,'JSON');
	}

	//删除老师
	public function ajaxTrainerTeacherDelete(){
		$teacher_id = I('get.teacher_id',0,'intval');
		$error = new Error();

		if($teacher_id > 0){
			$teacher_info = D('OrgTeacher')->find($teacher_id);
			$trainer_id = intval(session($this->Config("SESSION_TRAINER_ID")));
			if(empty($teacher_info) || $teacher_info['trainer_id'] != $trainer_id){
				$error->setError('101','数据错误');
			}else{
				D('OrgTeacher')->delete($teacher_id);
				$error->setError('0','删除成功');
			}
		}else{
			$error->setError('101','数据错误');
		}

		$this->ajaxReturn($error->getResult());
	}

	//地址管理
	public function trainerAddress(){
		$page_num = $this->Config("PAGE_LIST_NUM");

		$map = array();
		$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));

		$addressList = D('TrainerAddress')->where($map)->field('id,title,area_id,area_info')->limit('0,'.$page_num)->select();

		$this->assign('addressList',$addressList);
		$this->display();
	}

	public function ajaxTrainerAddress(){
		$error = new Error();

		if(IS_GET){
			$page_num = $this->Config("PAGE_LIST_NUM");
			$page = I('get.page');
			$start_num = intval($page)*$page_num;

			$map = array();
			$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));

			$addressList = D('TrainerAddress')->where($map)->field('id,title,area_id,area_info')->limit($start_num.','.$page_num)->select();
			if(!empty($addressList) && is_array($addressList)){
				foreach($addressList as $k=>$address){
					$addressList[$k]['edit_url'] = U('TrainerCenter/trainerAddressAdd',array('address_id'=>$address['id']));
				}
			}

			$error->setError('0','加载成功',$addressList);
		}else{
			$error->setError('101','服务器错误');
		}

		$this->ajaxReturn($error->getResult());

	}

	public function trainerAddressAdd(){
		$address_id = I('get.address_id',0,'intval');

		if($address_id > 0){
			$addressInfo = D('TrainerAddress')->find($address_id);

			if(!empty($addressInfo) && $addressInfo['trainer_id'] == intval(session($this->Config("SESSION_TRAINER_ID")))){
				$this->assign('addressInfo',$addressInfo);
				$this->meta_title = '修改地址';
			}else{
				$this->meta_title = '添加地址';
			}
		}else{
			$this->meta_title = '添加地址';
		}

		$this->display();
	}

	public function ajaxTrainerAddressAdd(){
		$error = new Error();

		if(IS_POST){
			$title = I('post.area_name','','trim');
			$area_id = I('post.area_id',0,'intval');
			$area_info = I('post.area_info','','trim');

			if(empty($title) || empty($area_id) || empty($area_info)){
				$error->setError('102','所在地区或详细地址不能为空');
			}else {
				$address_id = I('post.address_id', 0, 'intval');
				$trainer_id = intval(session($this->Config("SESSION_TRAINER_ID")));

				$address = str_replace(' ','',$title);
				$address .= $area_info;
				$ak = $this->Config("DEFAULT_BAIDU_API_KEY");
				$url = 'http://api.map.baidu.com/geocoder/v2/?address='.$address.'&output=json&ak='.$ak;
				$mapInfo = getCurl($url);
				$lng = $mapInfo['result']['location']['lng'];
				$lat = $mapInfo['result']['location']['lat'];

				if($address_id > 0){
					D('TrainerAddress')->updateTrainerAddress($address_id,$trainer_id,$title,$area_id,$area_info,$lng,$lat);
					$error->setError('0','编辑地址信息成功');
				}else{
					D('TrainerAddress')->addTrainerAddress($trainer_id,$title,$area_id,$area_info,$lng,$lat);
					$error->setError('0','添加地址信息成功');
				}
			}
		}else{
			$error->setError('101','提交信息错误');
		}

		$this->ajaxReturn($error->getResult());
	}

	public function ajaxTrainerAddressDelete(){
		$address_id = I('get.address_id',0,'intval');
		$error = new Error();

		if($address_id > 0){
			$address_info = D('TrainerAddress')->find($address_id);
			$trainer_id = intval(session($this->Config("SESSION_TRAINER_ID")));
			if(empty($address_info) || $address_info['trainer_id'] != $trainer_id){
				$error->setError('101','数据错误');
			}else{
				D('TrainerAddress')->delete($address_id);
				$error->setError('0','删除成功');
			}
		}else{
			$error->setError('101','数据错误');
		}

		$this->ajaxReturn($error->getResult());
	}

	//关注用户
	public function trainerFocus(){
		$page_num = $this->Config("PAGE_LIST_NUM");

		$map = array();
		$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));
		$map['starsearch_favourite.state'] = 1;

		$focusList = M('Favourite')
			->join('starsearch_user on starsearch_favourite.user_id = starsearch_user.id')
			->where($map)
			->field('starsearch_favourite.id,starsearch_user.mobile,starsearch_user.username,starsearch_user.avator,starsearch_user.createtime')
			->limit('0,'.$page_num)
			->order('starsearch_favourite.sort desc,starsearch_favourite.id desc')
			->select();

		$this->assign('focusList',$focusList);
		$this->display();
	}

	public function ajaxTrainerFocus(){
		$error = new Error();

		if(IS_GET){
			$page_num = $this->Config("PAGE_LIST_NUM");
			$page = I('get.page');
			$start_num = intval($page)*$page_num;

			$map = array();
			$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));
			$map['starsearch_favourite.state'] = 1;

			$focusList = M('Favourite')
				->join('starsearch_user on starsearch_favourite.user_id = starsearch_user.id')
				->where($map)
				->field('starsearch_favourite.id,starsearch_user.mobile,starsearch_user.username,starsearch_user.avator,starsearch_user.createtime')
				->limit($start_num.','.$page_num)
				->order('starsearch_favourite.sort desc,starsearch_favourite.id desc')
				->select();

			if(!empty($focusList) && is_array($focusList)){
				foreach($focusList as $k=>$focus){
					if(empty($focus['avator'])){
						$focusList[$k]['avator'] = __ROOT__.'/Public/images/icon-people.jpg';
					}else{
						$focusList[$k]['avator'] = __ROOT__.$focus['avator'];
					}

					$focusList[$k]['dateTime'] = date('Y-m-d H:i:s',$focus['createtime']);
				}
			}
			$error->setError('0','加载成功',$focusList);
		}else{
			$error->setError('101','服务器错误');
		}

		$this->ajaxReturn($error->getResult());
	}

	//钱包
	public function trainerMoney(){
		$trainer_id = intval(session($this->Config("SESSION_TRAINER_ID")));
		//账户余额
		$balance = D('Trainer')->getFieldById($trainer_id,'money');

		$page_num = $this->Config("PAGE_LIST_NUM");

		$map = array();
		$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));

		$moneyList = D('MoneyLog')->where($map)->field('id,money,reason')->limit('0,'.$page_num)->select();

		$this->assign('balance',$balance);
		$this->assign('moneyList',$moneyList);
		$this->display();
	}
	//ajax加载
	public function ajaxTrainerMoney(){
		$error = new Error();

		if(IS_GET){
			$page_num = $this->Config("PAGE_LIST_NUM");
			$page = I('get.page');
			$start_num = intval($page)*$page_num;

			$map = array();
			$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));

			$moneyList = D('MoneyLog')->where($map)->field('id,money,reason')->limit($start_num.','.$page_num)->select();

			if(!empty($money) && is_array($money)){
				foreach($moneyList as $k=>$money){
					$moneyList[$k]['create_date'] = date('Y-m-d H:i:s',$money);
					if($money['money'] > 0){
						$moneyList[$k]['type'] = 1;
					}else{
						$moneyList[$k]['type'] = 2;
					}
				}
			}

			$error->setError('0','加载成功',$moneyList);
		}else{
			$error->setError('101','服务器错误');
		}

		$this->ajaxReturn($error->getResult());
	}

	//钱包提现
	public function trainerMoneyWithdraw(){
		$trainer_id = intval(session($this->Config("SESSION_TRAINER_ID")));
		//账户余额
		$balance = D('Trainer')->getFieldById($trainer_id,'money');

		$this->assign('balance',$balance);
		$this->display();
	}

	//ajax提交提现申请
	public function ajaxTrainerMoneyWithdrawAdd(){
		$balance = I('post.balance',0,'intval');

		$error = new Error();

		if($balance <= 0){
			$error->setError('101','提现金额不能为空');
		}else{
			$trainer_id = intval(session($this->Config("SESSION_TRAINER_ID")));
			//账户余额
			$money = D('Trainer')->getFieldById($trainer_id,'money');

			if($balance > $money){
				$error->setError('101','提现金额不能大于账户余额');
			}else{
				//提现申请
				$withdrawArray = array();
				$withdrawArray['trainer_id'] = $trainer_id;
				$withdrawArray['money'] = $balance;
				$withdrawArray['trainer_withdraw_state_id'] = 1;

				D('TrainerWithdraw')->add($withdrawArray);
				//钱包记录
				$moneyArray = array();
				$moneyArray['trainer_id'] = $trainer_id;
				$moneyArray['money'] = '-'.$balance;
				$moneyArray['reason'] = '提现';

				D('MoneyLog')->add($moneyArray);

				//账户余额
				$trainerArray = array();
				$trainerArray['money'] = $trainerArray['money'] - $balance;
				D('Trainer')->save($trainerArray);

				$error->setError('0','提现申请发送成功');
			}
		}
		$this->ajaxReturn($error->getResult());
	}

	//优惠券
	public function trainerCoupons(){
		
		$page_num = $this->Config("PAGE_LIST_NUM");

		$map = array();
		$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));

		$voucherList = D('Voucher')->where($map)->field('id,lesson_class_id,title,amount,pricelimit,total,use_starttime,use_endtime')->limit('0,'.$page_num)->select();

		$lessonClass = D('LessonClass')->field("id,title")->order('sort desc ,id asc')->select();

		$lessonClassTemp = array();
		if(!empty($lessonClass) && is_array($lessonClass)){
			foreach($lessonClass as $lesson){
				$lessonClassTemp[$lesson['id']] = $lesson['title'];
			}
		}

		if(!empty($voucherList) && is_array($voucherList)){
			foreach($voucherList as $k=>$voucher){
				if($voucher['pricelimit'] > 0){
					if($voucher['lesson_class_id'] > 0){
						$voucherList[$k]['introduction'] = '满'.$voucher['pricelimit'].'元使用,限'.$lessonClassTemp[$voucher['lesson_class_id']].'类使用,不可叠加';
					}else{
						$voucherList[$k]['introduction'] = '满'.$voucher['pricelimit'].'元使用,不可叠加';
					}
				}else{
					$voucherList[$k]['introduction'] = '购买课程不可叠加';
				}

			}
		}
		$this->assign('voucherList',$voucherList);
		$this->display();
	}

	//ajaxload加载
	public function ajaxTrainerCoupons(){
		$error = new Error();

		if(IS_GET){
			$page_num = $this->Config("PAGE_LIST_NUM");
			$page = I('get.page');
			$start_num = intval($page)*$page_num;

			$map = array();
			$map['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));

			$voucherList = D('Voucher')->where($map)->field('id,lesson_class_id,title,amount,pricelimit,total,use_starttime,use_endtime')->limit($start_num.','.$page_num)->select();

			$lessonClass = D('LessonClass')->field("id,title")->order('sort desc ,id asc')->select();

			$lessonClassTemp = array();
			if(!empty($lessonClass) && is_array($lessonClass)){
				foreach($lessonClass as $lesson){
					$lessonClassTemp[$lesson['id']] = $lesson['title'];
				}
			}

			if(!empty($voucherList) && is_array($voucherList)){
				foreach($voucherList as $k=>$voucher){
					if($voucher['pricelimit'] > 0){
						if($voucher['lesson_class_id'] > 0){
							$voucherList[$k]['introduction'] = '满'.$voucher['pricelimit'].'元使用,限'.$lessonClassTemp[$voucher['lesson_class_id']].'类使用,不可叠加';
						}else{
							$voucherList[$k]['introduction'] = '满'.$voucher['pricelimit'].'元使用,不可叠加';
						}
					}else{
						$voucherList[$k]['introduction'] = '购买课程不可叠加';
					}

				}
			}
			$error->setError('0','加载成功',$voucherList);
		}else{
			$error->setError('101','服务器错误');
		}

		$this->ajaxReturn($error->getResult());
	}


	//添加优惠券
	public function trainerCouponsAdd(){
		$lessonClass = D('LessonClass')->loadLessonClass(true);
		$lessonClassStr = "[{title:'不限制',value:0},";
		if(!empty($lessonClass) && is_array($lessonClass)){
			foreach($lessonClass as $lesson){
				$lessonClassStr .= "{title:'".$lesson['name']."',";
				$lessonClassStr .= "value:".$lesson['id']."},";
			}
		}
		$lessonClassStr .= ']';

		$this->assign('lessonClassStr',$lessonClassStr);
		$this->display();
	}

	//ajax添加优惠券
	public function ajaxTrainerCouponsAdd(){
		$error = new Error();

		if(IS_POST){
			$lesson_class_id = I('post.lesson_class_id',0,'intval');
			$title = I('post.title','','trim');
			$amount = I('post.amount',0.00,'floatval');
			$pricelimit = I('post.pricelimit',0.00,'floatval');
			$total = I('post.total',0,'intval');
			$eachlimit = I('post.eachlimit',0,'intval');
			$points = I('post.points',0,'intval');
			$use_starttime = I('post.use_starttime','','trim');
			$use_endtime = I('post.use_endtime','','trim');
			$giveout_starttime = I('post.giveout_starttime','','trim');
			$giveout_endtime = I('post.giveout_endtime','','trim');

			if(empty($title)){
				$error->setError('102','优惠券名称不能为空');
			}else if($amount <= 0.00) {
				$error->setError('102', '优惠金额不能为空');
			}else {
				$insert_array = array();
				$insert_array['voucher_class_id'] = 2;
				$insert_array['trainer_id'] = intval(session($this->Config("SESSION_TRAINER_ID")));
				$insert_array['trainer_title'] = trim(session($this->Config("SESSION_TRAINER_NAME")));
				$insert_array['lesson_class_id'] = $lesson_class_id;
				$insert_array['title'] = $title;
				$insert_array['amount'] = $amount;
				$insert_array['pricelimit'] = $pricelimit;
				$insert_array['total'] = $total;
				$insert_array['eachlimit'] = $eachlimit;
				$insert_array['points'] = $points;

				if(empty($use_starttime)){
					$insert_array['use_starttime'] = time();
				}else{
					$u_starttime= strtotime($use_starttime) + 86400 - 1;
					$insert_array['use_starttime'] = $u_starttime;
				}

				if(empty($use_endtime)){
					$insert_array['use_endtime'] = 0;
				}else{
					$u_endtime= strtotime($use_endtime) + 86400 - 1;
					$insert_array['use_endtime'] = $u_endtime;
				}

				if(empty($giveout_starttime)){
					$insert_array['giveout_starttime'] = time();
				}else{
					$g_starttime= strtotime($giveout_starttime) + 86400 - 1;
					$insert_array['giveout_starttime'] = $g_starttime;
				}

				if(empty($giveout_endtime)){
					$insert_array['giveout_endtime'] = 0;
				}else{
					$g_endtime= strtotime($giveout_endtime) + 86400 - 1;
					$insert_array['giveout_endtime'] = $g_endtime;
				}

				$coupons_id = D('Voucher')->add($insert_array);

				if($coupons_id > 0){
					$error->setError('0','添加优惠券成功');
				}else{
					$error->setError('103','添加优惠券失败');
				}
			}
		}else{
			$error->setError('101','提交信息错误');
		}

		$this->ajaxReturn($error->getResult());
	}

	//删除优惠券
	public function ajaxTrainerCouponsDelete(){
		$voucher_id = I('get.voucher_id',0,'intval');
		$error = new Error();

		if($voucher_id > 0){
			$voucher_info = D('Voucher')->find($voucher_id);
			$trainer_id = intval(session($this->Config("SESSION_TRAINER_ID")));
			if(empty($voucher_info) || $voucher_info['trainer_id'] != $trainer_id){
				$error->setError('101','数据错误');
			}else{
				D('Voucher')->delete($voucher_id);
				$error->setError('0','删除成功');
			}
		}else{
			$error->setError('101','数据错误');
		}

		$this->ajaxReturn($error->getResult());
	}
}