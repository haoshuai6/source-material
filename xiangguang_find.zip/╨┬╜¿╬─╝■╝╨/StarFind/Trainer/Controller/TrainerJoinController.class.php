<?php
namespace Trainer\Controller;

use Common\BaseClass\Error;
use Common\BaseClass\StarfindController;
use Common\Model\SmsModel;
use Common\Model\UserModel;
use Common\Model\WxAutologinModel;

class TrainerJoinController extends StarfindController
{
	//机构或个人入驻
	public function index()
	{
		$this->assign('smstype', $this->Config("SMS_TYPE_LOGIN"));
		$this->assign('smsurl', U('Home/Sms'));
		$this->assign('smstime', ($this->Config("SMS_MIN_TIME")) * 2);
		$this->display();
	}

	public function doUserJoin()
	{
		$error = new Error();

		$agreement = I('post.agreement_trainer');
		if(!$agreement){
			$error->setError(301, "请接受并同意公约");
		}else{
			$insert_array = array();
			$insert_array['trainer_classid'] = I("post.trainer_classid", 0, "intval");
			$insert_array['contact'] = I('post.contact', "", "trim");
			$insert_array['mobile'] = I("post.mobile", "", "checkMobile");

			$code = I('post.mcode', "", "checkSmsCode");
			$insert_array['trainer_name'] = I("post.trainer_name");
			$insert_array['trainer_card'] = I('post.trainer_card');
			$insert_array['contact_mobile'] = I("post.contact_mobile");
			$insert_array['address'] = I('post.address');
			$insert_array['wx_openid'] = session($this->Config("SESSION_WX_OPENID"));

			if($insert_array['trainer_classid'] != 1 && $insert_array['trainer_classid'] != 2){
				$error->setError(302, "数据错误");
			}

			if($insert_array['trainer_classid'] == 2){
				$insert_array['teacher_graduated'] = I('post.teacher_graduated');
				$insert_array['teacher_school_name'] = I('post.teacher_school_name');
				$insert_array['teacher_school_card'] = I('post.teacher_school_card');

				if(empty($insert_array['contact'])){
					$error->setError(303, "联系人(负责人)不能为空");
				}

				if(empty($insert_array['mobile'])){
					$error->setError(303, "手机号不正确");
				}

				if(empty($code)){
					$error->setError(303, "短信验证码不正确");
				}

				if(empty($insert_array['trainer_name'])){
					$error->setError(303, "真实姓名不能为空");
				}

				if(empty($insert_array['trainer_card'])){
					$error->setError(303, "身份证照片不能为空");
				}

				if(empty($insert_array['teacher_graduated'])){
					$error->setError(303, "请选择是否在读");
				}

				if(empty($insert_array['teacher_school_name'])){
					$error->setError(303, "院校名称不能为空");
				}

				if(empty($insert_array['teacher_school_card'])){
					$error->setError(303, "毕业证照片不能为空");
				}

				if(empty($insert_array['contact_mobile'])){
					$error->setError(303, "联系电话不能为空");
				}

				if(empty($insert_array['address'])){
					$error->setError(303, "教学地址不能为空");
				}

			}else{
				if(empty($insert_array['contact'])){
					$error->setError(303, "联系人(负责人)不能为空");
				}

				if(empty($insert_array['mobile'])){
					$error->setError(303, "手机号不正确");
				}

				if(empty($code)){
					$error->setError(303, "短信验证码不正确");
				}

				if(empty($insert_array['trainer_name'])){
					$error->setError(303, "机构名称不能为空");
				}

				if(empty($insert_array['trainer_card'])){
					$error->setError(303, "营业执照不能为空");
				}

				if(empty($insert_array['contact_mobile'])){
					$error->setError(303, "机构电话不能为空");
				}

				if(empty($insert_array['address'])){
					$error->setError(303, "教学地址不能为空");
				}

			}

			$smsmodel = new SmsModel();
			$sms = $smsmodel->checkSms($insert_array['mobile'], $this->Config("SMS_TYPE_LOGIN"), $code, (time() - ($this->Config("SMS_EXPIRED_TIME") * 60)));
//			if ($sms) {
				//提交申请
				$insert_array['createtime'] = time();
				$insert_array['updatetime'] = time();

				$sid = D('TrainerSignup')->add($insert_array);
				if(!$sid){
					$error->setError(305, "保存申请信息出错");
				}
//			} else {
//				$error->setError(304, "短信验证码不正确或者已经过期");
//			}

		}

		$this->ajaxReturn($error->getResult());
	}

	//ajax上传
	public function ajaxUpload(){
		$upload = new \Think\Upload();
		$upload->maxSize = 5242880;  //上传文件最大为5M
		$upload->exts = array('jpg', 'gif', 'png', 'jpeg');

		$upload->rootPath = './Uploads/';
		$upload->savePath  = 'trainer_card/'.date('Ymd').'/';
		$upload->subName = '';

		$file_name = I('post.filename','','trim');
		$info = $upload->uploadOne($_FILES[$file_name]);
		if(!$info){
			$return['status'] = 0;
			$return['info'] = $upload->getError();
		}else{
			$return['status'] = 1;
			$info['file_url'] = __ROOT__.$upload->rootPath.$upload->savePath.$info['savename'];
			$info['file'] = $upload->rootPath.$upload->savePath.$info['savename'];
			$return = array_merge($return,$info);
		}

		$this->ajaxReturn($return,'JSON');
	}

}