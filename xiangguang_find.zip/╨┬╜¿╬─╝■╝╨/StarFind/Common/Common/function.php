<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/18
 */

function checkMobile($mobile)
{
    $r = "";
    $mobile = trim($mobile);
    if (preg_match("/^1[34578]\d{9}$/", $mobile)) {
        $r = $mobile;
    }
    return $r;
}

function checkSmsCode($code)
{
    $r = "";
    $code = trim($code);
    if (preg_match("/^\d{6}$/", $code)) {
        $r = $code;
    }
    return $r;
}

function getYear($year)
{
    if ($year) {
        return (date("Y") - $year);
    } else {
        return "";
    }
}

function toMoney($float)
{
    $m = floatval($float);
    $m = floatval(substr(sprintf("%.3f", $m), 0, -1));
    return $m;
}

/*
 * 计算教龄
 * */
function getExperienceYears($startYears){
    if(empty($startYears)){
        return 1;
    }else{
        $nowYears = date('Y');
        $diffYears = $nowYears - $startYears;

        if(empty($diffYears)){
            return 1;
        }else{
            return $diffYears;
        }

    }
}

function getCURL($url)
{
    $ch = curl_init();//初始化curl
    curl_setopt($ch, CURLOPT_URL, $url);//抓取指定网页
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);//关闭https验证
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
    //将获取到的内容json解码为类
    $result = json_decode($result, true);
    return $result;
}
function http_request($url,$data=null){
    $ch = curl_init();//初始化curl
    curl_setopt($ch, CURLOPT_URL, $url);//抓取指定网页
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);//关闭https验证
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    if(!empty($data)){
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($result, true);
    return $result;
}

function msubstr($str, $start=0, $length, $charset="utf-8", $suffix=true) {
    if(function_exists("mb_substr"))
        $slice = mb_substr($str, $start, $length, $charset);
    elseif(function_exists('iconv_substr')) {
        $slice = iconv_substr($str,$start,$length,$charset);
        if(false === $slice) {
            $slice = '';
        }
    }else{
        $re['utf-8']   = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
        $re['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";
        $re['gbk']    = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";
        $re['big5']   = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";
        preg_match_all($re[$charset], $str, $match);
        $slice = join("",array_slice($match[0], $start, $length));
    }
    return $suffix ? $slice.'...' : $slice;
}



