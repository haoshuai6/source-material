<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace  Common\Model;
use Think\Model;


class ConfigUserModel extends Model
{


}