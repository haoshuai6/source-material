<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/28
 */

namespace Common\Model;

use Common\BaseClass\StarfindModel;

class PaymentModel extends StarfindModel
{


    public function getPaymentList()
    {
        return $this->select();
    }
    public function getPaymentByString($pstring)
    {
        return $this->where(array('payment_string'=>$pstring))->find();
    }

    public function isPayOfflineAllow($paymentlist)
    {
        if (($paymentlist) && (is_array($paymentlist))) {
            foreach ($paymentlist as $payment) {
                if ($payment['payment_string'] == $this->Config("PAYMENT_OFFLINE_STRING")) {
                    return true;
                }
            }
        }
        return false;
    }

    public function removePayOffline($paymentlist)
    {
        $pm = array();
        if (($paymentlist) && (is_array($paymentlist))) {
            foreach ($paymentlist as $payment) {

                if ($payment['payment_string'] != $this->Config("PAYMENT_OFFLINE_STRING")) {
                    $pm[] = $payment;
                }

            }
        }
        return $pm;
    }
}