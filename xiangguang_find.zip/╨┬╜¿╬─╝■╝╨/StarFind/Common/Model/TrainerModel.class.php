<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace Common\Model;

use Common\BaseClass\StarfindModel;

class TrainerModel extends StarfindModel
{
	public function addTrainer($trainer_class_id, $mobile, $name, $avator = '', $demo = '')
	{
		$data = array();
		$data['trainer_classid'] = $trainer_class_id;
		$data['mobile'] = $mobile;
		$data['avator'] = $avator;
		$data['title'] = $name;
		$data['demo'] = $demo;

		$trainer_id = $this->add($data);
		return $trainer_id;
	}

	public function getTrainerClass($trainer_id)
	{
		$trainer_class_id = $this->where(array("id" => $trainer_id))->getField("trainer_classid");
		return $trainer_class_id;
	}

	public function getRedisTrainerAddressName($trainer_class_id)
	{
		if ($trainer_class_id == $this->config("CLASS_TRAINER_ORGANIZATION")) {
			return $this->config("REDIS_ADDRESS_TRAINER_ORG");
		} else {
			return $this->config("REDIS_ADDRESS_TRAINER_PERSON");
		}
	}

	public function getTrainerByMobile($mobile)
	{
		return $this->where(array('mobile' => $mobile))->find();
	}


	public function updateTrainerLogin($uid)
	{
		$data = array();
		$data['loginnums'] = array('exp', 'loginnums+1');
		$data['lastlogin'] = time();
		$data['ipaddress'] = get_client_ip();
		return $this->where(array("id" => $uid))->save($data);
	}


	public function getTrainer($trainer_id)
	{
		return $this->find($trainer_id);
	}
	
}