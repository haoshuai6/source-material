<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/9
 */
namespace Common\Model;

use Common\BaseClass\StarfindModel;

Class FavouriteModel extends StarfindModel
{
	/*新增*/
	public  function addByUid($pama = array()){
		$data = array();
		$data['state'] = 1;
		$data['createtime'] = time();
		$data['updatetime'] = time();
		$data['operator'] = $pama['user_id'];
		$data['trainer_id'] = $pama['trainer_id'];
		$data['user_id'] = $pama['user_id'];
		$data['lesson_id'] = $pama['lesson_id'];
		$res = $this->table('__FAVOURITE__')->add($data);

		return $res;

	}
	public function getInfoByUid($userid)
	{
		$con = array();
		$con_tra = array();
		$trainer_id = array();
		$con['user_id'] = $userid;
		$con['state'] = $this->Config("STATE_OK");

		$favourite_list = $this->table('__FAVOURITE__')->where($con)->order('createtime desc')->select();
		if($favourite_list && is_array($favourite_list)){
			foreach ($favourite_list as $k => $f_list){
				$trainer_id[$k] = $f_list['trainer_id'];
			}
		}

		$con_tra['id'] = array('in',$trainer_id);
		$favourite_trainer_list = $this->table('__TRAINER__')->where($con_tra)->order('createtime desc')->select();

		return $favourite_trainer_list;
	}
	public function getInfoByTid($trainer_id)
	{
		$con = array();
		$con['trainer_id'] = intval($trainer_id);
		$con['state'] = $this->Config("STATE_OK");
        
		$favourite_list_count = $this->table('__FAVOURITE__')->where($con)->count('distinct(user_id)');


		return $favourite_list_count;
	}
	/*是否关注*/
	public  function getStatusByUidTid($uid,$tid,$lid){
		$con = array();
		$con['user_id'] = intval($uid);
		$con['trainer_id'] = intval($tid);
		$con['lesson_id'] = intval($lid);
		$favourite_status_count = $this->table('__FAVOURITE__')->where($con)->count();
		if($favourite_status_count >0 ){
			return true;
		}else {
			return false;
		}

	}

}