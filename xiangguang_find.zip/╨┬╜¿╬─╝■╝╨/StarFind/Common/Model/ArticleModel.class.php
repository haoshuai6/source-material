<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace  Common\Model;
use Common\BaseClass\StarfindModel;

class ArticleModel extends StarfindModel
{

	public function getInfoByClassid($cid){
		$info = $this->where(array('article_class_id'=>intval($cid)))->find();
		return $info;
	}
}