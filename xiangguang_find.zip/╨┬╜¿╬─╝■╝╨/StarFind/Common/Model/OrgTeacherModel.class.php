<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/24
 */
namespace Common\Model;

use Common\BaseClass\StarfindModel;

class OrgTeacherModel extends StarfindModel
{

	public function getTeacherInfo($teacher_array)
	{
		return $this->where(array('id'=>array('in' , $teacher_array)))->select();
	}
	public function getTeacherInfoByid($id)
	{
		return $this->where(array('trainer_id'=>$id))->find();
	}

}