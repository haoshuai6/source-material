<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/29
 */

namespace Common\Model;

use Common\BaseClass\StarfindModel;

class OrderPayModel extends StarfindModel
{
    public function addPay($paydata)
    {
        return $this->add($paydata);
    }

    public function getLastOrderPayByOrderId($order_id)
    {
        $con = array();
        $con['order_id'] = $order_id;

        return $this->where($con)->order("createtime desc")->find();
    }


    public function setOrderPay($orderpay_id, $newstate, $data = array())
    {
        $data['pay_state'] = $newstate;

        return $this->where($orderpay_id)->save($data);
    }

    public function getOrderPayByPaySN($paysn)
    {
        $con = array();
        $con['pay_sn'] = $paysn;
        return $this->where($con)->find();
    }
}