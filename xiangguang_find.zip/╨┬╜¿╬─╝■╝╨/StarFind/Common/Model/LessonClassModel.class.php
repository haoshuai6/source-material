<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/9
 */
namespace Common\Model;

use Common\BaseClass\StarfindModel;

Class LessonClassModel extends StarfindModel
{
	private $lessonclass;

	/**
	 * @return mixed
	 */
	public function getLessonclass()
	{
		return $this->lessonclass;
	}

	/**
	 * @param mixed $lessonclass
	 */
	public function setLessonclass($lessonclass)
	{
		$this->lessonclass = $lessonclass;
	}

	public function loadLessonClass($reload = false)
	{
		$c = array();
		$sc = S('LessonClass');
		if ((!$sc) || ($reload)) {
			$ls = $this->field("id,title,parent_id")->order('parent_id asc,sort desc ,id asc')->select();
			if (($ls) && is_array($ls)) {

				foreach ($ls as $k => $v) {
					if ($v['parent_id'] == 0) {
						$c[$v['id']] = array('id'=>$v['id'],'name' => $v['title']);
					} else {
						$c[$v['parent_id']]['sub'][$v['id']] = array('name' => $v['title']);
					}
				}
			}
			S('LessonClass', $c);
			$this->setLessonclass($c);
		}
		else {
			$this->setLessonclass($sc);
		}
		return $c;
	}

	public function getLessonClassInfo($lessonclass_id)
	{
		$sc = $this->getLessonclass();
		if ($sc[$lessonclass_id]) {
			return array('name' => $sc[$lessonclass_id]['name'], 'parent_id' => 0, 'sub' => $sc[$lessonclass_id]['sub']);
		} else {
			foreach ($sc as $k => $v) {
				foreach ($v['sub'] as $id => $vv) {
					if ($id == $lessonclass_id) {
						return array('name' => $vv['name'], 'parent_id' => $k, 'sub' => $vv['sub']);
					}
				}
			}
		}
		return false;
	}

	public function getLessonClassSubList($lessonclass_id)
	{
		$list = array();
		$info = $this->getLessonClassInfo($lessonclass_id);
		if ($info) {
			if ($info['parent_id'] == 0) {
				$list = array_keys($info['sub']);
			} else {
				$list = array($lessonclass_id);
			}
		}
		return $list;
	}
	public function getLessonClassList()
	{
		$c = array();
		$ls = $this->field("id,title,parent_id")->order('parent_id asc,sort desc ,id asc')->where(array('parent_id'=>array('neq',0)))->select();

		if (($ls) && is_array($ls)) {
			foreach ($ls as $k => $ls_list) {
				$par_name = $this->field("id,title")->where(array('id'=>$ls_list['parent_id']))->find();
				$c[$k]['title'] = $par_name['title'].'--'.$ls_list['title'];
				$c[$k]['value'] = $ls_list['id'];
			}
		}
		return $c;
	}
	public function getAllLessonClass(){
		$list = array();
		$ls = $this->field("id,title,parent_id")->order('parent_id asc,sort desc ,id asc')->where(array('parent_id'=>array('eq',0)))->select();

		if (($ls) && is_array($ls)) {
			foreach ($ls as $k => $ls_list) {
				$son = $this->field("id,title")->where(array('parent_id'=>$ls_list['id']))->select();
				$list[$k]['title'] = $ls_list['title'];
				$list[$k]['son'] = $son;
			}
		}
		return $list;
	}
	public  function getLessonSonClass($sid)
	{
		static $name = '';
		$p_list = $this->field("id,title,parent_id")->where(array('id'=>intval($sid)))->find();

		$name .= $p_list['title'].'-';
		if($p_list['parent_id']){
			$this->getLessonSonClass($p_list['parent_id']);
		}

		return $name;
	}
	public function getLessonParentClass($p_id)
	{
		$title = '';
		$ls = $this->field("id,title,parent_id")->order('parent_id asc,sort desc ,id asc')->where(array('id'=>intval($p_id)))->find();
		$lp = $this->field("id,title,parent_id")->order('parent_id asc,sort desc ,id asc')->where(array('id'=>intval($ls['parent_id'])))->find();
        if($lp['title']){
			$title = $lp['title'].'--'.$ls['title'];
		}

		return $title;
	}
	public function getClassInfoByid($id){
		$info = $this->where(array('id'=>intval($id)))->find();
		return $info;
	}
}