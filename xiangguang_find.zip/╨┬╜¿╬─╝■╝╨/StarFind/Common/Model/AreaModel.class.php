<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/9
 */
namespace Common\Model;

use Common\BaseClass\StarfindModel;

Class AreaModel extends StarfindModel
{
	private $arealist;

	public $AREA_ZONE = "zone";
	public $AREA_REGION = "region";
	public $AREA_CITY = "city";
	public $AREA_PROVINCE = "province";

	private $area_level = array();

	/**
	 * @return mixed
	 */
	public function getArea()
	{
		return $this->arealist;
	}

	/**
	 * @param mixed $area
	 */
	public function setArea($area)
	{
		$this->arealist = $area;
	}

   /* public  function __initialize(){
	    $this->area_level = array($this->AREA_PROVINCE, $this->AREA_CITY, $this->AREA_REGION, $this->AREA_ZONE);
   }*/
	public function __construct()
	{
		parent::__construct();
		$this->area_level = array($this->AREA_PROVINCE, $this->AREA_CITY, $this->AREA_REGION, $this->AREA_ZONE);
	}


	public function getLevel($levelname)
	{
		$p = -1;
		$n = -1;
		foreach ($this->area_level as $k => $ln) {
			if ($levelname == $ln) {
				if ($k > 0) {
					$p = $k - 1;
				}
				if ($k < (count($this->area_level) - 1)) {
					$n = $k + 1;
				}
				break;
			}
		}
		return array('now' => $k, "pre" => $p, "next" => $n);
	}


	public function loadArea($reload = false)
	{
		$area = S('Area');
		if ((!$area) || ($reload)) {
			$china = array();
			$arealist = $this->field("id, title,geo_lng,geo_lat")->order('sort desc , id asc')->select();
			if (($arealist) && is_array($arealist)) {
				foreach ($arealist as $ar) {
					$area_id = $ar['id'];
					if (strlen($area_id) == 6) {
						$p = substr($area_id, 0, 2);
						$c = substr($area_id, 2, 2);
						$a = substr($area_id, 4, 2);

						if (($c == "00") && ($a == "00")) {
							$china[$this->AREA_PROVINCE][$area_id] = array('name' => $ar['title'], 'geo_lng' => $ar['geo_lng'], 'geo_lat' => $ar['geo_lat']);
						} else if ($a == "00") {
							$china[$this->AREA_PROVINCE][$p . "0000"][$this->AREA_CITY][$area_id] = array('name' => $ar['title'], 'geo_lng' => $ar['geo_lng'], 'geo_lat' => $ar['geo_lat']);
						} else {
							$china[$this->AREA_PROVINCE][$p . "0000"][$this->AREA_CITY][$p . $c . "00"][$this->AREA_REGION][$area_id] = array('name' => $ar['title'], 'geo_lng' => $ar['geo_lng'], 'geo_lat' => $ar['geo_lat']);
						}
					} else if (strlen($area_id == 8)) {
						$p = substr($area_id, 0, 2);
						$c = substr($area_id, 2, 2);
						$a = substr($area_id, 4, 2);
						$china[$this->AREA_PROVINCE][$p . "0000"][$this->AREA_CITY][$p . $c . "00"][$this->AREA_REGION][$p . $c . $a][$this->AREA_ZONE][$area_id] = array('name' => $ar['title'], 'geo_lng' => $ar['geo_lng'], 'geo_lat' => $ar['geo_lat']);
					}
				}
			}
			$area = $china;
			S('Area', $china);
		}
		$this->setArea($area);
		return $area;
	}


	public function getAreaInfo($area_id)
	{
		$area = $this->getArea();
		if (strlen($area_id) == 6) {
			$p = substr($area_id, 0, 2);
			$c = substr($area_id, 2, 2);
			$a = substr($area_id, 4, 2);

			if (($c == "00") && ($a == "00")) {
				return $area[$this->AREA_PROVINCE][$area_id];
			} else if ($a == "00") {
				return $area[$this->AREA_PROVINCE][$p . "0000"][$this->AREA_CITY][$area_id];
			} else {
				return $area[$this->AREA_PROVINCE][$p . "0000"][$this->AREA_CITY][$p . $c . "00"][$this->AREA_REGION][$area_id];
			}
		} else if (strlen($area_id) == 8) {
			$p = substr($area_id, 0, 2);
			$c = substr($area_id, 2, 2);
			$a = substr($area_id, 4, 2);
			return $area[$this->AREA_PROVINCE][$p . "0000"][$this->AREA_CITY][$p . $c . "00"][$this->AREA_REGION][$p . $c . $a][$this->AREA_ZONE][$area_id];
		}
		return $area;
	}

	public function getAreaSubList($area_id, $min = "region")
	{
		$listid = array();

		$area = $this->getArea();

		if (strlen($area_id) == 6) {
			$p = substr($area_id, 0, 2);
			$c = substr($area_id, 2, 2);
			$a = substr($area_id, 4, 2);

			if (($c == "00") && ($a == "00")) {
				if ($min == $this->AREA_PROVINCE) {
					if ($area[$this->AREA_PROVINCE][$area_id]) {
						return array($area_id);
					}
				}
				$cl = array_keys($area[$this->AREA_PROVINCE][$area_id][$this->AREA_CITY]);
				if ($min == $this->AREA_CITY) {
					$listid = $cl;
				} else if ($min == $this->AREA_REGION) {
					foreach ($cl as $c) {
						$aa = $this->getAreaSubList($c, $this->AREA_REGION);
						if (is_array($aa)) {
							$listid = array_merge($listid, $aa);
						}
					}
				} else if ($min == $this->AREA_ZONE) {
					foreach ($cl as $c) {
						$regionid = $this->getAreaSubList($c, $this->AREA_REGION);
						foreach ($regionid as $r) {

							$aa = $this->getAreaSubList($r, $this->AREA_ZONE);
							if (is_array($aa)) {
								$listid = array_merge($listid, $aa);
							}
						}
					}
				}

			} else if ($a == "00") {

				if ($min == $this->AREA_CITY) {
					if ($area[$this->AREA_PROVINCE][$p . "0000"][$this->AREA_CITY][$area_id]) {
						return array($area_id);
					}
				}

				$rl = array_keys($area[$this->AREA_PROVINCE][$p . "0000"][$this->AREA_CITY][$area_id][$this->AREA_REGION]);
				if ($min == $this->AREA_REGION) {
					$listid = $rl;
				} else if ($min == $this->AREA_ZONE) {
					foreach ($rl as $r) {
						$aa = $this->getAreaSubList($r, $this->AREA_ZONE);
						if (is_array($aa)) {
							$listid = array_merge($listid, $aa);
						}
					}
				}
			} else {

				if ($min == $this->AREA_REGION) {
					if ($area[$this->AREA_PROVINCE][$p . "0000"][$this->AREA_CITY][$p . $c . "00"][$this->AREA_REGION][$area_id]) {
						return array($area_id);
					}
				}

				$zl = array_keys($area[$this->AREA_PROVINCE][$p . "0000"][$this->AREA_CITY][$p . $c . "00"][$this->AREA_REGION][$area_id][$this->AREA_ZONE]);
				$listid = $zl;
			}
		} else if (strlen($area_id) == 8) {

			if ($min == $this->AREA_ZONE) {
				$p = substr($area_id, 0, 2);
				$c = substr($area_id, 2, 2);
				$a = substr($area_id, 4, 2);
				if ($area[$this->AREA_PROVINCE][$p . "0000"][$this->AREA_CITY][$p . $c . "00"][$this->AREA_REGION][$p . $c . $a][$this->AREA_ZONE][$area_id]) {
					return array($area_id);
				}
			}

			$listid = array();
		} else {

			if ($min == $this->AREA_PROVINCE) {
				if ($area[$this->AREA_PROVINCE][$area_id]) {
					return array($area_id);
				}
			}

			$pl = array_keys($area[$this->AREA_PROVINCE]);
			if ($min == $this->AREA_PROVINCE) {
				$listid = $pl;
			} else if ($min == $this->AREA_CITY) {
				foreach ($pl as $p) {
					$aa = $this->getAreaSubList($p, $this->AREA_CITY);
					if (is_array($aa)) {
						$listid = array_merge($listid, $aa);
					}
				}
			} else if ($min == $this->AREA_REGION) {
				foreach ($pl as $p) {
					$cityid = $this->getAreaSubList($p, $this->AREA_CITY);
					foreach ($cityid as $c) {
						$aa = $this->getAreaSubList($c, $this->AREA_REGION);
						if (is_array($aa)) {
							$listid = array_merge($listid, $aa);
						}
					}
				}
			} else if ($min == $this->AREA_ZONE) {

				foreach ($pl as $p) {
					$cityid = $this->getAreaSubList($p, $this->AREA_CITY);
					foreach ($cityid as $c) {
						$regionid = $this->getAreaSubList($c, $this->AREA_REGION);
						foreach ($regionid as $r) {
							$aa = $this->getAreaSubList($r, $this->AREA_ZONE);
							if (is_array($aa)) {
								$listid = array_merge($listid, $aa);
							}
						}
					}
				}
			}
		}

		return $listid;
	}

	public  function getArea_recu($area_id)
	{
		static $area_name = '';
		$area_p = $this->field("id,title,parent_id")->where(array('id'=>intval($area_id)))->find();

		$area_name .= $area_p['title'].',';
		if($area_p['parent_id']){
			$this->getArea_recu($area_p['parent_id']);
		}
		
		return $area_name;
	}

	
}