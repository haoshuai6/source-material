<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/22
 */
namespace Common\Model;

use Common\BaseClass\StarfindModel;

class OrderModel extends StarfindModel
{

    public function createOrder($user, $trainer_id, $price, $shop, $address, $order_sn, $demo)
    {
        $data = array();
        $data['state_order'] = $this->Config("ORDER_STATE_WAITPAY");
        $data['sn_order'] = $order_sn;
        $data['trainer_id'] = $trainer_id;
        $data['title_trainer'] = $shop['name'];
        $data['demo'] = $demo;

        $data['buyer_id'] = $user['id'];
        $data['buyer_name'] = $user['username'];
        $data['buyer_mobile'] = $user['mobile'];
        $data['contact_truename'] = $address['contact_name'];
        $data['contact_mobile'] = $address['contact_mobile'];
        $data['contact_address1'] = $address['contact_address1'];
        $data['contact_address2'] = $address['contact_address2'];

        $data['amount_lesson'] = $price['lesson'];
        $data['amount_shipping'] = $price['shipping'];
        $data['amount_order'] = $price['shipping'] + $price['lesson'];
        $data['state_verify'] = $this->Config("ORDER_VERIFY_WAIT");

        $data['time_create'] = time();

        $oid = $this->add($data);
        if ($oid) {
            $orderlogmodel = new OrderLogModel();
            $orderlogmodel->addLog($oid, $this->Config("ORDER_STATE_CANCEL"), $this->Config("ORDER_STATE_WAITPAY"), $this->Config("ORDER_LOG_USER"), $user['id'], $user['username'], $demo, "创建订单");
        }
        return $oid;
    }


    public function changeOrderStatus($order_id, $state_old, $state_new, $orderdata, $role_class, $role_id = 0, $role_name = "", $demo = "", $message = "")
    {
        $con = array('id' => $order_id);
        $orderdata['state_order'] = $state_new;
        $r = $this->where($con)->save($orderdata);
        if ($r) {
            $orderlogmodel = new OrderLogModel();
            if (!$message) {
                $message = "改变订单状态";
            }
            $orderlogmodel->addLog($order_id, $state_old, $state_new, $role_class, $role_id, $role_name, $demo, $message);
        }
        return $r;
    }


    public function getOrder($order_id)
    {
        return $this->find($order_id);
    }
    
    public function getOrderBySn($ordersn){
       return $this->where(array('sn_order' => $ordersn))->find();
    }
    private function checkOrderSn($ordersn)
    {
        if ($this->where(array('sn_order' => $ordersn))->thinkfind()) {
            return true;
        } else {
            return false;
        }
    }

    private function checkPaySn($paysn)
    {
        $orderpaymodel = new OrderPayModel();
        if ($orderpaymodel->where(array('pay_sn' => $paysn))->thinkfind()) {
            return true;
        } else {
            return false;
        }

    }

    public function genPaySn($userid)
    {
        $retry = 5;

        $ul = strlen($userid);
        $randomlen = 9 - $ul;
        if ($randomlen >= 1) {
            $r = pow(10, ($randomlen - 1));
            $random = rand($r, (($r * 10) - 1));
        }

        $sn_order = "p" . date("YmdHis") . $random . $userid;

        while ($retry > 0) {
            if (!$this->checkPaySn($sn_order)) {
                return $sn_order;
            } else {
                $retry--;
            }
        }

        return false;
    }

    public function genOrderSn($userid)
    {
        $retry = 5;

        $ul = strlen($userid);
        $randomlen = 9 - $ul;
        if ($randomlen >= 1) {
            $r = pow(10, ($randomlen - 1));
            $random = rand($r, (($r * 10) - 1));
        }

        $sn_order = "o" . date("YmdHis") . $random . $userid;

        while ($retry > 0) {
            if (!$this->checkOrderSn($sn_order)) {
                return $sn_order;
            } else {
                $retry--;
            }
        }
        return false;
    }

    public function getOrderOpt($statuscode)
    {
        $order = array();
        switch ($statuscode) {
            case "0":
                $order['text']['ucenter'] = "已取消";
                $order['opt']['ucenter'] = array();
                break;
            case "10":
                $order['text']['ucenter'] = "待付款";
                $order['opt']['ucenter'] = array("cancel","topay");
                break;
            case "15":
                $order['text']['ucenter'] = "线下付款成功，等待确认";
                $order['opt']['ucenter'] = array("cancel");
                break;
            case "20":
                $order['text']['ucenter'] = "付款成功";
                $order['opt']['ucenter'] = array("cancel");
                break;
            case "30":
                $order['text']['ucenter'] = "已发货";
                $order['opt']['ucenter'] = array("cancel");
                break;
            case "40":
                $order['text']['ucenter'] = "已收货";
                $order['opt']['ucenter'] = array("finish");
                break;
            case "50":
                $order['text']['ucenter'] = "已完成";
                $order['opt']['ucenter'] = array("evaluate");
                break;
        }
        return $order;
    }

     public function getOrderstatus($statustext) {
         $st = -1;

         switch ($statustext) {
             case "all":
                 $st = -1;
                 break;
             case "cancel":
                 $st = 0;
                 break;
             case "waitpay":
                 $st = 10;
                 break;
             case "yetpay":
                 $st = '20';
                 break;
             case "yetpays":
                 $st = '15,20';
                 break;
             case "refund":
                 $st = 80;
                 break;
             case "finish":
                 $st = 50;
                 break;
             case "evaluate":
                 $st = 60;
                 break;
         }
         return $st;
     }
    public function getCountByState($state){
        $con = array();
        $con['state_order'] = array('in',"$state");
        return $this->where($con)->count();
    }

}