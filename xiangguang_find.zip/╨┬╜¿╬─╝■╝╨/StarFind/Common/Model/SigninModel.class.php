<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace  Common\Model;
use Common\BaseClass\StarfindModel;

class SigninModel extends StarfindModel
{

	public function addSignin($data){
		$array = array();
		$array['s_uid'] = $data['uid'];
		$array['s_time'] = $data['time'];
		$res = $this->add($array);
		return $res;
	}

	/**
	 * 增加积分，增加记录
	 */
	public function addPointBySign($param,$points,$day){
		$user_model = new UserModel();

		$userid = $param['uid'];
		$point = intval($points);
		$reason = '于'.$day.'签到,赠送'.$points.'积分';
		$role_id = $param['uid'];
		$role_name = $param['user_name'];
		$res_point = $user_model->addUserPoint($userid, $point, $reason, '', $role_id, $role_name, '');
        if($res_point){
			return true;
		}else {
			return false;
		}
	}

	/**
	 * check_sign
	 * @param $uid
	 * @param $date time()
	 * @return count
	 */
	public function check_user_sign($uid,$time){
		$con = array();
		$con['s_uid'] = $uid;
		$date = date('Y-m-d',$time);

		$day_start = strtotime($date.' '.'00:00:01');
		$day_end = strtotime($date.' '.'23:59:59');

		$con['s_time'] = array('between',"$day_start,$day_end");
		return $this->where($con)->count();
	}
}