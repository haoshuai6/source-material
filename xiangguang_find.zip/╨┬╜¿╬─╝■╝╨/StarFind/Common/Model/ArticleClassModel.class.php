<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace  Common\Model;
use Common\BaseClass\StarfindModel;

class ArticleClassModel extends StarfindModel
{
    private $articleclass;
    /**
     * @return mixed
     */
    public function getArticleclass()
    {
        return $this->articleclass;
    }

    /**
     * @param mixed $lessonclass
     */
    public function setArticleclass($articleclass)
    {
        $this->articleclass = $articleclass;
    }

    public function loadArticleClass($reload = false)
    {
        $c = array();
        $sc = S('ArticleClass');
        if ((!$sc) || ($reload)) {
            $ls = $this->field("id,keyword,value")->order('sort desc ,id asc')->select();
            if (($ls) && is_array($ls)) {

                foreach ($ls as $k => $v) {
                    $c[$v['keyword']] = $v['value'];
                }
            }
            S('ArticleClass', $c);
            $this->setArticleclass($c);
        }
        else {
            $this->setArticleclass($sc);
        }
        return $c;
    }

    public function getArticleClassInfo($articleclass_keyword)
    {
        $sc = $this->getArticleclass();

        if(empty($sc)){
            $this->loadArticleClass(true);
        }else{
            if ($sc[$articleclass_keyword]) {
                return $sc[$articleclass_keyword]['value'];
            }
        }

        return false;
    }

    public function getValByKey($key){
        $val = $this->where(array('keyword'=>trim($key)))->find();
        return $val;
    }

}