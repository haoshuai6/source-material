<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/23
 */

namespace Common\Model;

use Common\BaseClass\StarfindModel;

class OrderLogModel extends StarfindModel
{
	public function addLog($order_id, $state_old, $state_new, $role_class, $role_id , $role_name , $demo = "", $message = "")
	{
		$data = array();
		$data['order_id'] = $order_id;
		$data['state_from'] = $state_old;
		$data['state_to'] = $state_new;
		$data['role_class_id'] = $role_class;
        $data['role_id'] = $role_id;
        $data['role_name'] = $role_name;
		$data['message'] = $message;
		$data['demo'] = $demo;

		$logid = $this->add($data);
		return $logid;
	}


}