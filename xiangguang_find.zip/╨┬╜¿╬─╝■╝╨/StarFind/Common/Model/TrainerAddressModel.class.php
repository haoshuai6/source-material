<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace Common\Model;

use Common\BaseClass\StarfindredisModel;

class TrainerAddressModel extends StarfindredisModel
{

	/**
	 *
	 * 添加培训者地址 ， 同时更新培训地址redis
	 *
	 * @param $trainer_id
	 * @param $address
	 * @param $area_id
	 * @param $geo_lng
	 * @param $geo_lat
	 * @return bool|mixed 培训者地址id
	 */
	public function addTrainerAddress($trainer_id, $address, $area_id, $area_info,$geo_lng, $geo_lat)
	{
		$data = array();
		$data['title'] = $address;
		$data['trainer_id'] = $trainer_id;
		$data['area_id'] = $area_id;
		$data['area_info'] = $area_info;
		$data['geo_lng'] = $geo_lng;
		$data['geo_lat'] = $geo_lat;

		$address_id = $this->add($data);
		if ($address_id) {

		}
		return $address_id;
	}

	/**
	 * 更新培训者地址 ， 同时更新培训地址redis，更新课程地址redis
	 *
	 * @param $address_id
	 * @param $trainer_id
	 * @param $address
	 * @param $area_id
	 * @param $geo_lng
	 * @param $geo_lat
	 * @return bool
	 */
	public function updateTrainerAddress($address_id, $trainer_id, $address, $area_id, $area_info,$geo_lng, $geo_lat)
	{
		$data = array();
		$data['title'] = $address;
		$data['area_id'] = $area_id;
		$data['area_info'] = $area_info;
		$data['geo_lng'] = $geo_lng;
		$data['geo_lat'] = $geo_lat;

		$update_id = $this->where(array("id" => $address_id, "trainer_id" => $trainer_id))->save($data);
		if ($update_id) {

		}


		return $update_id;
	}

	/**
	 *
	 * 删除培训者地址， 更新培训地址redis，课程地址redis （使用前需要先判断是否有课程关联到此地址上。如有应拒绝执行！）
	 *
	 * @param $address_id
	 * @param $trainer_id
	 * @return mixed
	 */
	public function deleteTrainerAddress($address_id, $trainer_id)
	{
		// 课程
		$lessonaddressmodel = new LessonAddressModel();
		$laarray = $lessonaddressmodel->getLessonAddress($lessonaddressmodel, $trainer_id, $address_id);
		if (!$laarray) {
			$delete_id = $this->where(array("id" => $address_id, "trainer_id" => $trainer_id))->delete();
			if ($delete_id) {
				$lessonaddressmodel->delete(array('trainer_id' => $trainer_id, 'address_id' => $address_id));
			}
			return $delete_id;
		} else {
			return false;
		}
	}

	/**
	 * 获取地址课程对应数据
	 * @param $lessonadddressmodel
	 * @param $trainer_id
	 * @param $address_id
	 * @return mixed
	 */
	public function getLessonAddress($lessonadddressmodel, $trainer_id, $address_id)
	{
		$laarray = $lessonadddressmodel->where(array('trainer_id' => $trainer_id, 'address_id' => $address_id))->select();
		return $laarray;
	}

	public function getTrainerAdderss($trainer_id){
		$address_info = $this->table('__TRAINER_ADDRESS__')->where(array('trainer_id' => $trainer_id))->find();
		return $address_info;
	}

	public function getTrainerAddressList($trainer_ids){
		$address_list = $this->where(array('id'=>array('in',$trainer_ids)))->select();
		return $address_list;
	}
}