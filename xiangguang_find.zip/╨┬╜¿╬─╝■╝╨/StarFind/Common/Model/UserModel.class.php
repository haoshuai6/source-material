<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace Common\Model;

use Common\BaseClass\StarfindModel;

class UserModel extends StarfindModel
{

    public function getUserByMobile($mobile)
    {
        return $this->where(array('mobile' => $mobile))->find();
    }

    public function getUser($mobile)
    {
        return $this->where(array('mobile' => $mobile))->thinkfind();
    }


    public function getUserInfo($userid)
    {
        return $this->find($userid);
    }

    public function addUserByMobile($mobile, $invitecode = "")
    {
        $data = array();
        $data['mobile'] = $mobile;
        if ($invitecode) {
            $iu = $this->getUserByInviteCode($invitecode);
            if ($iu) {
                $data['invited_user_id'] = $iu['id'];
            }

            // todo 奖励邀请注册用户
        }

        $data['username'] = $this->Config("DEFAULT_USER_NAME");
        $data['avator'] = $this->Config("DEFAULT_USER_AVATOR");
        return $this->add($data);
    }


    public function updateUserLogin($uid)
    {
        $data = array();
        $data['loginnums'] = array('exp', 'loginnums+1');
        $data['lastlogin'] = time();
        $data['ipaddress'] = get_client_ip();
        return $this->where(array("id" => $uid))->save($data);
    }

    public function getUserByInviteCode($invitecode)
    {
        $invitecode = trim($invitecode);
        if ($invitecode) {
            return $this->where(array('invite_code' => $invitecode))->thinkfind();
        } else {
            return null;
        }
    }


    public function genInviteCode($openid, $userid)
    {
        $c = $userid . $openid . time() . rand(10000, 99999);
        $ck = true;
        $ic = "";
        while ($ck) {
            $ic = md5($c);
            if (!($this->where(array('invite_code' => $ic))->thinkfind())) {
                $ck = false;
            } else {
                $c = $userid . $openid . time() . rand(10000, 99999);
                $ck = true;
            }
        }
        return $ic;
    }


    public function addUserPoint($userid, $points, $reason, $role_class_id, $role_id, $role_name, $order_id)
    {
        $data = array();

        $data['point'] = array('exp', ' `point` +' .'('. $points .')');
        $r = $this->where(array('id' => $userid))->save($data);
        if ($r !== false) {
            $pointlogmodel = new PointLogModel();
            $rl = $pointlogmodel->addLog($userid, $points, $reason, $role_class_id, $role_id, $role_name, $order_id);
            return $rl;
        }
        return $r;
    }

    public function addUserVoucherNumbers($userid, $voucherNums)
    {
        $data = array();
        $data['voucher_nums'] = array('exp', 'voucher_nums+' . $voucherNums);
        return $this->where(array('id' => $userid))->save($data);
    }

    public  function updateUserByuid($uid,$parame){

        $data = array();
        $data['username'] = $parame['username'];
        $data['sex'] = $parame['sex'];
        $data['age'] = $parame['age'];
        if(!empty($parame['avator'])){
            $data['avator'] = $parame['avator'];
        }

        $data['want_class_id'] = $parame['want_class_id'];
        $data['trained'] = $parame['trained'];
        $data['area_id'] = $parame['area_id'];

        return $this->where(array("id" => $uid))->save($data);
    }
    /**
     * 处理积分兑换优惠券
     */
    public  function addVoucherByUserPoint($param,$points){
        if(is_array($param)){
            $voucher_user_model = new UserVoucherModel();
            $voucher_model = new VoucherModel();

            // 启动事务支持
            $this->startTrans();
            /*增加优惠券*/
            $data = array();
            $data['user_id'] = $param['user_id'];
            $data['voucher_id'] = $param['voucher_id'];
            $res = $voucher_user_model->addVoucher($data);

            /*增加用户优惠券数量*/
            $voucherNums = 1;
            $res_num = $this->addUserVoucherNumbers($param['user_id'], $voucherNums);

            /*增加优惠券发放数量*/
            $res_give = $voucher_model->addVoucherGivenum($param['voucher_id']);

            /*减去积分*/
            $userid = $param['user_id'];
            $point = '-'.intval($points);//负分
            $reason = '兑换优惠券减去相应积分';
            $role_id = $param['user_id'];
            $role_name = $param['user_name'];
            $res_point = $this->addUserPoint($userid, $point, $reason, '', $role_id, $role_name, '');

            //var_dump($res_point);

            if($res  && $res_num !==false && $res_give!==false && $res_point !==false){
                $this->commit();
                return true;
            }else{
                $this->rollback();
                return false;
            }

        }
    }
    public function checkInvite($uid){
        $uinfo = $this->where(array('id'=>$uid))->find();
        return $uinfo;
    }
    public function updateInviteByid($code,$uid){
        return $this->where(array('id' => $uid))->save(array('invite_code'=>$code));
    }
}