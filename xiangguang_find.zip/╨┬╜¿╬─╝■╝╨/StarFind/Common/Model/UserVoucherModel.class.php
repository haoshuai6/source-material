<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/25
 */
namespace Common\Model;

use Common\BaseClass\StarfindModel;

class UserVoucherModel extends StarfindModel
{

    /**
     * 获取单一用户优惠券列表，根据 金额倒序，结束时间正序
     *
     * @param $user_id              用户id
     * @param bool $now 只显示当前时间可用的
     * @param int $trainerid 只显示 系统和当前培训者 的
     * @param int $voucher_state 优惠券状态
     * @return mixed
     */
    public function getUserVoucherList($user_id, $now = true, $trainerid = 0, $voucher_state = 99)
    {
        $con = array();
        $con['uv.user_id'] = $user_id;

        if ($voucher_state != 99) {
            $con["uv.voucher_state"] = $voucher_state;
        }
        $con['uv.state'] = $this->Config("STATE_OK");
        $con['v.state'] = $this->Config("STATE_OK");
        $con['uv.voucher_id'] = array('eq', array('exp', "v.id"));

        $table = "__USER_VOUCHER__ as uv , __VOUCHER__ as v";

        if ($now) {
            $time = time();
            $con['v.use_starttime'] = array('elt', $time);
            $con['v.use_endtime'] = array('egt', $time);
        }

        if ($trainerid) {
            $con['v.trainer_id'] = array('in', array($trainerid, 0));
        }

        $field = "uv.id , v.voucher_class_id, v.trainer_id , v.trainer_title, v.lesson_class_id ,v.title , v.amount ,v.pricelimit , v.points, v.use_starttime, v.use_endtime";

        $vlist = $this->field($field)->where($con)->table($table)->order("v.amount desc , v.use_endtime asc")->thinkselect();
        //var_dump($this->getLastSql());
        return $vlist;
    }


    // 优惠券标记为已使用
    public function setUserVoucherUsed($user_voucher_id, $user_id, $order_id)
    {
        $con = array();
        $con['id'] = $user_voucher_id;
        $con['user_id'] = $user_id;

        $v = $this->where($con)->find();
        if (!$v) {
            return false;
        }


        $data = array();
        $data['voucher_state'] = $this->Config("VOUCHER_STATE_USED");
        $data['order_id'] = $order_id;
        $data['used_time'] = time();

        $r = $this->where($con)->save($data);
        if ($r) {
            // 增加优惠券使用量
            $vouchermodel = new VoucherModel();
            $vouchermodel->addVoucherUsedNum($v['voucher_id']);
        }
        return $r;
    }

    // 恢复优惠券
    public function setUserVoucherUnused($user_voucher_id, $user_id)
    {
        $con = array();
        $con['id'] = $user_voucher_id;
        $con['user_id'] = $user_id;

        $v = $this->where($con)->find();
        if (!$v) {
            return false;
        }

        $data = array();
        $data['voucher_state'] = $this->Config("VOUCHER_STATE_OK");
        $data['order_id'] = 0;
        $data['used_time'] = 0;

        $r = $this->where($con)->save($data);
        if ($r) {
            // 减少优惠券使用量
            $vouchermodel = new VoucherModel();
            $vouchermodel->addVoucherUsedNum($v['voucher_id'], -1);
        }
        return $r;
    }
    public  function  getVoucherByUid($uid){
        $con = array();
        $con_tra = array();
        $con['user_id'] = $uid;
        $Voucher_list = $this->where($con)->order('createtime desc')->select();
        if($Voucher_list && is_array($Voucher_list)){
            foreach ($Voucher_list as $k => $v_list){
                $con_tra['state'] = $this->Config("STATE_OK");
                $con_tra['id'] = $v_list['voucher_id'];
                $vou_list = $this->table('__VOUCHER__')->where($con_tra)->order('createtime desc')->select();
                $Voucher_list[$k]['vou_info'] = $vou_list;
            }
        }

        return $Voucher_list;
    }

    /*检测领取张数*/
    public function checkVoucherByUidVid($uid,$vid){

        $con = array();
        $con['user_id'] = $uid;
        $con['voucher_id'] = $vid;
        $voucher_count = $this->where($con)->count();
        return $voucher_count;
    }

    /**
     * 增加优惠券
     */
    public function addVoucher($pama){
        $data = array();
        $data['updatetime'] = time();
        $data['createtime'] = time();
        $data['operator'] = $pama['user_id'];
        $data['user_id'] = $pama['user_id'];
        $data['voucher_id'] = $pama['voucher_id'];
        $data['voucher_state'] = 0;
        $res = $this->add($data);
        return $res;
    }
}