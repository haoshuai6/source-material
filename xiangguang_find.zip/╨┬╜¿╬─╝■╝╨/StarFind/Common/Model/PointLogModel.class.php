<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/24
 */

namespace Common\Model;

use Common\BaseClass\StarfindModel;

class PointLogModel extends StarfindModel
{
    public function addLog($userid, $point_num, $reason, $role_class_id, $role_id, $role_name , $order_id = 0)
    {
        return $this->add(array(
            "user_id" => $userid,
            "point_num" => $point_num,
            "reason" => $reason,
            "role_class_id" => $role_class_id,
            "role_id" => $role_id,
            "role_name" => $role_name,
            "order_id" => $order_id,
        ));
    }
}