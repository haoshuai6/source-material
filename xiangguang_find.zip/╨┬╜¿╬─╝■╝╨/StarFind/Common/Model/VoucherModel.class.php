<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/30
 */

namespace Common\Model;

use Common\BaseClass\StarfindModel;

class VoucherModel extends StarfindModel
{
    public function addVoucherUsedNum($voucher_id, $nums = 1)
    {
        $data = array();
        $data['used'] = array('exp', 'used' + $nums);

        $con = array();
        $con['id'] = $voucher_id;

        return $this->where($con)->save($data);
    }

    /**
     * add已经发放数量
     * @param $voucher_id
     * @param int $nums
     * @return bool
     */
    public function  addVoucherGivenum($voucher_id, $nums = 1){
        $data = array();
        $data['giveout'] = array('exp', 'giveout+'.$nums);
        $con = array();
        $con['id'] = $voucher_id;

        return $this->where($con)->save($data);
    }
    public function getVoucherByid($voucher_id){
        $con = array();
        $con['id'] = $voucher_id;
        $voucher_info = $this->where($con)->find();
        return $voucher_info;
    }
    /*优惠券列表*/
    public function getVoucherList(){
        $con_tra['state'] = $this->Config("STATE_OK");
        $vou_list = $this->where($con_tra)->order('createtime desc')->select();
        return $vou_list;
    }
    public function getVoucherType($value){
        $con['state'] = $this->Config("STATE_OK");
        $con['value'] = intval($value);
        $Type = $this->table('__VOUCHAR_CLASS__')->where($con)->find();
        return $Type;
    }

}