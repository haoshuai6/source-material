<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/16
 */

namespace Common\Model;

use Common\BaseClass\StarfindModel;

class TrainerSignupModel extends StarfindModel
{
	public function getTrainerSignupByWeChatId($openid)
	{
		return $this->where(array('wx_openid' => $openid))->thinkfind();
	}

}