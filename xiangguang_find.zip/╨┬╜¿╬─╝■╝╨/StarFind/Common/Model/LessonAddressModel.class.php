<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace Common\Model;

use Common\BaseClass\StarfindredisModel;
use Common\Model\TrainerAddressModel;

class LessonAddressModel extends StarfindredisModel
{
	/**
	 *
	 * 添加课程地址，同时添加课程redis
	 *
	 * @param $trainer_id
	 * @param $address_id
	 * @param $lesson_id
	 * @return bool|mixed
	 */
	public function addTrainerLessonAddress($trainer_id, $address_id, $lesson_id)
	{
		$data = array();
		$data['trainer_id'] = $trainer_id;
		$data['lesson_id'] = $lesson_id;
		$data['address_id'] = $address_id;

		$r_id = $this->add($data);
		if ($r_id) {
		}
		return $r_id;
	}

	/**
	 * 添加课程redis
	 *
	 * @param $trainer_id
	 * @param $address_id
	 * @param $lessonaddress_id
	 */
	public function addLessonGeo($trainer_id, $address_id, $lessonaddress_id)
	{
		$ta = $this->getTrainerAddress($trainer_id, $address_id);
		if ($ta) {

		}
	}

	/**
	 * 根据培训者地址id，获取课程地址数据
	 *
	 * @param $trainer_id
	 * @param $address_id
	 * @return mixed
	 */
	public function getTrainerAddress($trainer_id, $address_id)
	{
		$trainer_address_model = new TrainerAddressModel();
		return $trainer_address_model->where(array('id' => $address_id, 'trainer_id' => $trainer_id))->find();
	}

	/**
	 * 删除课程地址，同时删除课程redis
	 *
	 * @param $trainer_id
	 * @param $lesson_id
	 * @return bool|mixed
	 */
	public function rmLessonAddress($trainer_id, $lesson_id)
	{
		// 删除课程geo地址
		$laarray = $this->getLessonAddress($trainer_id, $lesson_id);
		// 删除课程数据库地址
		return $this->delete(array('trainer_id' => $trainer_id, 'lesson_id' => $lesson_id));
	}

	/**
	 * 根据课程地址id， 获取课程地址数据
	 *
	 * @param $trainer_id
	 * @param $address_id
	 * @return mixed
	 */
	public function getLessonAddress($lesson_id)
	{
		$laarray = $this->field('address_id')->where(array('lesson_id' => $lesson_id))->select();

		$addressIds = array();

		if(!empty($laarray) && is_array($laarray)){
			foreach($laarray as $v){
				$addressIds[] = $v['address_id'];
			}
		}
		return $addressIds;
	}
}