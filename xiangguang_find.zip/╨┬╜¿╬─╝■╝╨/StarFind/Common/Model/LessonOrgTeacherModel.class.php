<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/24
 */
namespace Common\Model;

use Common\BaseClass\StarfindModel;

class LessonOrgTeacherModel extends StarfindModel
{

	public function getTeacherArrayByLessonId($lesson_id)
	{
		$ta = array();
		$r = $this->field("org_teacher_id")->where(array('lesson_id' => $lesson_id))->select();
		if (($r) && is_array($r)) {

			foreach ($r as $k => $t) {
				$ta[] = $t['org_teacher_id'];
			}
		}

		return $ta;
	}
	public function getLessonArrayByTeacherId($teacher_id)
	{
		$le = array();
		$r = $this->field("lesson_id")->where(array('org_teacher_id' => intval($teacher_id)))->select();
		if (($r) && is_array($r)) {
			foreach ($r as $k => $t) {
				$le[] = $t['lesson_id'];
			}
		}
		return $le;
	}

	public function addTrainerOrgTeacher($lesson_id,$org_teacher_id)
	{
		$data = array();
		$data['lesson_id'] = $lesson_id;
		$data['org_teacher_id'] = $org_teacher_id;

		$r_id = $this->add($data);
		if ($r_id) {
		}
		return $r_id;
	}
	
}