<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/18
 */

namespace Common\Model;

use Common\BaseClass\StarfindModel;

class SmsModel extends StarfindModel
{

	public function getCountByMobile($mobile)
	{
		$con = array();
		$con['mobile'] = $mobile;
		$con['createtime'] = $this->getTodayStartTime();

		return $this->where($con)->count();
	}

	public function getCountByIP($ip)
	{
		$con = array();
		$con['ipaddress'] = $ip;
		$con['createtime'] = $this->getTodayStartTime();
		return $this->where($con)->count();
	}

	private function getTodayStartTime()
	{
		return mktime(0, 0, 0, date('m'), date('d'), date('Y'));
	}


	public function addSms($mobile, $code, $ip, $type, $message = "")
	{
		$data = array();
		$data['mobile'] = $mobile;
		$data['code'] = $code;
		$data['ipaddress'] = $ip;
		$data['sms_type_id'] = $type;
		$data['message'] = $message;
		$r = $this->add($data);
		return $r;
	}

	public function getLastSms($mobile, $type)
	{
		$con = array();
		$con['mobile'] = $mobile;
		$con['sms_type_id'] = $type;

		return $this->where($con)->order("id desc")->find();
	}

	public function getSms($mobile, $type, $code, $expiredtime)
	{
		$con = array();
		$con['mobile'] = $mobile;
		$con['sms_type_id'] = $type;
		if ($this->Config("DEBUG_WECHAT")) {
			$con['state'] = array('in', array(-1, 1));
		} else {
			$con['code'] = $code;
		}
		$con['createtime'] = array('egt', $expiredtime);

		return $this->where($con)->order("id desc")->find();
	}

	public function deleteSms($smsid)
	{
		return $this->delete($smsid);
	}

	// 检查短信验证码是否正确
	public function checkSms($mobile, $type, $code, $expiredtime)
	{
		$sms = false;
		$smsid = $this->getSms($mobile, $type, $code, $expiredtime);
		if ($smsid) {
			//标记为过期
			$this->deleteSms($smsid['id']);
			$sms = true;
		} else {
			$sms = false;
		}

		return $sms;
	}


}