<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/22
 */

namespace Common\Model;

use Common\BaseClass\StarfindModel;

class OrderLessonModel extends StarfindModel
{
	public function createOrderLesson($order_id, $order_lesson_array)
	{
		$data = array();

		if (($order_lesson_array) && is_array($order_lesson_array)) {

			foreach ($order_lesson_array as $lesson_id => $lesson) {

				$l = array();
				$l['order_id'] = $order_id;
				$l['lesson_id'] = $lesson_id;
				$l['buy_numbers'] = $lesson['nums'];

				$l['title'] = $lesson['name'];
				$l['image'] = $lesson['image'];
				$l['price'] = $lesson['price'];
				$l['lesson_nums'] = $lesson['lesson_nums'];

				$data[] = $l;
			}
		}

		if ($data) {
			$r = $this->addAll($data);
			return $r;
		} else {
			return false;
		}
	}

	public function getCountByLessonID($userid , $lesson_id_array)
	{
		$con = array();
		$con['od.buyer_id'] = $userid;
		$con['lesson.lesson_id'] = array('in', $lesson_id_array);
		$con['od.id'] = array('eq', array('exp', "lesson.order_id"));
		$con['od.state_order']= array('neq' , $this->Config("ORDER_STATE_CANCEL"));
		$con['lesson.state'] = $this->Config("STATE_OK");
		$con['od.state'] = $this->Config("STATE_OK");

		$field = "lesson.`lesson_id`, SUM(lesson.buy_numbers) AS c";
		$r = $this->field($field)->table("__ORDER_LESSON__ as lesson , __ORDER__ as od")->where($con)->thinkselect();
		return $r;
	}

	public function getLessonArrayByOrderID($order_id)
	{
		return $this->where(array('order_id'=>$order_id))->select();
	}

	public function getLessonByUid($userid,$state_order)
	{
		$con = array();
		$l_con = array();
		$order_info = array();
		$order_lesson_info = array();

		$con['state_order'] = array('in',"$state_order");
		$con['buyer_id'] = $userid;
		$con['state'] = $this->Config("STATE_OK");
		$order_fild = "id,state,createtime,state_order,state_verify,trainer_id,title_trainer,buyer_id,buyer_name,buyer_mobile,amount_lesson,amount_order,time_create";
		$order_info = $this->field($order_fild)->table('__ORDER__')->where($con)->order('time_create desc')->select();

        if($order_info && is_array($order_info)){
			foreach ($order_info as $k => $or_list){
				$l_con['order_id'] = $or_list['id'];
				$order_lesson_info = $this->table('__ORDER_LESSON__')->where($l_con)->select();
				$order_info[$k]['order_lesson'] = $order_lesson_info;
			}
		}

		$getTrainer = new TrainerModel();
		if($order_info && is_array($order_info)){
			foreach ($order_info as $m => $m_list){
				 $trainer_info = $getTrainer->getTrainer($m_list['trainer_id']);
				 $order_info[$m]['trainer_info'] = $trainer_info;
				if($m_list['order_lesson'] && is_array($m_list['order_lesson'])){
					foreach ($m_list['order_lesson'] as $l => $l_list){
						$order_info[$m]['less_nums_sum'] += floatval( $l_list['lesson_nums'] );
					}
				}
			}
        }
	
		return $order_info;
	}
	public function getLessonByOrderid($Orderid)
	{
		$l_con['order_id'] = $Orderid;
		$order_lesson_info = $this->table('__ORDER_LESSON__')->where($l_con)->select();
		return $order_lesson_info;
	}
}