<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace Common\Model;

use Common\BaseClass\StarfindModel;

class LessonModel extends StarfindModel
{
	public function addLesson($lesson_class_id, $trainer_id, $name, $cover_image, $price, $lesson_nums = 1, $price_market = 0.00, $buy_point = 0, $buy_voucher = 1, $canpayoffline = 1)
	{
		$data = array();
		$data['lesson_class_id'] = $lesson_class_id;
		$data['title'] = $name;
		$data['trainer_id'] = $trainer_id;
		$data['image'] = $cover_image;
		$data['price'] = $price;
		$data['price_market'] = $price_market;
		$data['lesson_nums'] = $lesson_nums;
		$data['buy_point'] = $buy_point;
		$data['buy_voucher'] = $buy_voucher;
		$data['canpayoffline'] = $canpayoffline;

		$lesson_id = $this->add($data);
		return $lesson_id;
	}


	public function getLesson($lesson_id)
	{
		return $this->find($lesson_id);
	}

	public function getLessonArrayByLessonIDArray($lesson_id_array)
	{
		return $this->where(array('id' => array('in', $lesson_id_array)))->select();
	}
	public function getLessonArrayByLessonIDArrayJP($lesson_id_array)
	{
		return $this->where(array('id' => array('in', $lesson_id_array)))->order('evaluate_score desc')->limit(2)->select();
	}

	public function getLessonWithTrainer($lesson_id_array)
	{
		$con = array();
		$con['lesson.id'] = array('in', $lesson_id_array);
		$con['lesson.state'] = $this->Config("STATE_OK");
		$con['trainer.state'] = $this->Config("STATE_OK");
		$con['trainer.id'] = array('eq', array('exp', "lesson.trainer_id"));


		$field = "trainer.mobile , trainer.title as trainer_title , trainer.id as trainer_id , trainer.avator , lesson.title as lesson_title ,lesson_class_id ,image, price, maxbuy_nums , lesson_nums ,lesson.id as lesson_id";

		$r = $this->field($field)->table("__LESSON__ as lesson , __TRAINER__ as trainer")->where($con)->thinkselect();

		return $r;
	}

	public function getOrgLessonTeacher($lesson_id)
	{
		$lotmodel = new LessonOrgTeacherModel();
		$ot = $lotmodel->getTeacherArrayByLessonId($lesson_id);
		if ($ot) {
			$otmodel = new OrgTeacherModel();
			return $otmodel->getTeacherInfo($ot);
		} else {
			return null;
		}
	}
}