<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace  Common\Model;
use Common\BaseClass\StarfindModel;

class EvaluateModel extends StarfindModel
{

	public function getCountEvalByLevel($uid,$level=0){
		/*$level=0，全部*/
		$con['user_id'] = intval($uid);
		$con['state'] = $this->Config("STATE_OK");
		if($level){
			$con['evaluate_score'] = intval($level);
		}
		$eval_count = $this->where($con)->count();
		return $eval_count;
	}
	public function getEvalByLevel($uid,$level=0){
		$con['user_id'] = intval($uid);
		$con['state'] = $this->Config("STATE_OK");
		if($level){
			$con['evaluate_score'] = intval($level);
		}
		$eval_list= $this->where($con)->select();
		return $eval_list;
	}
	public  function getTagEvaluateByscore($data){
		$con  = array();
		$con['score'] = intval($data['score']);
		$con['type_id'] = intval($data['type_id']);

		$Tag_list = $this->table('__EVALUATE_TAG__')->where($con)->select();
		return $Tag_list;
	}
	public  function getTagEvaluate(){
		$Tag_list = $this->table('__EVALUATE_TAG__')->select();
		return $Tag_list;
	}
	public  function getTagEvaluateByid($id){
		$con = array();
		$con['state'] = $this->Config("STATE_OK");
		$con['id'] = array('eq',$id);
		$Tag_list = $this->table('__EVALUATE_TAG__')->where($con)->find();
		return $Tag_list;
	}

	public  function getTagEvaluateGroup(){
		$having = 'state = 1' ;
		$source_num = $this->field('id,state,score')->table('__EVALUATE_TAG__')->group('score')->having($having)->select();
		return $source_num;
	}
	public function addEvaluate($data = array()){
		$add_array = array();
		$add_array['operator'] =  $data['operator'];
		$add_array['trainer_id'] = $data['trainer_id'];
		$add_array['user_id'] = $data['user_id'];
		$add_array['user_name'] = $data['user_name'];
		$add_array['user_avator'] = $data['user_avator'];
		$add_array['order_id'] = $data['order_id'];
		$add_array['lesson_id'] = $data['lesson_id'];
		$add_array['lesson_name'] = $data['lesson_name'];
		$add_array['score_trainer'] = $data['score_trainer'];
		$add_array['score_teacher'] = $data['score_teacher'];
		$add_array['score_tags'] = $data['score_tags'];
		$add_array['evaluate_score'] = $data['evaluate_score'];
		$add_array['evaluate'] = $data['evaluate'];
		$res = $this->table('__EVALUATE__')->add($add_array);
		return $res;
	}

}