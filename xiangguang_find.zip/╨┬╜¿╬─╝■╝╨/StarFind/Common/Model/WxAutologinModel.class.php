<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/19
 */

namespace Common\Model;

use Common\BaseClass\StarfindModel;

class WxAutologinModel extends StarfindModel
{
	public function getWxUser($wx_openid, $from)
	{
		$wxid = 0;
		$lastmobile = "";

		$wxuser = $this->where(array('wx_openid' => $wx_openid))->order("updatetime desc, id desc")->find();
		if ($wxuser) {
			$wxid = $wxuser['id'];
			if ($wxuser['mobile']) {

				// 自动登陆时间？
				if ($wxuser['updatetime'] >= (time() - ($this->Config("AUTOLOGIN_MAX_DAY") * 3600))) {
					$lastmobile = $wxuser['mobile'];
				}
			}

			$data = array();
			$data['ipaddress'] = get_client_ip();
			if ($from) {
				$data['from'] = $from;
			}

			$this->where(array('id' => $wxid))->save($data);
		} else {
			$wxid = $this->add(array('wx_openid' => $wx_openid, 'ipaddress' => get_client_ip(), 'from' => $from));
		}

		return array('wxid' => $wxid, 'mobile' => $lastmobile);
	}


	public function updateWxUser($uid, $mobile)
	{
		$data = array();
		$data['updatetime'] = time();
		$data['mobile'] = $mobile;
		return $this->where(array('id' => $uid))->save($data);
	}

	public function saveWxUser($uid, $mobile)
	{
		$data = array();
		$data['mobile'] = $mobile;
		return $this->where(array('id' => $uid))->save($data);
	}

	public function deleteWxUser($uid)
	{
		return $this->where(array('id' => $uid))->delete();

	}
}