<?php
return array(
	'DEFAULT_CHARSET' => 'utf-8',
	'URL_MODEL'=>1,
	'URL_HTML_SUFFIX' => "",

	'SHOW_PAGE_TRACE' => true,
	'MODULE_ALLOW_LIST' => array('Home','User','Trainer','Test'),
	'DEFAULT_MODULE' => 'Home',  // 默认模块

	'COOKIE_PREFIX' => 'STARFIND_',      // Cookie前缀 避免冲突
	'SESSION_PREFIX' => 'STARFIND', // session 前缀

	'DB_PREFIX' => 'starsearch_',
	'DB_TYPE' => 'MYSQL',     // 数据库类型
	'DB_HOST' => '192.168.1.199', // 服务器地址
	'DB_NAME' => '2016_11_xingguang_find',          // 数据库名
	'DB_USER' => 'xingguang',      // 用户名
	'DB_PWD' => 'xingguang',          // 密码


	'REDIS_IP' => '192.168.1.199',
	'REDIS_PORT' => '6379',
	'REDIS_DB' => 0,
	'REDIS_PREFIX' => 'starfind:',


	'LAYOUT_ON' => true,
    'LAYOUT_NAME' => '../../Common/Layout/starfind_layout',
	'TMPL_ACTION_ERROR' => '../../Common/Layout/error_jump',
	'TMPL_ACTION_SUCCESS' => '../../Common/Layout/success_jump',
);