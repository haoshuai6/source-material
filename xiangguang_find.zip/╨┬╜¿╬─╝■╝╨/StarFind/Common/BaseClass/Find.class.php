<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/10
 */
namespace Common\BaseClass;

use Common\Model\AreaModel;
use Common\Model\LessonClassModel;
use Respect\Validation\Validator as v;
use Think\Model;
use JasonGrimes\Paginator;
use Predis;

Class Find
{
	private $configs;

	private $redis;

	/**
	 * @return Predis\Client
	 */
	public function getRedis()
	{
		return $this->redis;
	}

	/**
	 * @param Predis\Client $redis
	 */
	public function setRedis($redis)
	{
		$this->redis = $redis;
	}


	public function __construct($config)
	{
		$this->setConfigs($config);
		$this->setRedis(new Predis\Client(array(
			'host' => C('REDIS_IP'),
			'port' => C('REDIS_PORT'),
			'database' => C('REDIS_DB'),
		), array('prefix' => C('REDIS_PREFIX'))));
	}

	/**
	 * @return mixed
	 */
	public function getConfigs()
	{
		return $this->configs;
	}

	/**
	 * @param mixed $config
	 */
	public function setConfigs($config)
	{
		$this->configs = $config;
	}

	public function getConfig($configVal)
	{
		$c = $this->getConfigs();
		return $c[$configVal];
	}


	public function find($user_geo_lng = 0, $user_geo_lat = 0, $find_type = 1, $trainer_class_id = 0, $area_id = 0, $lesson_class_id = 0, $search = "", $order = 0, $page = 1, $prepagenum = 0, $distince = 150)
	{

		$var = $this->init_var($user_geo_lng, $user_geo_lat, $find_type, $trainer_class_id, $area_id, $lesson_class_id, $search, $order, $page, $prepagenum, $distince);
		$redis = $this->getRedis();
		$redisstring = $this->getRedisString($var);

		$total = 0;
		$nums = $redis->get($redisstring['total_redis_geo']);
		if ($nums) {
			$total = $nums;

		} else {

			$var = $this->getFindData($var);
			$paginator = $var['data']["paginator"];
			$total = $paginator->getTotalItems();

			//设置redis
			$pipe = $redis->pipeline();
			$redis->set($redisstring['total_redis_geo'], $total);
			$redis->expire($redisstring['total_redis_geo'], $this->getConfig("REDIS_FIND_EXPIRED"));

			if ($var['data']['geolist']) {
				foreach ($var['data']['geolist'] as $geo) {
					$redis->geoadd($redisstring['redis_geo'], $geo['geo_lng'], $geo['geo_lat'], $geo['id']);
				}
			}
			$redis->expire($redisstring['redis_geo'], $this->getConfig("REDIS_FIND_EXPIRED"));
			$replies = $pipe->execute();

		}

		//分页信息
		if (!$var['data']["paginator"]) {
			$paginator = new Paginator($total, $var['prepagenum'], $var['page'], '');
			if (!((v::between(1, $paginator->getNumPages())->validate($var['page'])))) {
				$var['page'] = 1;
			}

			$var['data']['paginator'] = $paginator;
		}


		$distincelist = array();
		if ($var['orderby']) {
			$distincelist = $redis->georadius($redisstring['redis_geo'], $var['user_geo_lng'], $var['user_geo_lat'], $var['distince'], "km", array("WITHDIST" => true, "SORT" => "ASC"));
		} else {
			$distincelist = $redis->georadius($redisstring['redis_geo'], $var['user_geo_lng'], $var['user_geo_lat'], $var['distince'], "km", array("WITHDIST" => true, "SORT" => "ASC", "COUNT" => ($var['page'] * $var['prepagenum'])));
			//按照页码切割数组
			$alist = array_slice($distincelist, (($var['page'] - 1) * $var['prepagenum']), $var['prepagenum']);
			$distincelist = $alist;
		}

		// list
		$geolist = array();
		if ($var['data']['geolist']) {
			$geolist = $var['data']['geolist'];
		}
		if (!$var['ext_field']) {
			$geolist = array();
		}

		$var['data']['list'] = $this->getFindList($var, $distincelist, $geolist);

		return $var;
	}


	private function init_var($user_geo_lng = 0, $user_geo_lat = 0, $find_type = 1, $trainer_class_id = 0, $area_id = 0, $lesson_class_id = 0, $search = "", $order = 0, $page = 1, $prepagenum = 0, $distince = 150)
	{

		// 初始化参数

		if (!$prepagenum) {
			$prepagenum = $this->getConfig("PAGE_PRE_NUMS");
			if (!$prepagenum) {
				$prepagenum = 10;
			}
		}

		if (!$page) {
			$page = 1;
		}

		if (!$distince) {
			$distince = $this->getConfig("REDIS_FIND_MAX_DISTINCE");
			if (!$distince) {
				$distince = 150;
			}
		}

		if ((!$user_geo_lat) || (!$user_geo_lng)) {
			$model_area = new AreaModel();
			$model_area->loadArea();
			$area = $model_area->getAreaInfo("370100");
			if ($area) {
				$user_geo_lng = $area['geo_lng'];
				$user_geo_lat = $area['geo_lat'];
			}
		}

		$e = new Error();
		// find_type 1培训者 2课程
		if (($e->checkResult()) && (v::in([$this->getConfig("FINDTYPE_TRAINER"), $this->getConfig("FINDTYPE_LESSON")])->validate($find_type))) {

		} else {
			//$e->setError(1, "查找类型不匹配");
			$find_type = $this->getConfig("FINDTYPE_TRAINER");
		}

		if (($e->checkResult()) && (v::in([0, $this->getConfig("CLASS_TRAINER_ORGANIZATION"), $this->getConfig("CLASS_TRAINER_PERSON")])->validate($trainer_class_id))) {

		} else {
			//$e->setError(1, "培训者类型不匹配");
			$trainer_class_id = $this->getConfig("CLASS_TRAINER_ORGANIZATION");
		}

		$area_array = array();
		if ($area_id) {
			$am = new AreaModel();
			$am->loadArea();
			$arealist = ($am->getAreaSubList($area_id, $am->AREA_REGION));
			if ($arealist) {
				$area_array = $arealist;
			}
		}

		if ($area_array) {
			if (($e->checkResult()) && (v::in($area_array)->validate($area_id))) {

			} else {
				//$e->setError(1, "区域不匹配");
				$area_id = 0;
			}
		}

		$lesson_array = array();
		if ($lesson_class_id) {
			$lcmodel = new LessonClassModel();
			$lc = $lcmodel->loadLessonClass();
			$lesson_array = $lcmodel->getLessonClassSubList($lesson_class_id);
		}

		if (!$lesson_array) {
			//$e->setError(1, "课程类型不匹配");
			$lesson_class_id = 0;
		}

		// format orderby
		$order_array = array(
			"",
			"trainer.evaluate_score desc ",
			"trainer.evaluate_nums desc ",
			"lesson.price asc ",
			"lesson.price desc "
		);


		// 必须是课程才能按照价格排序
		if (($order == 3) || ($order == 4)) {
			if ($find_type == $this->getConfig("FINDTYPE_TRAINER")) {
				$order = 0;
			}
		}


		$orderby = "";
		if ($order_array) {
			if (($e->checkResult()) && (v::between(0, (count($order_array) - 1))->validate($order))) {
				$orderby = $order_array[$order];

			} else {
				//$e->setError(1, "课程类型不匹配");
				$orderby = "";
				$order = 0;
			}
		}


		return array(
			"user_geo_lng" => $user_geo_lng,
			"user_geo_lat" => $user_geo_lat,
			"find_type" => $find_type,
			"trainer_class_id" => $trainer_class_id,
			"area_array" => $area_array,
			"area_id" => $area_id,
			"lesson_class_array" => $lesson_array,
			"lesson_class_id" => $lesson_class_id,
			"search" => $search,
			"orderby" => $orderby,
			"order" => $order,
			"page" => $page,
			"prepagenum" => $prepagenum,
			"distince" => $distince
		);
	}


	private function getFindData($var, $ids = array())
	{
		$model = new Model();

		$tables = array(
			C('DB_PREFIX') . "trainer_address" => "address",
			C('DB_PREFIX') . "trainer" => "trainer",
			C('DB_PREFIX') . "lesson" => "lesson"
		);

		$con = array();
		$con['trainer.state'] = $this->getConfig("STATE_OK");
		$con['address.state'] = $this->getConfig("STATE_OK");

		$group = "address.id";

		$count = "distinct(" . $group . ")";

		if (!$ids) {
			if ($var['trainer_class_id']) {
				$con['trainer.trainer_classid'] = $var['trainer_class_id'];
			}

			if ($var['area_array']) {
				$con['address.area_id'] = array("in", $var['area_array']);
			}

			if ($var['lesson_class_array']) {
				$con['lesson.lesson_class_id'] = array("in", $var['lesson_class_array']);
			}
		} else {

			if ($var['find_type'] == $this->getConfig("FINDTYPE_LESSON")) {
				$con['lessonaddress.id'] = array('in', $ids);
			} else {
				$con['address.id'] = array('in', $ids);
			}
		}

		// field
		$field = "address.id , address.geo_lng , address.geo_lat";

		// 课程补充
		if ($var['find_type'] == $this->getConfig("FINDTYPE_LESSON")) {

			$tables[C('DB_PREFIX') . "lesson_address"] = "lessonaddress";

			$con['lesson.state'] = $this->getConfig("STATE_OK");
			$con['lessonAddress.state'] = $this->getConfig("STATE_OK");

			$sql = " lessonaddress.lesson_id = lesson.id And lessonaddress.address_id=address.id And lessonaddress.trainer_id=trainer.id ";

			$group = "";

			$count = "*";

			$field = "lessonaddress.id , address.geo_lng , address.geo_lat ";


		} else {
			$sql = " trainer.id=address.trainer_id and lesson.trainer_id = trainer.id ";
		}

		if (!$ids) {
			if ($var["search"]) {
				if ($var['find_type'] == $this->getConfig("FINDTYPE_TRAINER")) {
					$sql .= " And ( trainer.title like '%" . $var["search"] . "%' OR address.title like '%" . $var["search"] . "%') ";
				} else {
					$sql .= " And ( lesson.title like '%" . $var["search"] . "%') ";
				}
			}
		}

		$ext_field = false;

		if (($var['orderby']) || ($ids)) {

			if ($var['find_type'] == $this->getConfig("FINDTYPE_TRAINER")) {
				$field .= " ,trainer.avator , trainer.image,trainer.title as trainertitle , trainer.demo , trainer.evaluate_nums , trainer.evaluate_score ,trainer.id as trainerid, trainer.trainer_classid ";
			} else {
				$field .= " ,lesson.image , lesson.title as lessontitle , lesson.price , lesson.lesson_nums ,trainer.title as trainertitle , lesson.lesson_class_id , lesson.id as lessonid, trainer.trainer_classid";
			}

			$ext_field = true;
		}


		// 总数
		if (!$ids) {
			$total = $model->table($tables)->where($con)->where($sql)->count($count);
			// 总页数
			$paginator = new Paginator($total, $var['prepagenum'], $var['page'], '');
			if ($paginator->getNumPages() > 0) {
				if (!((v::between(1, $paginator->getNumPages())->validate($var['page'])))) {
					$var['page'] = 1;
				}
			} else {
				$var['page'] = 0;
			}

			$var['data']['paginator'] = $paginator;
		} else {
			$var['page'] = 1;
		}

		if (($ids) || ($total)) {
			if ($var['orderby']) {
				$geolist = $model->table($tables)->field($field)->where($con)->where($sql)->group($group)->order($var['orderby'])->limit((($var['page'] - 1) * $var['prepagenum']), $var['prepagenum'])->select();

			} else {
				$geolist = $model->table($tables)->field($field)->where($con)->where($sql)->group($group)->select();
			}
		} else {
			$geolist = null;
		}
		//dump($geolist);
		$var['data']['geolist'] = $geolist;
		$var['ext_field'] = $ext_field;
		//var_dump($model->getLastSql());
		return $var;
	}


	private function getRedisString($var)
	{
		$redis_geo = $var['find_type'] . "_" . $var['trainer_class_id'] . "_" . $var['area_id'] . "_" . $var['lesson_class_id'] . "_" . base64_encode($var['search']);
		if ($var['orderby']) {
			$redis_geo .= "_" . $var['order'] . "_" . $var['page'] . "_" . $var['prepagenum'];
		}

		return array(
			"redis_geo" => $this->getConfig("REDIS_FIND_LIST_CACHE") . $redis_geo,
			"total_redis_geo" => $this->getConfig("REDIS_FIND_TOTAL_CACHE") . $redis_geo
		);

	}

	private function getFindList($var, $distinctlist, $datalist = array())
	{

		$d = array();
		if (($distinctlist) && is_array($distinctlist)) {
			foreach ($distinctlist as $dis) {
				$d[$dis[0]] = $dis[1];
			}
		}

		if ($d) {
			if (!$datalist) {
				$dt = $this->getFindData($var, array_keys($d));
				$datalist = $dt['data']['geolist'];
			}
		}

		$list = array();

		$idstring = "id";
		if ($var['find_type'] == $this->getConfig("FINDTYPE_LESSON")) {
			$idstring = "id";
		}

		if ($var['orderby']) {
			// 有排序，按照sql数据显示
			if (($datalist) && is_array($datalist)) {
				foreach ($datalist as $k => $item) {
					$dis = $d[$item[$idstring]];
					if ($dis) {
						$item['distince'] = $dis;
					} else {
						$item['distince'] = -1;
					}
					$list[] = $item;
				}
			}
		} else {
			// 按照距离排序
			if (($d) && is_array($d)) {

				foreach ($d as $id => $dis) {

					if (($datalist) && is_array($datalist)) {
						foreach ($datalist as $k => $item) {
							if ($item[$idstring] == $id) {
								$item['distince'] = $dis;
								$list[] = $item;
								break;
							}
						}
					}
				}
			}
		}
		return ($list);
	}
}
