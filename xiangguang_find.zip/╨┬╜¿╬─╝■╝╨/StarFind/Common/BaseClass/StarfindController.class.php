<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace Common\BaseClass;

use Common\Model\TrainerModel;
use Common\Model\UserModel;
use Common\Model\WxAutologinModel;
use Sinergi\Token\StringGenerator;
use Think\Controller;
use Think\Log;

Class StarfindController extends Controller
{

    protected $config;
    public $wxtoken;
    public $wxinfo;
    public $Wechat;

    /**
     * @return mixed
     */
    public function getConfig()
    {
        return $this->config;
    }

    public function Config($key)
    {
        return $this->config[$key];
    }

    /**
     * @param mixed $config
     */
    public function setConfig($config)
    {
        $this->config = $config;
    }

    public function __construct()
    {
        $this->config = $this->loadConfig();
        $this->Wechat = new Wechatauth($this->Config("DEFAULT_WECHAT_APP_ID"), $this->Config("DEFAULT_WECHAT_APP_SECRET"));
        $this->weixin();
        parent::__construct();

        $title = $this->getTitle();
        $this->assign('pagetitle', $title);
    }

    private function loadConfig()
    {
        $c = new Config();
        $config = $c->load();
        return $config;
    }


    public function getWechatSignPackage()
    {
        return $this->Wechat->getSignPackage();
    }

    public function weixin()
    {
        // 检查是否微信
        $agent = $_SERVER['HTTP_USER_AGENT'];
        if (!strpos($agent, 'MicroMessenger')) {
            if (!($this->Config("DEBUG_WECHAT"))) {
                header('Content-type:text/html;charset=utf-8');
                die("此程序必须在微信环境下运行1！");
            }
        }

        // 获取渠道信息
        $from = I("f", '', 'trim');
        if (!$from) {
            if (session($this->Config("SESSION_INVITE_CODE"))) {
                $from = session($this->Config("SESSION_INVITE_CODE"));
            } else {
                $from = I('cookie.from');
            }
        }

        if ($from) {
            if (session($this->Config("SESSION_INVITE_CODE") != $from)) {
                session($this->Config("SESSION_INVITE_CODE"), $from);
                cookie('from', $from, 60 * 60 * 24 * 7);
            }
        }


        // 模拟微信返回数据

        $s_token = array(
            'access_token' => 'OezXcEiiBSKSxW0eoylIeBLFGJScwQpIj74qhkmv9lfXON1vD_Be0CjQg9nw6F-XLbxVfNK_qXw3RPy7ehnDqfCkeQXvcuKCVPSzLZjdu5zIP0c24Koq9xuJMzFDrkGV3VnCy2FyCeYkCqguOjayzg',
            'expires_in' => 7200,
            'refresh_token' => 'OezXcEiiBSKSxW0eoylIeBLFGJScwQpIj74qhkmv9lfXON1vD_Be0CjQg9nw6F-XA7aDPddsMt9xvJok1YsTXk0LA4d-m0kqHqaB9wrFSpE9hDbRftNCvfKH3Jw5O3J1tyV8cvrOOR4uIGydzCSTFQ',
            'openid' => 'o-t-1wBUnk5Q1OzgaPc1z1hP4I2n',
            'scope' => 'snsapi_base'
        );

        $s_info = array(
            'openid' => $s_token['openid'],
            'nickname' => '微信用户',
            'headimgurl' => $this->Config("DEFAULT_SITE_WWWURL") . "/" . $this->Config("DEFAULT_USER_AVATOR"),
        );

        if ($this->Config("DEBUG_WECHAT")) {
            session('wxtoken', $s_token);
            session('wxinfo', $s_info);
        }

        $token = session('wxtoken'); //查看是否已经授权
        $wxinfo = session('wxinfo');


        if (empty($token) && empty($wxinfo)) {

            if (I('code')) {
                $token = $this->Wechat->get_access_token('', '', I('code'));
                $tohtml = (array)json_decode(file_get_contents($token));

                if ($tohtml['openid']) {

                    if ($this->Config("WECHAT_USERINFO")) {
                        $info = $this->Wechat->get_user_info($tohtml['access_token'], $tohtml['openid']);
                    } else {
                        $info['openid'] = $tohtml['openid'];
                        $info['nickname'] = '微信用户';
                        $info['headimgurl'] = $this->Config("DEFAULT_SITE_WWWURL") . "/" . $this->Config("DEFAULT_USER_AVATOR");
                    }
                    session('wxtoken', $tohtml);
                    session('wxinfo', $info);
                    $this->wxtoken = $token;
                    $this->wxinfo = $info;
                    $wxinfo = $this->wxinfo;
                }
            } else {
                header("location: " . $this->Wechat->get_authorize_url($this->Config("DEFAULT_SITE_WWWURL") . "" . __SELF__, '', $this->Config("WECHAT_USERINFO")));
                exit();
            }
        } else {
            $this->wxtoken = $token;
            $this->wxinfo = $wxinfo;
        }

        if ($wxinfo['openid']) {
            if (session($this->Config("SESSION_WX_OPENID")) != $wxinfo['openid']) {
                session($this->Config("SESSION_WX_OPENID"), $wxinfo['openid']);
            }
        } else {
            header('Content-type:text/html;charset=utf-8');
            die("此程序必须在微信环境下运行3！");
        }


        if (session($this->Config("SESSION_WX_OPENID"))) {
            $wxuser = array();
            if (!session($this->Config("SESSION_WX_USERID"))) {            // 获取微信用户id
                $wxuser = $this->getWxId($wxinfo['openid'], session("from"));
                if ($wxuser) {
                    session($this->Config("SESSION_WX_USERID"), $wxuser['wxid']);
                }
            }

            if (!$this->normalCheckUserLogin()) {            // 是否已经登陆

                $mobile = checkMobile(cookie('mobile'));
                if (!$wxuser) {
                    $wxuser = $this->getWxId($wxinfo['openid'], session("from"));
                }
                if ($wxuser['mobile'] == $mobile) {
                    // 自动登录 培训者或者普通用户？
                    if ($this->setTrainerLogin($wxuser['mobile'], $wxuser['wxid'])) {

                    }

                    if ($this->setUserLogin($wxuser['mobile'], $wxuser['wxid'])) {

                    }
                    // autologin ok !
                }
            }
        } else {
            header('Content-type:text/html;charset=utf-8');
            die("此程序必须在微信环境下运行2！");
        }
    }


    public function normalCheckUserLogin()
    {
        if (session($this->Config("SESSION_USER_MOBILE"))) {
            return true;
        } else {
            return false;
        }
    }

    public function normalCheckTrainerLogin()
    {
        if (session($this->Config("SESSION_TRAINER_MOBILE"))) {
            return true;
        } else {
            return false;
        }
    }

    public function getWxId($openid, $invint_code)
    {
        $um = new WxAutologinModel();
        $u = $um->getWxUser($openid, $invint_code);
        return $u;
    }


    public function setUserLogin($mobile, $wxuserid)
    {
        $usermodel = new UserModel();
        $user = $usermodel->getUserByMobile($mobile);
        if ($user) {
            session($this->Config("SESSION_USER_ID"), $user['id']);
            session($this->Config("SESSION_USER_MOBILE"), $user['mobile']);
            session($this->Config("SESSION_USER_NAME"), $user['username']);
            session($this->Config("SESSION_USER_AVATOR"), $user['avator']);

            cookie('mobile', $mobile, array('expire' => 3600 * 24 * $this->Config("AUTOLOGIN_MAX_DAY")));
            // update user;
            $usermodel->updateUserLogin($user['id']);

            $um = new WxAutologinModel();
            $um->updateWxUser($wxuserid, $mobile);

            return true;
        } else {
            return false;
        }
    }

    public function setTrainerLogin($mobile, $wxuserid)
    {
        $trainermodel = new TrainerModel();
        $trainer = $trainermodel->getTrainerByMobile($mobile);
        if ($trainer) {
            session($this->Config("SESSION_TRAINER_ID"), $trainer['id']);
            session($this->Config("SESSION_TRAINER_MOBILE"), $trainer['mobile']);
            session($this->Config("SESSION_TRAINER_NAME"), $trainer['title']);
            session($this->Config("SESSION_TRAINER_AVATOR"), $trainer['avator']);
            session($this->Config("SESSION_TRAINER_TYPE"), $trainer['trainer_classid']);

            cookie('mobile', $mobile, array('expire' => 3600 * 24 * $this->Config("AUTOLOGIN_MAX_DAY")));
            $trainermodel->updateTrainerLogin($trainer['id']);
            $um = new WxAutologinModel();
            $um->updateWxUser($wxuserid, $mobile);

            return true;
        } else {
            return false;
        }
    }


    public function setUserLogout()
    {
        // 删除自动登录
        $wxid = session($this->Config("SESSION_WX_USERID"));
        $wxmodel = new WxAutologinModel();
        $wxmodel->deleteWxUser($wxid);

        // 清除session
        session($this->Config("SESSION_WX_USERID"), null);
        session($this->Config("SESSION_USER_ID"), null);
        session($this->Config("SESSION_USER_MOBILE"), null);
        session($this->Config("SESSION_USER_NAME"), null);
        session($this->Config("SESSION_USER_AVATOR"), null);
        // 清除cookie
        cookie('mobile', null);
    }

    public function setTrainerLogout()
    {
        // 删除自动登录
        $wxid = session($this->Config("SESSION_WX_USERID"));
        $wxmodel = new WxAutologinModel();
        $wxmodel->deleteWxUser($wxid);
        session($this->Config("SESSION_WX_USERID"), null);
        // 清除session
        session($this->Config("SESSION_TRAINER_ID"), null);
        session($this->Config("SESSION_TRAINER_MOBILE"), null);
        session($this->Config("SESSION_TRAINER_NAME"), null);
        session($this->Config("SESSION_TRAINER_AVATOR"), null);
        session($this->Config("SESSION_TRAINER_TYPE"), null);
        // 清除cookie
        cookie('mobile', null);
    }

    public function getTitle()
    {
        return $this->Config("DEFAULT_SITE_TITLE");
    }


    public function token_make()
    {
        if (session($this->config("SESSION_TOKEN"))) {
            return session($this->config("SESSION_TOKEN"));
        } else {
            $token = StringGenerator::randomAlnum(32);
            session($this->config("SESSION_TOKEN"), $token);
            return $token;
        }
    }

    public function token_refresh()
    {
        $token = StringGenerator::randomAlnum(32);
        session($this->config("SESSION_TOKEN"), $token);
    }

    public function token_get()
    {
        $token = session($this->config("SESSION_TOKEN"));
        if ($token) {
            return $token;
        } else {
            $token = $this->token_make();
        }
        return $token;
    }

    public function token_check($token)
    {
        if ($this->Config("DEBUG_TOKEN")) {
            $stoken = $this->token_get();

            if ($token) {
                if ($stoken == $token) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return true;
        }
    }
}