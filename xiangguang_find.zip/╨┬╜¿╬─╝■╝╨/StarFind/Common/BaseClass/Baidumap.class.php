<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/17
 */
namespace Common\BaseClass;
class Baidumap
{
	public $config;

	public function __construct($config)
	{
		$this->config = $config;
	}

	public function Config($configstring)
	{
		if (isset($this->config[$configstring])) {
			return $this->config[$configstring];
		} else {
			return false;
		}
	}


	public function getBaiduMapLocation($lng, $lat)
	{
		$baidumapurl = "http://api.map.baidu.com/geoconv/v1/?coords=" . $lng . "," . $lat . "&from=1&to=5&ak=" . $this->Config("DEFAULT_BAIDU_API_KEY");
		$s = $this->http($baidumapurl);
		if ($s[0] != 200) {
			return null;
		} else {
			$l = json_decode($s[1], JSON_UNESCAPED_UNICODE);
		}
		return array("lng" => $l['result'][0]["x"], "lat" => $l['result'][0]["y"]);

	}

	//curl
	public function http($url, $method, $postfields = null, $headers = array(), $debug = false)
	{
		$ci = curl_init();
		/* Curl settings */
		curl_setopt($ci, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
		curl_setopt($ci, CURLOPT_CONNECTTIMEOUT, 30);
		curl_setopt($ci, CURLOPT_TIMEOUT, 30);
		curl_setopt($ci, CURLOPT_RETURNTRANSFER, true);

		switch ($method) {
			case 'POST':
				curl_setopt($ci, CURLOPT_POST, true);
				if (!empty($postfields)) {
					curl_setopt($ci, CURLOPT_POSTFIELDS, $postfields);
				}
				break;
		}
		curl_setopt($ci, CURLOPT_URL, $url);
		curl_setopt($ci, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ci, CURLINFO_HEADER_OUT, true);

		$response = curl_exec($ci);
		$http_code = curl_getinfo($ci, CURLINFO_HTTP_CODE);

		if ($debug) {
			echo "=====post data======\r\n";
			Log::write(print_r($postfields, true), 'WARN');

			echo '=====info=====' . "\r\n";
			Log::write(print_r(curl_getinfo($ci), true), 'WARN');

			echo '=====$response=====' . "\r\n";
			Log::write(print_r($response, true), "WARN");
		}
		curl_close($ci);
		return array($http_code, $response);
	}
}