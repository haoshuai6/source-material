<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/22
 */

namespace Common\BaseClass;

use Boris\EvalWorker;
use Common\Model\LessonClassModel;
use Common\Model\LessonModel;
use Common\Model\OrderLessonModel;
use Common\Model\OrderLogModel;
use Common\Model\OrderModel;
use Common\Model\OrderPayModel;
use Common\Model\PaymentModel;
use Common\Model\TrainerModel;
use Common\Model\UserModel;
use Common\Model\UserVoucherModel;
use \Exception;
use Common\BaseClass\Error;

class Order
{
    // 创建订单
    public function newOrder($userid, $lesson_array, $address, $demo = "")
    {

        $e = new Error();
        // 收集订单信息
        $e = $this->getOrderData($userid, $lesson_array, $address, $demo);
        if ($e->checkResult()) {

            $orderdata = $e->getData();

            if (($orderdata) && is_array($orderdata)) {

                $ordermodel = new OrderModel();
                try {
                    $ordermodel->startTrans();

                    foreach ($orderdata['trainer'] as $trainer_id => $order) {

                        // 检查最大购买数量
                        $m = $this->checkMaxBuyNums($userid, $order['lesson']);
                        if (!$m->checkResult()) {
                            throw new Exception($m->getText());
                        }

                        $order_sn = $ordermodel->genOrderSn($userid);
                        $order_id = $ordermodel->createOrder($orderdata['user'], $trainer_id, $order['price'], $order['shop'], $orderdata['address'], $order_sn, $orderdata['demo']);

                        if ($order_id) {
                            $orderlessonmodel = new OrderLessonModel();
                            $r = $orderlessonmodel->createOrderLesson($order_id, $order['lesson']);
                            if ($r) {

                                $orderdata['order_id'] = $order_id;
                                $e->setData($orderdata);

                                // todo 下单成功后操作  返还积分？


                            } else {
                                throw new Exception("保存订单信息失败");
                            }

                        } else {
                            throw new Exception("保存订单信息失败");
                        }
                    }
                    // 提交
                    $ordermodel->commit();

                } catch (Exception $ex) {

                    $e->setError(500, $ex->getMessage());
                    $ordermodel->rollback();
                }


            } else {
                $e->setError(201, "未找到订单数据");
            }
        }
        return $e;
    }


    // 返回顶订单信息
    private function getOrderData($userid, $lesson_array, $address, $demo)
    {

        $error = new Error();

        $lessonmodel = new LessonModel();
        $usermodel = new UserModel();

        $user = $usermodel->getUserInfo($userid);
        if ($user) {

        } else {
            $error->setError(103, "获取用户信息错误");
        }

        if (($error->checkResult()) && (!$lesson_array)) {
            $error->setError(106, "订单中未包含数据");
        }


        $orderarray = array();

        $orderarray['user'] = $user;
        $orderarray['address'] = $address;
        $orderarray['demo'] = $demo;

        if ($error->checkResult()) {
            $lessonlist = $lessonmodel->getLessonWithTrainer(array_keys($lesson_array));

            if (($lessonlist) && is_array($lessonlist)) {
                foreach ($lessonlist as $k => $lesson) {
                    // 放入order数组
                    $orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['nums'] += $lesson_array[$lesson['lesson_id']];
                    if (!$orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['price']) {
                        $orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['price'] = $lesson['price'];
                    }

                    if (!$orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['image']) {
                        $orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['image'] = $lesson['image'];
                    }

                    if (!$orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['lesson_class_id']) {
                        $orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['lesson_class_id'] = $lesson['lesson_class_id'];
                    }

                    if (!$orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['name']) {
                        $orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['name'] = $lesson['lesson_title'];
                    }

                    if (!$orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['maxbuy_nums']) {
                        $orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['maxbuy_nums'] = $lesson['maxbuy_nums'];
                    }

                    if (!$orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['lesson_nums']) {
                        $orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['lesson_nums'] = $lesson['lesson_nums'];
                    }

                    $orderarray['trainer'][$lesson['trainer_id']]['price']['lesson'] += ($lesson['price'] * $lesson_array[$lesson['lesson_id']]);
                    $orderarray['trainer'][$lesson['trainer_id']]['price']['shipping'] += 0;

                    if (!$orderarray['trainer'][$lesson['trainer_id']]['shop']) {
                        $orderarray['trainer'][$lesson['trainer_id']]['shop']['name'] = $lesson['trainer_title'];
                        $orderarray['trainer'][$lesson['trainer_id']]['shop']['avator'] = $lesson['avator'];
                        $orderarray['trainer'][$lesson['trainer_id']]['shop']['mobile'] = $lesson['mobile'];
                    }

                    if (($lesson['maxbuy_nums'] > 0) && ($orderarray['trainer'][$lesson['trainer_id']]['lesson'][$lesson['lesson_id']]['nums'] > $lesson['maxbuy_nums'])) {
                        // 单笔订单数量大于最大购买数量
                        $error->setError(105, "<" . $lesson['lesson_title'] . "> 购买的数量超过了限制");
                    }
                }
            } else {
                $error->setError(107, "订单中未包含数据");
            }
        }

        $error->setData($orderarray);
        return $error;
    }


    public function checkMaxBuyNums($userid, $lesson)
    {
        $e = new Error();

        $ids = array();
        if (($lesson) && is_array($lesson)) {

            foreach ($lesson as $lesson_id => $info) {

                if ($info['maxbuy_nums'] > 0) {
                    $ids[$lesson_id] = $info['maxbuy_nums'];
                }
            }
        }

        if ($ids) {
            $orderlessonmodel = new OrderLessonModel();
            $num = $orderlessonmodel->getCountByLessonID($userid, array_keys($ids));
            if (($num) && is_array($num)) {

                foreach ($num as $k => $c) {

                    $lesson_id = $c['lesson_id'];
                    $buy_nums = $c['c'];

                    if ($ids[$lesson_id] < ($buy_nums + $lesson[$lesson_id]['nums'])) {
                        $e->setError(100, "<" . $lesson[$lesson_id]['name'] . ">超出最大购买数量");
                        break;
                    }
                }
            }
        }

        return $e;
    }


    // 获取订单支付信息
    public function getOrderInfo($order_id, $user_id = 0)
    {
        $e = new Error();

        $pay = array();

        if ($e->checkResult()) {
            $ordermodel = new OrderModel();
            $order = $ordermodel->getOrder($order_id);
            if (!$order) {
                $e->setError(101, "无法获取订单信息");
            } else {
                $pay['data_order'] = $order;

                if ($user_id) {
                    if ($user_id != $order['buyer_id']) {
                        $e->setError(101, "订单用户信息不匹配");
                    }
                } else {
                    $user_id = $order['buyer_id'];
                }
                $pay['user_id'] = $user_id;
                $pay['trainer_id'] = $order['trainer_id'];

                $orderstatus = new OrderStatus($ordermodel->getConfig());
                $opt = $orderstatus->getUserOperate($order);

               /* var_dump(!(in_array($ordermodel->Config("ORDER_OPT_PAY"), $opt['opt'])));*/
                if (!(in_array($ordermodel->Config("ORDER_OPT_PAY"), $opt['opt']))) {
                    $e->setError(111, "订单状态不匹配");
                }


                // 还原用户的积分和优惠券，取消支付表里面的数据

                if ($e->checkResult()) {
                    $orderpaymodel = new OrderPayModel();

                    $orderpay = $orderpaymodel->getLastOrderPayByOrderId($order_id);
                    if ($orderpay) {

                        // 等待支付的情况下
                        if ($orderpay['pay_state'] == $orderpaymodel->Config("PAY_STATE_WAIT")) {

                            $orderpaymodel->startTrans();
                            try {
                                $usermodel = new UserModel();
                                if ($orderpay['used_point']) {
                                    $p = $usermodel->addUserPoint($user_id, $orderpay['used_point'], "用户取消支付恢复积分", $usermodel->Config("ORDER_LOG_USER"), $user_id, "", $order_id);
                                    if (!$p) {
                                        throw new Exception("恢复用户积分失败");
                                    }
                                }

                                if ($orderpay['used_voucher_id']) {

                                    // 恢复优惠券数量
                                    $p = $usermodel->addUserVoucherNumbers($user_id, 1);
                                    if (!$p) {
                                        throw new Exception("恢复用户优惠券失败");
                                    }

                                    // 恢复用户优惠券
                                    $uservouchermodel = new UserVoucherModel();
                                    $uv = $uservouchermodel->setUserVoucherUnused($orderpay["used_voucher_id"], $orderpay['user_id']);
                                    if (!$uv) {
                                        throw new Exception("修改用户优惠券信息失败");
                                    }

                                }

                                $p = $orderpaymodel->setOrderPay($orderpay['id'], $orderpaymodel->Config("PAY_STATE_CANCEL"));
                                if (!$p) {
                                    throw new Exception("取消用户支付记录失败");
                                }

                                $orderpaymodel->commit();
                            } catch (Exception $ex) {
                                $e->setError(113, $ex->getMessage());
                                $orderpaymodel->rollback();
                            }
                        }
                    }
                }
            }
        }

        if ($e->checkResult()) {
            $usermodel = new UserModel();
            $user = $usermodel->getUserInfo($user_id);
            if (!$user) {
                $e->setError(101, "无法获取用户信息");
            } else {
                $pay['data_user'] = $user;

                $pay['user']['points'] = $user['point'];
            }
        }
        $lessonmodel = new LessonModel();

        if ($e->checkResult()) {

            $orderlessonmodel = new OrderLessonModel();
            $lessonarray = $orderlessonmodel->getLessonArrayByOrderID($order_id);
            if (!$lessonarray) {
                $e->setError(101, "无法获取课程信息");
            } else {
                $pay['data_lessonarray'] = $lessonarray;
                $lessonids = array();
                if (($lessonarray) && is_array($lessonarray)) {

                    foreach ($lessonarray as $k => $li) {
                        $lessonids[] = $li['lesson_id'];
                        $pay['lesson'][$li['lesson_id']]['nums'] = $li['buy_numbers'];
                        $pay['lesson'][$li['lesson_id']]['price'] = $li['price'];
                        $pay['lesson'][$li['lesson_id']]['total'] = $li['price'] * $li['buy_numbers'];
                        $pay['order']['total'] += $pay['lesson'][$li['lesson_id']]['total'];
                    }
                }
                if (!$lessonids) {
                    $e->setError(101, "无法获取课程信息");
                } else {
                    $lessons = $lessonmodel->getLessonArrayByLessonIDArray($lessonids);
                    if (!$lessons) {
                        $e->setError(102, "无法获取课程信息");
                    } else {
                        $pay['data_lesson'] = $lessons;
                        if (($lessons) && (is_array($lessons))) {
                            foreach ($lessons as $k => $lesson) {
                                $pay['lesson'][$lesson['id']]['offline'] = $lesson['canpayoffline'];
                                $pay['lesson'][$lesson['id']]['point'] = $lesson['buy_point'];
                                $pay['lesson'][$lesson['id']]['voucher'] = $lesson['buy_voucher'];
                                $pay['lesson'][$lesson['id']]['title'] = $lesson['title'];
                                $pay['lesson'][$lesson['id']]['lesson_class_id'] = $lesson['lesson_class_id'];


                                // 计算订单最多可以使用的积分数量
                                if ($lesson['buy_point'] == $lessonmodel->Config("LESSON_POINTS_NOTALLOW")) {

                                } else if ($lesson['buy_point'] == $lessonmodel->Config("LESSON_POINTS_NOLIMIT")) {
                                    $pay['order']['point_limit'] += $pay['lesson'][$lesson['id']]['total'] * $lessonmodel->Config("POINT_TO_MONEY");
                                } else {
                                    $pay['order']['point_limit'] += $lesson['buy_point'] * $lessonmodel->Config("POINT_TO_MONEY");
                                }

                                // 是否线下支付，同订单里有一个课程不支持，整个订单都不支持
                                if (!(key_exists("payoffline", $pay['order']))) {
                                    $pay['order']['payoffline'] = true;
                                }
                                if (($pay['order']['payoffline']) && ($lesson['canpayoffline'] == $lessonmodel->Config("LESSON_PAY_OFFLINE_NO"))) {
                                    $pay['order']['payoffline'] = false;
                                }

                                // 计算可用优惠券金额
                                if ($lesson['buy_voucher'] == $lessonmodel->Config("LESSON_VOUCHER_NONE")) {
                                    $pay['data_voucher']['system'] += 0;
                                    $pay['data_voucher']['trainer'] += 0;
                                } else if ($lesson['buy_voucher'] == $lessonmodel->Config("LESSON_VOUCHER_ALL")) {
                                    $pay['data_voucher']['system'] += $pay['lesson'][$lesson['id']]['total'];
                                    $pay['data_voucher']['trainer'] += $pay['lesson'][$lesson['id']]['total'];
                                } else if ($lesson['buy_voucher'] == $lessonmodel->Config("LESSON_VOUCHER_TRAINER")) {
                                    $pay['data_voucher']['system'] += 0;
                                    $pay['data_voucher']['trainer'] += $pay['lesson'][$lesson['id']]['total'];
                                } else if ($lesson['buy_voucher'] == $lessonmodel->Config("LESSON_VOUCHER_SYSTEM")) {
                                    $pay['data_voucher']['system'] += $pay['lesson'][$lesson['id']]['total'];
                                    $pay['data_voucher']['trainer'] += 0;
                                }
                            }
                        }

                    }
                }
            }
        }

        if ($e->checkResult()) {
            $user_voucher_nums = $user['voucher_nums'];
            if (($user_voucher_nums > 0) && (($pay['data_voucher']['system'] + $pay['data_voucher']['trainer']) > 0)) {
                // 获取用户优惠券信息
                $uservouchermodel = new UserVoucherModel();
                $vlist = $uservouchermodel->getUserVoucherList($user_id, true, $pay['trainer_id'], $ordermodel->Config("VOUCHER_STATE_OK"));
             
                if (($vlist) && (is_array($vlist))) {

                    $lessonclass = array();
                    foreach ($vlist as $k => $voucher) {
                        // 优惠券状态
                        $p_system = 0;
                        $p_trainer = 0;

                        // 课程类别限制
                        if ($voucher['lesson_class_id']) {
                            // 载入数据
                            if (!$lessonclass) {
                                $lcmodel = new LessonClassModel();
                                $lessonclass = $lcmodel->loadLessonClass();
                            }
                            $lessonclassarray = $lcmodel->getLessonClassSubList($voucher['lesson_class_id']);

                            // 所有此类型的课程金额
                            foreach ($pay['lesson'] as $lid => $li) {
                                if (in_array($li['lesson_class_id'], $lessonclassarray)) {
                                    if ($li['voucher'] == $lessonmodel->Config("LESSON_VOUCHER_NONE")) {

                                    } else if ($li['voucher'] == $lessonmodel->Config("LESSON_VOUCHER_ALL")) {
                                        $p_system += $li['total'];
                                        $p_trainer += $li['total'];
                                    } else if ($li['voucher'] == $lessonmodel->Config("LESSON_VOUCHER_TRAINER")) {
                                        $p_system += 0;
                                        $p_trainer += $li['total'];
                                    } else if ($li['voucher'] == $lessonmodel->Config("LESSON_VOUCHER_SYSTEM")) {
                                        $p_system += $li['total'];
                                        $p_trainer += 0;
                                    }
                                }
                            }
                        } else {
                            $p_system = $pay['data_voucher']['system'];
                            $p_trainer = $pay['data_voucher']['trainer'];
                        }

                        if ($voucher['voucher_class_id'] == $lessonmodel->Config("VOUCHER_CLASS_SYSTEM")) {
                            if (($p_system > 0) && ($p_system >= $voucher['pricelimit'])) {
                                $pay['order']['voucher_list'][] = $voucher;
                            }
                        } else if ($voucher['voucher_class_id'] == $lessonmodel->Config("VOUCHER_CLASS_TRAINER")) {
                            if (($p_trainer > 0) && ($p_trainer >= $voucher['pricelimit'])) {
                                $pay['order']['voucher_list'][] = $voucher;
                            }
                        }
                    }
                }
            } else {
                $pay['order']['voucher_list'] = array();
            }

            if (isset($pay['order']['point_limit']) && ($pay['order']['point_limit'] >= $user['point'])) {
                $pay['order']['point_limit'] = $user['point'];
            }
        }

        // 支付方式
        if ($e->checkResult()) {
            $paymentmodel = new PaymentModel();
            $payment = $paymentmodel->getPaymentList();
            if ($pay['order']['payoffline']) {
                if (!($paymentmodel->isPayOfflineAllow($payment))) {
                    $pay['order']['payoffline'] = false;
                }
            } else {
                $payment = $paymentmodel->removePayOffline($payment);
            }
            $pay['order']['payment'] = $payment;
        }

        $pay['order']['order_id'] = $order_id;
        $pay['order']['data_info'] = $order;
        $e->setData($pay['order']);
        return $e;
    }


    public function doOrderPrice($config, $paydata, $order_id, $point, $voucher, $payment, $user_id)
    {
        $e = new Error();
        //检查提交数据是否符合要求

        $pay['data']['order_id'] = $order_id;

        if ($point > $paydata['point_limit']) {
            $e->setError(301, "使用积分数量超过限制");
        } else {
            $pay['data']['point'] = $point;
        }
       
        if (($e->checkResult()) && ($voucher)) {
            if (($paydata['voucher_list']) && (is_array($paydata['voucher_list']))) {
                $find = false;
                foreach ($paydata['voucher_list'] as $k => $v) {
                    if ($voucher == $v['id']) {
                        $find = true;
                        $pay['data']['voucher'] = $v;
                        break;
                    }
                }
                if (!$find) {
                    $e->setError(301, "优惠券不能使用");
                }

            } else {
                $e->setError(301, "优惠券不能使用");
            }
        }

        if (($e->checkResult()) && ($payment)) {

            if (($paydata['payment']) && (is_array($paydata['payment']))) {
                $find = false;
                foreach ($paydata['payment'] as $k => $p) {
                    if ($p['id'] == $payment) {
                        $find = true;
                        $pay['data']['payment'] = $p;
                        $pay['payment']['payment_string'] = $p['payment_string'];
                        $pay['payment']['config'] = $p['config'];
                        break;
                    }
                }

                if (!$find) {
                    $e->setError(301, "支付方式不能使用");
                }

            } else {
                $e->setError(301, "暂无可用的支付方式");
            }
        }

        if ($e->checkResult()) {


            // 整理价格数据
            $price = toMoney($paydata['total']);

            $pay['price']['total'] = $price;
            $pay['price']['voucher'] = 0;
            $pay['price']['point'] = 0;
            $pay['price']['amount_online'] = $price;
            $pay['price']['amount_offline'] = 0;

            $pay['promotion']['voucher_id'] = 0;
            $pay['promotion']['point'] = 0;

            if ($price < 0) {
                $price = 0;
            }
            if ($price > 0) {

                // 优先计算优惠券
                if ($pay['data']['voucher']) {
                    if ($pay['data']['voucher']['amount'] <= $price) {
                        $pay['price']['voucher'] = toMoney($pay['data']['voucher']['amount']);
                    } else {
                        $pay['price']['voucher'] = $price;
                    }

                    $pay['promotion']['voucher_id'] = intval($pay['data']['voucher']['id']);
                    $price = $price - $pay['price']['voucher'];
                }
            }

            if ($price > 0) {
                if ($pay['data']['point']) {
                    // 计算积分抵扣
                    $pm = $pay['data']['point'] / $config['POINT_TO_MONEY'];
                    if ($pm > $price) {
                        $pay['price']['point'] = $price;
                        $pay['promotion']['point'] = $price * $config['POINT_TO_MONEY'];;
                    } else {
                        $pay['price']['point'] = toMoney($pm);
                        $pay['promotion']['point'] = $pay['data']['point'];
                    }
                    $price = toMoney($price - $pay['price']['point']);
                }
            }

            if ($price < 0) {
                $price = 0;
            }

            //线上线下
            if ($pay['payment']['payment_string'] == $config['PAYMENT_OFFLINE_STRING']) {
                $pay['price']['amount_offline'] = $price;
                $pay['price']['amount_online'] = 0;
            } else {
                $pay['price']['amount_offline'] = 0;
                $pay['price']['amount_online'] = $price;
            }

            if (($pay['price']['amount_offline'] == 0) && ($pay['price']['amount_online'] == 0)) {
                $pay['payment']['payment_string'] = $config['PAYMENT_ONLINE_STRING'];
            }


            $pay['data']['user_id'] = $user_id;

            $e->setData($pay);
        }
        return $e;
    }

    public function doPayOrder($orderdata)
    {

        $e = new Error();

        $ordermodel = new OrderModel();

        try {

            $ordermodel->startTrans();


            $usermodel = new UserModel();
            // 扣除积分
            if ($orderdata['promotion']['point']) {
                $p = $usermodel->addUserPoint($orderdata['data']['user_id'], (0 - $orderdata['promotion']['point']), "用户创建支付扣除积分", $usermodel->Config("ORDER_LOG_USER"), $orderdata['data']['user_id'], "", $orderdata['data']['order_id']);
                if (!$p) {
                    throw new Exception("扣除用户积分失败");
                }
            }
            // 扣除优惠券
            if ($orderdata['promotion']['voucher_id']) {
                $v = $usermodel->addUserVoucherNumbers($orderdata['data']['user_id'], -1);
                if (!$v) {
                    throw new Exception("扣除用户优惠券失败");
                }

                // 作废用户优惠券
                $uservouchermodel = new UserVoucherModel();
                $uv = $uservouchermodel->setUserVoucherUsed($orderdata['promotion']['voucher_id'], $orderdata['data']['user_id'],$orderdata['data']['order_id']);
                if (!$uv) {
                    throw new Exception("扣除用户优惠券信息失败");
                }
            }

            // 数据写入订单支付表，支付成功后，再改变订单的状态
            $pay_sn = $ordermodel->genPaySn($orderdata['data']['user_id']);


            $orderpay = array();
            $orderpay['order_id'] = $orderdata['data']['order_id'];
            $orderpay['user_id'] = $orderdata['data']['user_id'];
            $orderpay['pay_sn'] = $pay_sn;
            $orderpay['pay_state'] = $usermodel->Config("PAY_STATE_WAIT");
            $orderpay['payment_string'] = $orderdata['payment']['payment_string'];
            $orderpay['pay_online'] = $orderdata['price']['amount_online'];
            $orderpay['pay_offline'] = $orderdata['price']['amount_offline'];
            $orderpay['pay_point'] = $orderdata['price']['point'];
            $orderpay['pay_voucher'] = $orderdata['price']['voucher'];
            $orderpay['pay_balance'] = 0;
            $orderpay['used_point'] = $orderdata['promotion']['point'];
            $orderpay['used_voucher_id'] = $orderdata['promotion']['voucher_id'];
            $orderpay['trade_no'] = "";
            $orderpay['trade_state'] = 0;
            $orderpay['trade_time'] = 0;
            $orderpay['trade_fulltext'] = "";

            $orderpaymodel = new OrderPayModel();
            $opid = $orderpaymodel->addPay($orderpay);
            if (!$opid) {
                throw new Exception("记录用户支付信息失败");
            }

            $ordermodel->commit();
        } catch (Exception $ex) {
            $ordermodel->rollback();
            $e->setError(500, $ex->getMessage());
        }

        var_dump($orderdata);
        if ($e->checkResult()) {
            if ($orderdata["price"]['amount_online'] > 0) {
                // todo 需要线上支付

                $d = array();
                $d['paid'] = false;
                $d['order_id'] = $orderpay['order_id'];
                $d['pay_sn'] = $pay_sn;
                $e->setData($d);

            } else {
                // 直接支付线下订单和0元订单
                $ee = $this->paidOrder($pay_sn);
                if ($ee->checkResult()) {

                    $e->setData($ee->getData());


                } else {
                    $e->setError(444, $ee->getText());
                }
            }
        }
        return $e;
    }

    // 支付订单，可用于线上支付后返回的数据
    public function paidOrder($pay_sn, $tradedata = array())
    {
        $e = new Error();

        $orderpaymodel = new OrderPayModel();
        $orderpay = $orderpaymodel->getOrderPayByPaySN($pay_sn);
        if ($orderpay) {
            if ($orderpay['pay_state'] == $orderpaymodel->Config("PAY_STATE_WAIT")) {
                if ($orderpay['payment_string'] == $orderpaymodel->Config("PAYMENT_OFFLINE_STRING")) {
                    //线下支付
                    $orderpaid = array();
                    $orderpaid['trade_no'] = "";
                    $orderpaid['trade_state'] = 0;
                    $orderpaid['trade_time'] = time();
                    $orderpaid['trade_fulltext'] = "";
                    $orderpaymodel->startTrans();

                    try {


                        $r = $orderpaymodel->setOrderPay($orderpay['id'], $orderpaymodel->Config("PAY_STATE_PAID"), $orderpaid);
                        if ($r) {

                            $orderdata = array();
                            $orderdata['payment_string'] = $orderpay["payment_string"];
                            $orderdata['pay_online'] = $orderpay["pay_online"];
                            $orderdata['pay_offline'] = $orderpay["pay_offline"];
                            $orderdata['pay_point'] = $orderpay["pay_point"];
                            $orderdata['pay_voucher'] = $orderpay["pay_voucher"];
                            $orderdata['pay_balance'] = $orderpay["pay_balance"];
                            $orderdata['used_point'] = $orderpay["used_point"];
                            $orderdata['used_voucher_id'] = $orderpay["used_voucher_id"];
                            $orderdata['time_paid'] = time();

                            $ordermodel = new OrderModel();
                            $os = $ordermodel->changeOrderStatus($orderpay['order_id'], $orderpaymodel->Config("ORDER_STATE_WAITPAY"), $orderpaymodel->Config("ORDER_STATE_OFFLINEPAY"), $orderdata, $ordermodel->Config("ORDER_LOG_USER"), $orderpay['user_id'], '', "线下支付订单成功");

                            if ($os) {

                                $d = array();
                                $d['paid'] = true;
                                $d['order_id'] = $orderpay['order_id'];

                                $e->setData($d);

                            } else {
                                throw new Exception("用户线下支付订单保存失败");
                            }
                        } else {
                            throw new Exception("用户线下支付订单失败");
                        }

                        $orderpaymodel->commit();
                    } catch (Exception $ex) {
                        $e->setError(300, $ex->getMessage());
                        $orderpaymodel->rollback();
                    }
                } else {
                    // 线上支付
                    if ($orderpay['pay_online'] == 0) {

                        $orderpaymodel->startTrans();
                        try {
                            $orderpaid = array();
                            $orderpaid['trade_no'] = "";
                            $orderpaid['trade_state'] = 0;
                            $orderpaid['trade_time'] = time();
                            $orderpaid['trade_fulltext'] = "";
                            $orderpaymodel->startTrans();

                            $r = $orderpaymodel->setOrderPay($orderpay['id'], $orderpaymodel->Config("PAY_STATE_PAID"), $orderpaid);
                            if ($r) {

                                // 优惠全额抵扣
                                $orderdata = array();
                                $orderdata['payment_string'] = $orderpay["payment_string"];
                                $orderdata['pay_online'] = $orderpay["pay_online"];
                                $orderdata['pay_offline'] = $orderpay["pay_offline"];
                                $orderdata['pay_point'] = $orderpay["pay_point"];
                                $orderdata['pay_voucher'] = $orderpay["pay_voucher"];
                                $orderdata['pay_balance'] = $orderpay["pay_balance"];
                                $orderdata['used_point'] = $orderpay["used_point"];
                                $orderdata['used_voucher_id'] = $orderpay["used_voucher_id"];
                                $orderdata['time_paid'] = time();

                                $ordermodel = new OrderModel();
                                $os = $ordermodel->changeOrderStatus($orderpay['order_id'], $orderpaymodel->Config("ORDER_STATE_WAITPAY"), $orderpaymodel->Config("ORDER_STATE_PAID"), $orderdata, $ordermodel->Config("ORDER_LOG_USER"), $orderpay['user_id'], '', "支付订单成功，订单全额抵扣");

                                if ($os) {

                                    $d = array();
                                    $d['paid'] = true;
                                    $d['order_id'] = $orderpay['order_id'];

                                    $e->setData($d);

                                } else {
                                    throw new Exception("用户在线支付订单保存失败");
                                }
                            } else {
                                throw new Exception("用户在线支付订单失败");
                            }

                            $orderpaymodel->commit();
                        } catch (Exception $ex) {
                            $e->setError(300, $ex->getMessage());
                            $orderpaymodel->rollback();
                        }
                    } else {
                        // todo 接收在线支付消息

                        $d = array();
                        $d['paid'] = false;
                        $d['order_id'] = $orderpay['order_id'];

                        $e->setData($d);
                        $e->setError(666, "接收在线支付消息");
                    }
                }

            } else {
                $e->setError(100, "订单支付信息状态异常");
            }
        } else {
            $e->setError(100, "无法获取订单支付信息");
        }
        return $e;
    }
}
