<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace Common\BaseClass;
use Common\Model\LogUserModel;
use Common\Model\LogSystemModel;
use Common\Model\LogTrainerModel;
use Common\Model\LogAdminModel;
use Think\Model;

class StarfindModel extends Model
{

	protected $config;

	/**
	 * @return mixed
	 */
	public function getConfig()
	{
		return $this->config;
	}

	public function Config($key)
	{
		return $this->config[$key];
	}

	/**
	 * @param mixed $config
	 */
	public function setConfig($config)
	{
		$this->config = $config;
	}

	private function loadConfig()
	{
		$c = new Config();
		return $c->load();
	}

	public function __construct($name = '', $tablePrefix = '', $connection = '')
	{
		$this->config = $this->loadConfig();
		parent::__construct($name = '', $tablePrefix = '', $connection = '');
	}

	// 重写add方法
	public function add($data = '', $options = array(), $replace = false , $log = true)
	{
		if (empty($data)) {
			// 没有传递数据，获取当前数据对象的值
			if (!empty($this->data)) {
				$data = $this->data;
				// 重置数据
				$this->data = array();
			} else {
				$this->error = L('_DATA_TYPE_INVALID_');
				return false;
			}
		}
		$datalist = $this->setInsertData(array($data));
		$result = parent::add($datalist[0], $options, $replace);
		if ($log) {
			$this->saveAutoLog("ADD", $result);
		}
		return $result;
	}

	public function addAll($dataList, $options = array(), $replace = false, $log = true)
	{
		$dataList = $this->setInsertData($dataList);
		$result = parent::addAll($dataList, $options, $replace);
		if($log) {
			$this->saveAutoLog("ADDALL", $result);
		}
		return $result;
	}

	// 重新save方法
	public function save($data = '', $options = array(), $log = true)
	{
		if (empty($data)) {
			// 没有传递数据，获取当前数据对象的值
			if (!empty($this->data)) {
				$data = $this->data;
				// 重置数据
				$this->data = array();
			} else {
				$this->error = L('_DATA_TYPE_INVALID_');
				return false;
			}
		}
		$data = $this->setUpdateData($data);
		$result = parent::save($data, $options);
		if ($log) {
			$this->saveAutoLog("SAVE", $result);
		}
		return $result;
	}

	// 重写delete方法
	public function delete($options = array(), $log = true)
	{
		$result = $this->setDeleteData($this->Config('STATE_DELETE'), $options);
		if ($log) {
			$this->saveAutoLog("DEL", $result);
		}
		return $result;
	}

	public function delete_forever($options = array(), $log = true)
	{
		$result =  $this->setDeleteData($this->Config('STATE_DELETE_FOREVER'), $options);
		if ($log) {
			$this->saveAutoLog("DELFOREVER", $result);
		}
		return $result;
	}

	public function delete_true($options = array(), $log = true)
	{
		$result = parent::delete($options);
		if ($log) {
			$this->saveAutoLog("DELTRUE", $result);
		}
		return $result;
	}

	public function thinkselect($options = array())
	{
		return parent::select($options);
	}

	public function thinkfind($options = array())
	{
		return parent::find($options);
	}
	public function thinkgetfield($field,$sepa=null)
	{
		return parent::getField($field,$sepa);
	}
	// 重写select
	public function select($options = array())
	{
		$pk = $this->getPk();
		if (is_string($options) || is_numeric($options)) {
			// 根据主键查询
			if (strpos($options, ',')) {
				$where[$pk] = array('IN', $options);
			} else {
				$where[$pk] = $options;
			}
			$options = array();
			$options['where'] = $where;
		} elseif (is_array($options) && (count($options) > 0) && is_array($pk)) {
			// 根据复合主键查询
			$count = 0;
			foreach (array_keys($options) as $key) {
				if (is_int($key)) $count++;
			}
			if ($count == count($pk)) {
				$i = 0;
				foreach ($pk as $field) {
					$where[$field] = $options[$i];
					unset($options[$i++]);
				}
				$options['where'] = $where;
			} else {
				return false;
			}
		} elseif (false === $options) { // 用于子查询 不查询只返回SQL
			$options['fetch_sql'] = true;
		}
		// 分析表达式
		$options = $this->_parseOptions($options);

		// 插入数据 begin

		// state
		if (!array_key_exists('where', $options)) {
			$options['where'] = array();
		}

		if (!array_key_exists('state', $options['where'])) {

			if (array_key_exists('_string', $options['where'])) {
				$i = strpos($options['where']['_string'], "state");
				if ($i === false) {
					$options['where']['state'] = $this->config('STATE_OK');
				}
			} else {
				$options['where']['state'] = $this->config('STATE_OK');
			}
		}

		// order
		if (!array_key_exists('order', $options)) {
			$options['order'] = 'sort desc , id desc';
		}

		// 插入数据 end

		// 判断查询缓存
		if (isset($options['cache'])) {
			$cache = $options['cache'];
			$key = is_string($cache['key']) ? $cache['key'] : md5(serialize($options));
			$data = S($key, '', $cache);
			if (false !== $data) {
				return $data;
			}
		}
		$resultSet = $this->db->select($options);
		if (false === $resultSet) {
			return false;
		}
		if (!empty($resultSet)) { // 有查询结果
			if (is_string($resultSet)) {
				return $resultSet;
			}

			$resultSet = array_map(array($this, '_read_data'), $resultSet);
			$this->_after_select($resultSet, $options);
			if (isset($options['index'])) { // 对数据集进行索引
				$index = explode(',', $options['index']);
				foreach ($resultSet as $result) {
					$_key = $result[$index[0]];
					if (isset($index[1]) && isset($result[$index[1]])) {
						$cols[$_key] = $result[$index[1]];
					} else {
						$cols[$_key] = $result;
					}
				}
				$resultSet = $cols;
			}
		}

		if (isset($cache)) {
			S($key, $resultSet, $cache);
		}
		return $resultSet;
	}

	public function find($options = array())
	{
		if (is_numeric($options) || is_string($options)) {
			$where[$this->getPk()] = $options;
			$options = array();
			$options['where'] = $where;
		}
		// 根据复合主键查找记录
		$pk = $this->getPk();
		if (is_array($options) && (count($options) > 0) && is_array($pk)) {
			// 根据复合主键查询
			$count = 0;
			foreach (array_keys($options) as $key) {
				if (is_int($key)) $count++;
			}
			if ($count == count($pk)) {
				$i = 0;
				foreach ($pk as $field) {
					$where[$field] = $options[$i];
					unset($options[$i++]);
				}
				$options['where'] = $where;
			} else {
				return false;
			}
		}
		// 总是查找一条记录
		$options['limit'] = 1;
		// 分析表达式
		$options = $this->_parseOptions($options);

		// 插入数据 begin

		// state
		if (!array_key_exists('where', $options)) {
			$options['where'] = array();
		}

		if (!array_key_exists('state', $options['where'])) {

			if (array_key_exists('_string', $options['where'])) {
				$i = strpos($options['where']['_string'], "state");
				if ($i === false) {
					$options['where']['state'] = $this->config('STATE_OK');
				}
			} else {
				$options['where']['state'] = $this->config('STATE_OK');
			}
		}

		// order
		if (!array_key_exists('order', $options)) {
			$options['order'] = 'sort desc , id desc';
		}

		// 插入数据 end


		// 判断查询缓存
		if (isset($options['cache'])) {
			$cache = $options['cache'];
			$key = is_string($cache['key']) ? $cache['key'] : md5(serialize($options));
			$data = S($key, '', $cache);
			if (false !== $data) {
				$this->data = $data;
				return $data;
			}
		}
		$resultSet = $this->db->select($options);
		if (false === $resultSet) {
			return false;
		}
		if (empty($resultSet)) {// 查询结果为空
			return null;
		}
		if (is_string($resultSet)) {
			return $resultSet;
		}

		// 读取数据后的处理
		$data = $this->_read_data($resultSet[0]);
		$this->_after_find($data, $options);
		if (!empty($this->options['result'])) {
			return $this->returnResult($data, $this->options['result']);
		}
		$this->data = $data;
		if (isset($cache)) {
			S($key, $data, $cache);
		}
		return $this->data;
	}


	// 为插入的数据补充默认数值
	private function setInsertData($dataarray)
	{
		foreach ($dataarray as $k => $data) {
			if ($data) {
				$time = time();

				if (!array_key_exists('state', $data)) {
					$dataarray[$k]['state'] = $this->config('STATE_OK');
				}
				if (!array_key_exists('sort', $data)) {
					$dataarray[$k]['sort'] = $this->config('SORT_DEFAULT');
				}
				if (!array_key_exists('createtime', $data)) {
					$dataarray[$k]['createtime'] = $time;
				}
				if (!array_key_exists('updatetime', $data)) {
					$dataarray[$k]['updatetime'] = $time;
				}
				if (!array_key_exists('operator', $data)) {
					$dataarray[$k]['operator'] = $this->getOperatorId();
				}
			}
		}
		return $dataarray;
	}


	// 为更新的数据补充默认数值
	private function setUpdateData($data)
	{
		if ($data) {
			if (!array_key_exists('updatetime', $data)) {
				$data['updatetime'] = time();
			}

			if (!array_key_exists('operator', $data)) {
				$data['operator'] = $this->getOperatorId();
			}
		}
		return $data;
	}


	private function setDeleteData($State_Delete_Key, $options = array())
	{
		$pk = $this->getPk();
		if (empty($options) && empty($this->options['where'])) {
			// 如果删除条件为空 则删除当前数据对象所对应的记录
			if (!empty($this->data) && isset($this->data[$pk])) {
				$data = $this->data;
				$this->data = array();
				$data['state'] = $State_Delete_Key;
				return $this->save($data, $options);
			} //return $this->delete($this->data[$pk]);
			else
				return false;
		}
		if (is_numeric($options) || is_string($options)) {
			// 根据主键删除记录
			if (strpos($options, ',')) {
				$where[$pk] = array('IN', $options);
			} else {
				$where[$pk] = $options;
			}
			$options = array();
			$options['where'] = $where;
		}
		// 根据复合主键删除记录
		if (is_array($options) && (count($options) > 0) && is_array($pk)) {
			$count = 0;
			foreach (array_keys($options) as $key) {
				if (is_int($key)) $count++;
			}
			if ($count == count($pk)) {
				$i = 0;
				foreach ($pk as $field) {
					$where[$field] = $options[$i];
					unset($options[$i++]);
				}
				$options['where'] = $where;
			} else {
				return false;
			}
		}
		// 分析表达式
		$options = $this->_parseOptions($options);
		if (empty($options['where'])) {
			// 如果条件为空 不进行删除操作 除非设置 1=1
			return false;
		}
		if (is_array($options['where']) && isset($options['where'][$pk])) {
			$pkValue = $options['where'][$pk];
		}

		if (false === $this->_before_delete($options)) {
			return false;
		}
		//$result = $this->db->delete($options);
		$data = array();
		$data['state'] = $State_Delete_Key;
		$result = $this->save($data, $options);

		if (false !== $result && is_numeric($result)) {
			$data = array();
			if (isset($pkValue)) $data[$pk] = $pkValue;
			$this->_after_delete($data, $options);
		}
		// 返回删除记录个数
		return $result;
	}


	private function saveAutoLog($typetext,$result)
	{
		if ($this->config("LOG_OPEN")) {
			$opid = $this->getOperatorId();
			$logtable = null;
			$data = array();
			if ($opid == $this->config("OPERATOR_SYSTEM_ID")) {
				// 系统默认
				$logtable = new LogSystemModel();
				$data['system_id'] = $opid;

			} else if ($opid <= (0 - $this->config("STARTNUM_TRAINER_ID"))) {

				$logtable = new LogTrainerModel();
				$data['trainer_id'] = $opid;

			} else if (($opid >= $this->config('STARTNUM_USER_ID')) || ($opid === $this->config("OPERATOR_GUEST_ID"))) {
				// 用户和访客
				$logtable = new LogUserModel();
				$data['user_id'] = $opid;

			} else {

				$logtable = new LogAdminModel();
				$data['admin_id'] = $opid;
			}

			$data['ipaddress'] = get_client_ip();
			$data['message'] = $typetext."_".$result."_".MODULE_NAME."_".CONTROLLER_NAME."_".ACTION_NAME;
			$data['url'] = __SELF__;
			$data['demo'] = serialize(json_encode(I("post.")));
			$logtable->add($data, null, false, false);
		}
	}

	// 获取操作员id ， 顺序为 总管理员 培训者 用户 默认
	private function getOperatorId()
	{
		$admin_id = session($this->config("SESSION_ADMIN_ID"));
		if (!$admin_id) {
			$trainer_id = session($this->config("SESSION_TRAINER_ID"));
			if (!$trainer_id) {
				$user_id = session($this->config("SESSION_USER_ID"));
				if (!$user_id) {
					$system_id = $this->config("SESSION_SYSTEM_ID");
					if (!$system_id) {
						return $this->config("OPERATOR_GUEST_ID");
					} else {
						return $system_id;
					}
				} else {
					return $user_id;
				}
			} else {
				return (0 - $trainer_id);
			}
		} else {
			return $admin_id;
		}
	}

	/**
	 * 获取一条记录的某个字段值
	 * @access public
	 * @param string $field  字段名
	 * @param string $spea  字段数据间隔符号 NULL返回数组
	 * @return mixed
	 */
	public function getField($field,$sepa=null) {
		$options['field']       =   $field;
		$options                =   $this->_parseOptions($options);

		// 插入数据 begin

		// state
		if (!array_key_exists('where', $options)) {
			$options['where'] = array();
		}

		if (!array_key_exists('state', $options['where'])) {

			if (array_key_exists('_string', $options['where'])) {
				$i = strpos($options['where']['_string'], "state");
				if ($i === false) {
					$options['where']['state'] = $this->config('STATE_OK');
				}
			} else {
				$options['where']['state'] = $this->config('STATE_OK');
			}
		}

		// order
		if (!array_key_exists('order', $options)) {
			$options['order'] = 'sort desc , id desc';
		}

		// 插入数据 end


		// 判断查询缓存
		if(isset($options['cache'])){
			$cache  =   $options['cache'];
			$key    =   is_string($cache['key'])?$cache['key']:md5($sepa.serialize($options));
			$data   =   S($key,'',$cache);
			if(false !== $data){
				return $data;
			}
		}
		$field                  =   trim($field);
		if(strpos($field,',') && false !== $sepa) { // 多字段
			if(!isset($options['limit'])){
				$options['limit']   =   is_numeric($sepa)?$sepa:'';
			}
			$resultSet          =   $this->db->select($options);
			if(!empty($resultSet)) {
				if(is_string($resultSet)){
					return $resultSet;
				}
				$_field         =   explode(',', $field);
				$field          =   array_keys($resultSet[0]);
				$key1           =   array_shift($field);
				$key2           =   array_shift($field);
				$cols           =   array();
				$count          =   count($_field);
				foreach ($resultSet as $result){
					$name   =  $result[$key1];
					if(2==$count) {
						$cols[$name]   =  $result[$key2];
					}else{
						$cols[$name]   =  is_string($sepa)?implode($sepa,array_slice($result,1)):$result;
					}
				}
				if(isset($cache)){
					S($key,$cols,$cache);
				}
				return $cols;
			}
		}else{   // 查找一条记录
			// 返回数据个数
			if(true !== $sepa) {// 当sepa指定为true的时候 返回所有数据
				$options['limit']   =   is_numeric($sepa)?$sepa:1;
			}
			$result = $this->db->select($options);
			if(!empty($result)) {
				if(is_string($result)){
					return $result;
				}
				if(true !== $sepa && 1==$options['limit']) {
					$data   =   reset($result[0]);
					if(isset($cache)){
						S($key,$data,$cache);
					}
					return $data;
				}
				foreach ($result as $val){
					$array[]    =   $val[$field];
				}
				if(isset($cache)){
					S($key,$array,$cache);
				}
				return $array;
			}
		}
		return null;
	}
}