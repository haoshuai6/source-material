<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/17
 */
namespace Common\BaseClass;

class StarfindUserController extends StarfindController
{
	public function __construct()
	{
		parent::__construct();
		$this->checkUserLogin();
	}


	private function checkUserLogin()
	{
		if (!session($this->Config("SESSION_USER_MOBILE")))
		{
			$this->redirect("Home/Login/userlogin" , array("re"=>urlencode(__SELF__)));
		}
	}


	public function getUserId()
	{
		return session($this->Config("SESSION_USER_ID"));
	}

	public function getUserMobile()
	{
		return session($this->Config("SESSION_USER_MOBILE"));
	}

	public function getUserName()
	{
		return session($this->Config("SESSION_USER_NAME"));
	}
	public  function getUserAvator(){
		return session($this->Config("SESSION_USER_AVATOR"));
	}


}