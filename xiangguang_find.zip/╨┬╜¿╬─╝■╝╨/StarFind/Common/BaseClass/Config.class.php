<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace Common\BaseClass;

class Config
{
	public function load()
	{
		$config = array();

		//$config = S('config');
		if (!$config)
		{
			$config_system = M('config_system')->where(array('state'=>1))->order('sort desc, id asc')->select();
			$config = array();
			foreach($config_system as $k=> $v)
			{
				$config[$v['keyword']] = $v['value'];
			}

			$config_user = M('config_user')->where(array('state'=>1))->order('sort desc, id asc')->select();
			foreach($config_user as $k=> $v)
			{
				$config[$v['keyword']] = $v['value'];
			}
			S('config',$config);
		}
		return $config;
	}
}