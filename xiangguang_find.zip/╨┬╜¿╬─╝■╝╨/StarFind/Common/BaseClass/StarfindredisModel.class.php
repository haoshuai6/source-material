<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace Common\BaseClass;
use Predis;

class StarfindredisModel extends StarfindModel
{

	public function __construct($name = '', $tablePrefix = '', $connection = '')
	{
		parent::__construct($name = '', $tablePrefix = '', $connection = '');
		$this->setRedis(new Predis\Client(array(
			'host' => C('REDIS_IP'),
			'port' => C('REDIS_PORT'),
			'database' => C('REDIS_DB'),
		), array('prefix' => C('REDIS_PREFIX'))));
	}

	private $redis;

	/**
	 * @return Predis\Client
	 */
	public function getRedis()
	{
		return $this->redis;
	}

	/**
	 * @param Predis\Client $redis
	 */
	public function setRedis($redis)
	{
		$this->redis = $redis;
	}
}