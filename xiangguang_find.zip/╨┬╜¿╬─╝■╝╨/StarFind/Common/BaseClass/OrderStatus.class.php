<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/28
 */

namespace Common\BaseClass;

class OrderStatus
{
    public $config;

    public function __construct($config)
    {
        $this->config = $config;
    }

    public function Config($configstring)
    {
        if (isset($this->config[$configstring])) {
            return $this->config[$configstring];
        } else {
            return false;
        }
    }

    public function getUserOperate($order)
    {
        $opt = $this->getOrderOperate($order);
        return array(
            'txt' => $opt['txt']['user'],
            'opt' => $opt['opt']['user']
        );
    }

    public function getTrainerOperate($order){
        $opt = $this->getOrderOperate($order);
        return array(
            'txt' => $opt['txt']['trainer'],
            'opt' => $opt['opt']['trainer']
        );
    }

    public function getOrderOperate($order)
    {

        $state_order = $order['state_order'];
        $payment = $order['payment_string'];
        $state_verify = $order['state_verify'];

        $state_lock = $order['state_lock'];
        $state_delete = $order['state_delete'];
        $state_refund = $order['state_refund'];
        $state_evaluation = $order['state_evaluation'];

        $opt = array();

        if ($state_lock == $this->Config("ORDER_LOCK_YES")) {
            $opt['txt']['user'] = "订单已锁定";
            $opt['opt']['user'] = array();
        } else {

            // 订单取消
            if ($state_order == $this->Config("ORDER_STATE_CANCEL")) {
                if ($state_delete == $this->Config("ORDER_DELETE_NO")) {
                    $opt['txt']['user'] = "已取消";
                    $opt['opt']['user'] = array($this->Config("ORDER_OPT_DELETE"));
                } else if ($state_delete == $this->Config("ORDER_DELETE_YES")) {
                    $opt['txt']['user'] = "已删除";
                    $opt['opt']['user'] = array($this->Config("ORDER_OPT_DELETEFOREVER"));
                } else if ($state_delete == $this->Config("ORDER_DELETE_FOREVER")) {
                    $opt['txt']['user'] = "彻底删除";
                    $opt['opt']['user'] = array();
                }

                $opt['txt']['trainer'] = "已取消";
                $opt['opt']['trainer'] = array();

            } // 等待付款
            else if ($state_order == $this->Config("ORDER_STATE_WAITPAY")) {

                if ($state_verify == $this->Config("ORDER_VERIFY_OK")) {

                    $opt['txt']['user'] = "审核通过，等待付款";
                    $opt['opt']['user'] = array($this->Config("ORDER_OPT_CANCEL"), $this->Config("ORDER_OPT_PAY"));

                    $opt['txt']['trainer'] = "审核通过，等待付款";
                    $opt['opt']['trainer'] = array($this->Config("ORDER_OPT_VERIFY"));

                } else if ($state_verify == $this->Config("ORDER_VERIFY_WAIT")) {

                    $opt['txt']['user'] = "等待审核";
                    $opt['opt']['user'] = array($this->Config("ORDER_OPT_CANCEL"));

                    $opt['txt']['trainer'] = "等待审核";
                    $opt['opt']['trainer'] = array($this->Config("ORDER_OPT_VERIFY"));

                } else if ($state_verify == $this->Config("ORDER_VERIFY_ERROR")) {

                    $opt['txt']['user'] = "审核失败";
                    $opt['opt']['user'] = array($this->Config("ORDER_OPT_CANCEL"));

                    $opt['txt']['trainer'] = "审核失败";
                    $opt['opt']['trainer'] = array();
                }
            } // 线下付款等待审核
            else if ($state_order == $this->Config("ORDER_STATE_OFFLINEPAY")) {

                $opt['txt']['user'] = "线下付款成功，等待确认";
                $opt['opt']['user'] = array($this->Config("ORDER_OPT_CANCEL"));

                $opt['txt']['trainer'] = "线下付款成功,等待确认";
                $opt['opt']['trainer'] = array($this->Config("ORDER_OPT_OFFLINE_COMFIRM"));

            } // 付款成功
            else if ($state_order == $this->Config("ORDER_STATE_PAID")) {

                if ($payment != $this->Config("PAYMENT_OFFLINE_STRING")) {

                    $opt['txt']['user'] = "在线付款成功";
                    $opt['opt']['user'] = array($this->Config("ORDER_OPT_CANCEL"), $this->Config("ORDER_OPT_REFUND"), $this->Config("ORDER_OPT_FINISH"));

                    $opt['txt']['trainer'] = "在线付款成功";
                    $opt['opt']['trainer'] = array();

                } else {
                    $opt['txt']['user'] = "线下付款成功,已确认";
                    $opt['opt']['user'] = array($this->Config("ORDER_OPT_FINISH"));

                    $opt['txt']['trainer'] = "线下付款成功,已确认";
                    $opt['opt']['trainer'] = array();
                }
            } else if ($state_order == $this->Config("ORDER_STATE_FINISH")) {
                if ($state_evaluation == $this->Config("ORDER_EVALUATION_NO")) {

                    $opt['txt']['user'] = "已完成，未评价";
                    $opt['opt']['user'] = array($this->Config("ORDER_OPT_EVALUATION"), $this->Config("ORDER_OPT_REFUND"));

                } else if ($state_evaluation == $this->Config("ORDER_EVALUATION_YES")) {

                    $opt['txt']['user'] = "已完成，已评价";
                    $opt['opt']['user'] = array($this->Config("ORDER_OPT_DELETE"), $this->Config("ORDER_OPT_REFUND"));

                } else if ($state_evaluation == $this->Config("ORDER_EVALUATION_TIMEOUT")) {

                    $opt['txt']['user'] = "已完成，已评价";
                    $opt['opt']['user'] = array($this->Config("ORDER_OPT_DELETE"), $this->Config("ORDER_OPT_REFUND"));

                }
            }
        }

        return $opt;
    }
}
