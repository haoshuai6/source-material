<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/5/19
 */

namespace Home\Controller;

use Think\Controller;
use Gregwar\Captcha\CaptchaBuilder;

class CaptchaController extends Controller
{


	protected $config;

	/**
	 * @return mixed
	 */
	public function getConfig()
	{
		return $this->config;
	}

	public function Config($key)
	{
		return $this->config[$key];
	}

	/**
	 * @param mixed $config
	 */
	public function setConfig($config)
	{
		$this->config = $config;
	}

	public function __construct()
	{
		$this->config = $this->loadConfig();
		parent::__construct();
	}

	private function loadConfig()
	{
		$c = new Config();
		$config = $c->load();
		return $config;
	}


	public function index()
	{
		// type 登陆1 注册2 找回密码3

		$type = intval($_GET['type']);
		if (!$type) {
			$type = $this->getConfig("CAPTCHA_LOGIN");
		}

		$cs = $this->getCaptchaString($type);

		$length = 4;
		$num = "";

		if ($length > 0) {
			$num .= rand(1, 9);
			if ($length > 1) {
				$length--;
				for ($i = 0; $i < $length; $i++) {
					$num .= rand(0, 9);
				}
			}
		}
		$builder = new CaptchaBuilder($num);
		$builder->setInterpolation(true);
		$builder->setIgnoreAllEffects(true);
		$builder->build();
		session($cs, $builder->getPhrase());

		header('Content-type: image/jpeg');
		$builder->output();
	}

	public function compareCaptcha($type, $captcha)
	{
		if ($captcha) {
			$cs = $this->getCaptchaString($type);
			$ss = session($cs);
			if ($ss == $captcha) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	private function getCaptchaString($type)
	{
		$str = "CAPTCHA_LOGIN";

		if ($type == 1) {
			$str = "CAPTCHA_LOGIN";
		} else if ($type == 2) {
			$str = "CAPTCHA_REG";
		} else if ($type == 3) {
			$str = "CAPTCHA_RESET";
		} else if ($type == 6) {
			$str = "CAPTCHA_BIND";
		} else {
			$str = "CAPTCHA_TYPE_" . $type;
		}

		return $str;
	}

	public function removeCaptcha($type)
	{
		$cs = $this->getCaptchaString($type);
		session($cs, null);
	}
}