<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/10
 */
namespace Home\Controller;

use Common\BaseClass\Find;
use Common\BaseClass\StarfindController;
use Common\Model\AreaModel;
use Common\Model\FavouriteModel;
use Common\Model\LessonClassModel;
use Common\Model\LessonModel;
use Common\Model\LessonOrgTeacherModel;
use Common\Model\OrgTeacherModel;
use Common\Model\TrainerAddressModel;
use Common\Model\TrainerModel;
use Common\BaseClass\Error;

Class FindController extends StarfindController
{
	// http://127.0.0.1/201611_ThinkPHP_XingGuang_Find/Home/Find/index

	public function index()
	{
		//全部科目
		$lessonClass = D('LessonClass')->loadLessonClass(true);

		//全部区域（济南）
		$areaList = D('Area')->loadArea(true);
		$areaSubIds = D('Area')->getAreaSubList(370100,'region');
		$areaSubList = array();
		foreach($areaSubIds as $subIds){
			$areaSubList[$subIds] = $areaList['province'][370000]['city'][370100]['region'][$subIds];
			$areaSubList[$subIds]['id'] = $subIds;
		}

		//离我最近
		$distanceList[0] = array('id'=>$this->Config("FIND_SEARCH_DISTANCES_500"),'title'=>'500米');
		$distanceList[1] = array('id'=>$this->Config("FIND_SEARCH_DISTANCES_1000"),'title'=>'500-1000米');
		$distanceList[2] = array('id'=>$this->Config("FIND_SEARCH_DISTANCES_ASC"),'title'=>'由近到远');

		$finder = new Find($this->getConfig());

		$user_geo_lng = 117.024567;
		$user_geo_lat = 36.67788;

		$find_type = I('get.find_type',1,'intval');//1:培训者2：课程
		$trainer_class_id = I('get.trainer_class_id',1,'intval');

		$area_id = 370100;
		$lesson_class_id = 0;
		$search = "";
		$order = 0;
		$page = 1;
		$prepagenum = 0;
		$distince = 0;

		if($find_type == 2){
			$lesson_class_id = I('get.lesson_class',0,'intval');
			$lesson_class_model = new LessonClassModel();
			$lesson_info = $lesson_class_model->getClassInfoByid($lesson_class_id);
			$this->assign('lesson_info',$lesson_info);
		}

		$trainerList = $finder->find($user_geo_lng, $user_geo_lat, $find_type, $trainer_class_id, $area_id, $lesson_class_id, $search, $order, $page, $prepagenum, $distince);
		
		$tplArray = array('lessonClass'=>$lessonClass,'areaList'=>$areaSubList,'distanceList'=>$distanceList,'trainerList'=>$trainerList['data']['list'],'find_type'=>$find_type,'trainer_class_id'=>$trainer_class_id);
		$this->assign($tplArray);

		if($find_type == 1){
			if($trainer_class_id == 1){
				$this->meta_title = '找机构';
			}else{
				$this->meta_title = '找老师';
			}
			$this->display();
		}else{
			$this->display('lesson');
		}
	}
	public function lesson_find_index(){
		$this->display();
	}
	public function lesson_find_class_json(){

		$less_class = D('LessonClass');
		$less_class_list = $less_class->getAllLessonClass();

		$json_array['lists'] = $less_class_list;
		echo   json_encode($json_array);
	}

	/*
	 * ajax查询机构或老师或课程
	 * */
	public function ajaxFind(){
		$error = new Error();

		$finder = new Find($this->getConfig());

		$user_geo_lng = 117.024567;
		$user_geo_lat = 36.67788;

		$find_type = I('post.find_type',1,'intval');
		$trainer_class_id = I('post.trainer_class_id',1,'intval');

		$area_id = I('post.area_id',370100,'intval');
		$lesson_class_id = I('post.lesson_class_id',0,'intval');
		$distince  = I('post.distince',0,'intval');
		switch($distince){
			case 1:
				$distince = 0.5;
				break;
			case 2:
				$distince = 1;
				break;
			default:
				$distince = 0;
				break;
		}

		$search = "";
		$order = 0;
		$page = I('post.page',1,'intval');
		$prepagenum = 0;

		$trainerList = $finder->find($user_geo_lng, $user_geo_lat, $find_type, $trainer_class_id, $area_id, $lesson_class_id, $search, $order, $page, $prepagenum, $distince);

		if(!empty($trainerList['data']['list']) && is_array($trainerList['data']['list'])){
			foreach($trainerList['data']['list'] as $k=>$trainer){
				if(empty($trainer['image'])){
					$trainerList['data']['list'][$k]['img_url'] = __ROOT__.'/Public/images/temp/004.jpg';
				}else{
					$trainerList['data']['list'][$k]['img_url'] = __ROOT__.$trainer['image'];
				}

				$trainerList['data']['list'][$k]['demo'] = msubstr($trainerList['data']['list'][$k]['demo'],0,25,'utf-8',false);
			}
		}
		
		$error->setError(0,'加载资料成功',$trainerList['data']['list']);
		$this->ajaxReturn($error->getResult());
	}


	public function jsindex()
	{
		$jssign = $this->getWechatSignPackage();
		$this->assign('wxjs', $jssign);
		$this->assign('mapkey', $this->Config("DEFAULT_BAIDU_API_KEY"));

		var_dump($_SESSION);
		$this->display();
	}

	public function baidulocation()
	{
		$lng = I("get.lng","0","floatval");
		$lat = I("get.lat","0","floatval");
        
		if (($lng)&&($lat)) {
			$this->ajaxReturn((new Baidumap($this->getConfig()))->getBaiduMapLocation($lng, $lat));
		}
		else
		{
			$this->ajaxReturn(
				array("lng"=>0, "lat"=>0)
			);
		}
	}

	public function trainer_info(){
        $t_id =  I("get.tid","0","intval");
		if(!$t_id){
			$this->error("无法获取信息");
		}

		$Trainer_model = new TrainerModel();
		$trainer_info = $Trainer_model->getTrainer($t_id);

		if($trainer_info['trainer_classid'] == $this->Config('CLASS_TRAINER_ORGANIZATION')){ //机构
			$area_model = new AreaModel();
			$address_info = D('TrainerAddress')->getTrainerAdderss($trainer_info['id']);
			if($address_info){
				$area_info_str = '';
				$text_address =  $area_model->getArea_recu($address_info['area_id']);
				$area_info_array = explode(',',$text_address);
				$area_info_array = array_reverse($area_info_array);
				if($area_info_array && is_array($area_info_array)){
					foreach ($area_info_array as $k => $a_list) {
						if($k==0){
							continue;
						}
						$area_info_str .= $a_list .',';
					}
				}
				$area_info_str =  rtrim($area_info_str, ',');
				$trainer_info['address_info'] = $area_info_str.'  '.$address_info['title'];
                $ratio = sprintf("%.2f", (floatval($trainer_info['num_evaluate_good']) / floatval($trainer_info['evaluate_nums'])))  * 100;
				$trainer_info['evaluate_good_ratio'] = $ratio.'%';
			}else{
				$trainer_info['address_info'] = '暂未填写地址';
			}

			$this->assign('trainer_info',$trainer_info);
			$this->display('trainer_trust_info');
		} else { //老师
			$org_teacher = new OrgTeacherModel();
			$lesson_class_model = new LessonClassModel();
            $favourite_model = new FavouriteModel();
			$lesson_model = new LessonModel();
			$lesson_org_teacher = new LessonOrgTeacherModel();

			$teacher_info = $org_teacher->getTeacherInfoByid($t_id);
			if($teacher_info['startyear']){
				$teacher_info['teacheryear'] = intval(date('Y') - $teacher_info['startyear']);
			}
			$less_c_str = '';
			$less_class_str = $lesson_class_model->getLessonSonClass($teacher_info['lesson_class_id']);
			$less_class_str_array = explode('-',$less_class_str);
			$less_class_str_array = array_reverse($less_class_str_array);
			if($less_class_str_array && is_array($less_class_str_array)){
				foreach ($less_class_str_array as $k => $a_list) {
					if($k==0){
						continue;
					}
					$less_c_str .= $a_list .'-';
				}
			}
			$less_c_str =  rtrim($less_c_str, '-');
			$trainer_info['less_class_str'] = $less_c_str;
			$trainer_info['teacher_info'] = $teacher_info;
			/*粉丝数量*/
			$fens_num =  $favourite_model->getInfoByTid($t_id);
			$trainer_info['fens_num'] = $fens_num;
			/*当前用户是否关注*/
			$uid =  session($this->Config("SESSION_USER_ID"));
			$fens_status =  $favourite_model->getStatusByUidTid($uid,$t_id);
            if($fens_status){
				$trainer_info['fens_status'] = 1;
			} 
			/*好评率*/
			$ratio = sprintf("%.2f", (floatval($trainer_info['num_evaluate_good']) / floatval($trainer_info['evaluate_nums'])))  * 100;
			$trainer_info['good_ratio'] = $ratio.'%';
			/*精品课程*/
			$lesson_array = array();

			if($teacher_info){
				$lesson_list = $lesson_org_teacher->getLessonArrayByTeacherId($teacher_info['id']);
				if($lesson_list){
					$lesson_array = $lesson_model->getLessonArrayByLessonIDArrayJP($lesson_list);
				}
			}
			$trainer_info['lesson_list'] = $lesson_array;
			$trainer_info['tid'] = $t_id;
			$trainer_info['uid'] = $uid;

			$this->assign('trainer_info',$trainer_info);
			$this->display('trainer_teacher_introduction');
		}
	}

	//机构简介
	public function trainer_introduction(){
		$t_id =  I("get.tid","0","intval");
		if(!$t_id){
			$this->error("无法获取信息");
		}

		$Trainer_model = new TrainerModel();
		$trainer_info = $Trainer_model->getTrainer($t_id);

		if($trainer_info['trainer_classid'] == $this->Config('CLASS_TRAINER_ORGANIZATION')){ //机构
			$area_model = new AreaModel();
			$address_info = D('TrainerAddress')->getTrainerAdderss($trainer_info['id']);
			if($address_info){
				$area_info_str = '';
				$text_address =  $area_model->getArea_recu($address_info['area_id']);
				$area_info_array = explode(',',$text_address);
				$area_info_array = array_reverse($area_info_array);
				if($area_info_array && is_array($area_info_array)){
					foreach ($area_info_array as $k => $a_list) {
						if($k==0){
							continue;
						}
						$area_info_str .= $a_list .',';
					}
				}
				$area_info_str =  rtrim($area_info_str, ',');
				$trainer_info['address_info'] = $area_info_str.'  '.$address_info['title'];
				$ratio = sprintf("%.2f", (floatval($trainer_info['num_evaluate_good']) / floatval($trainer_info['evaluate_nums'])))  * 100;
				$trainer_info['evaluate_good_ratio'] = $ratio.'%';
			}else{
				$trainer_info['address_info'] = '暂未填写地址';
			}

			$this->assign('trainer_info',$trainer_info);
			$this->display('trainer_trust_introduction');
		} else { //老师
			$org_teacher = new OrgTeacherModel();
			$lesson_class_model = new LessonClassModel();
			$favourite_model = new FavouriteModel();
			$lesson_model = new LessonModel();
			$lesson_org_teacher = new LessonOrgTeacherModel();

			$teacher_info = $org_teacher->getTeacherInfoByid($t_id);
			if($teacher_info['startyear']){
				$teacher_info['teacheryear'] = intval(date('Y') - $teacher_info['startyear']);
			}
			$less_c_str = '';
			$less_class_str = $lesson_class_model->getLessonSonClass($teacher_info['lesson_class_id']);
			$less_class_str_array = explode('-',$less_class_str);
			$less_class_str_array = array_reverse($less_class_str_array);
			if($less_class_str_array && is_array($less_class_str_array)){
				foreach ($less_class_str_array as $k => $a_list) {
					if($k==0){
						continue;
					}
					$less_c_str .= $a_list .'-';
				}
			}
			$less_c_str =  rtrim($less_c_str, '-');
			$trainer_info['less_class_str'] = $less_c_str;
			$trainer_info['teacher_info'] = $teacher_info;
			/*粉丝数量*/
			$fens_num =  $favourite_model->getInfoByTid($t_id);
			$trainer_info['fens_num'] = $fens_num;
			/*当前用户是否关注*/
			$uid =  session($this->Config("SESSION_USER_ID"));
			$fens_status =  $favourite_model->getStatusByUidTid($uid,$t_id,0);
			if($fens_status){
				$trainer_info['fens_status'] = 1;
			}
			/*好评率*/
			$ratio = sprintf("%.2f", (floatval($trainer_info['num_evaluate_good']) / floatval($trainer_info['evaluate_nums'])))  * 100;
			$trainer_info['good_ratio'] = $ratio.'%';
			/*精品课程*/
			$lesson_array = array();

			if($teacher_info){
				$lesson_list = $lesson_org_teacher->getLessonArrayByTeacherId($teacher_info['id']);
				if($lesson_list){
					$lesson_array = $lesson_model->getLessonArrayByLessonIDArrayJP($lesson_list);
				}
			}
			$trainer_info['lesson_list'] = $lesson_array;
			$trainer_info['tid'] = $t_id;
			$trainer_info['uid'] = $uid;

			$this->assign('trainer_info',$trainer_info);
			$this->display('trainer_teacher_introduction');
		}
	}

	//机构课程
	public function trainer_lessons(){
		$t_id =  I("get.tid","0","intval");
		if(!$t_id){
			$this->error("无法获取信息");
		}

		$page_num = $this->Config("PAGE_LIST_NUM");
		$class = I('get.class',1,'intval');

		//课程分类
		$lessonClass = D('LessonClass')->loadLessonClass(true);
		$subClass = D('LessonClass')->getLessonClassSubList($class);
		$subClass[] = $class;

		$map = array();
		$map['trainer_id'] = $t_id;
		$map['lesson_class_id'] = array('in',$subClass);

		$lessonList = D('Lesson')->where($map)->field('id,lesson_class_id,image,title,lesson_nums,price_market,price')->limit('0,'.$page_num)->select();

		$this->assign('class',$class);
		$this->assign('lessonList',$lessonList);
		$this->assign('lessonClass',$lessonClass);
		$this->assign('t_id',$t_id);
		$this->display();
	}

	//ajax加载课程
	public function ajaxTrainerLesson(){
		$error = new Error();

		if(IS_GET){
			$t_id =  I("get.tid","0","intval");
			if($t_id <= 0){
				$error->setError('102','数据错误');
			}else{
				$page_num = $this->Config("PAGE_LIST_NUM");
				$page = I('get.page',0,'intval');
				$start_num = intval($page)*$page_num;

				$class = I('get.class',1,'intval');
				$subClass = D('LessonClass')->getLessonClassSubList($class);
				$subClass[] = $class;

				$map = array();
				$map['trainer_id'] = $t_id;
				$map['lesson_class_id'] = array('in',$subClass);

				$lessonList = D('Lesson')->where($map)->field('id,lesson_class_id,image,title,lesson_nums,price_market,price')->limit($start_num.','.$page_num)->select();
				if(!empty($lessonList) && is_array($lessonList)){
					foreach($lessonList as $k=>$lesson){
						$lessonList[$k]['info_url'] = U('Find/trainer_lessons_info',array('lesson_id'=>$lesson['id']));

						if(empty($lesson['image'])){
							$lessonList[$k]['avator'] = __ROOT__.'/Public/images/icon-people.jpg';
						}else{
							$lessonList[$k]['avator'] = __ROOT__.$lesson['image'];
						}
					}
				}

				$error->setError('0','加载成功',$lessonList);
			}

		}else{
			$error->setError('101','服务器错误');
		}

		$this->ajaxReturn($error->getResult());
	}

	//课程详情
	public function trainer_lessons_info(){
		$lesson_id = I('get.lesson_id',0,'intval');

		if($lesson_id <= 0){
			$this->error("无法获取信息");
		}

		//课程详情
		$lesson_info1 = D('Lesson')->getLesson($lesson_id);
		$lesson_info2 = D('LessonInfo')->getLessonInfo($lesson_id);
		$lesson_address_ids = D('LessonAddress')->getLessonAddress($lesson_id);
		$lesson_address = D('TrainerAddress')->getTrainerAddressList($lesson_address_ids);

		if(empty($lesson_info2)){
			$lesson_info = $lesson_info1;
		}else{
			$lesson_info = array_merge($lesson_info1,$lesson_info2);
		}

		$lesson_info['lesson_address'] = $lesson_address;

		//机构详情
		$trainer_info = D('Trainer')->getTrainer($lesson_info['trainer_id']);

		if($trainer_info['trainer_classid'] == 1){
			//授课老师
			$org_teacher_ids = D('LessonOrgTeacher')->getTeacherArrayByLessonId($lesson_id);

			if(empty($org_teacher_ids)){
				$org_teacher = array();
			}else{
				$org_teacher = D('OrgTeacher')->getTeacherInfo($org_teacher_ids);
			}

			$this->assign('org_teacher',$org_teacher);
		}

		$this->assign('lesson_info',$lesson_info);
		$this->assign('trainer_info',$trainer_info);
		$this->display();
	}

	//机构老师
	public function trainer_teacher(){
		$t_id =  I("get.tid","0","intval");
		if(!$t_id){
			$this->error("无法获取信息");
		}

		$page_num = $this->Config("PAGE_LIST_NUM");
		$class = I('get.class',1,'intval');
		
		//课程分类
		$lessonClass = D('LessonClass')->loadLessonClass(true);

		$subClass = D('LessonClass')->getLessonClassSubList($class);
		$subClass[] = $class;

		$map = array();
		$map['trainer_id'] = $t_id;
		$map['lesson_class_id'] = array('in',$subClass);

		$teacherList = D('OrgTeacher')->where($map)->field('id,title,avator,startyear,graduate')->limit('0,'.$page_num)->select();

		$this->assign('t_id',$t_id);
		$this->assign('class',$class);
		$this->assign('teacherList',$teacherList);
		$this->assign('lessonClass',$lessonClass);

		$this->display();
	}

	public function ajaxTrainerTeacher(){
		$error = new Error();

		if(IS_GET){
			$t_id =  I("get.tid","0","intval");
			if($t_id <= 0){
				$error->setError('102','数据错误');
			}else{
				$page_num = $this->Config("PAGE_LIST_NUM");
				$page = I('get.page',0,'intval');
				$start_num = intval($page)*$page_num;

				$class = I('get.class',1,'intval');
				$subClass = D('LessonClass')->getLessonClassSubList($class);
				$subClass[] = $class;

				$map = array();
				$map['trainer_id'] = $t_id;
				$map['lesson_class_id'] = array('in',$subClass);

				$teacherList = D('OrgTeacher')->where($map)->field('id,title,avator,startyear,graduate')->limit($start_num.','.$page_num)->select();

				if(!empty($teacherList) && is_array($teacherList)){
					foreach($teacherList as $k=>$teacher){
						$teacherList[$k]['info_url'] = U('Find/trainer_teacher_info',array('teacher_id'=>$teacher[id]));
						$teacherList[$k]['startyearcount'] = getExperienceYears($teacher['graduate']);

						if(empty($teacher['avator'])){
							$teacherList[$k]['avator'] = __ROOT__.'/Public/images/icon-people.jpg';
						}else{
							$teacherList[$k]['avator'] = __ROOT__.$teacher['avator'];
						}
					}
				}

				$error->setError('0','加载成功',$teacherList);
			}

		}else{
			$error->setError('101','服务器错误');
		}

		$this->ajaxReturn($error->getResult());
	}

	//机构老师详情
	public function trainer_teacher_info(){
		$teacher_id = I('get.teacher_id',0,'intval');

		if(empty($teacher_id)){
			redirect(U('Find/index'));
		}else {
			$teacherInfo = D('OrgTeacher')->find($teacher_id);

			if(empty($teacherInfo)){
				redirect(U('Find/index'));
			}
		}

		$teacherInfo['lesson_class_name'] = D('LessonClass')->getFieldById($teacherInfo['lesson_class_id'],'title');
		$this->assign('teacherInfo',$teacherInfo);
		$this->display();
	}

	//机构学生评价
	public function trainer_evaluation(){
		$t_id =  I("get.tid","0","intval");

		if(!$t_id){
			$this->error("无法获取信息");
		}

		$type = I('get.type','all','trim');

		$map = array();
		$map['trainer_id'] = $t_id;

		switch($type){
			case 'good':
				$map['evaluate_score'] = intval($this->Config("EVALUATE_GOOD"));
				break;
			case 'middle':
				$map['evaluate_score'] = intval($this->Config("EVALUATE_MIDDLE"));
				break;
			case 'bad':
				$map['evaluate_score'] = intval($this->Config("EVALUATE_BAD"));
				break;
		}

		$page_num = $this->Config("PAGE_LIST_NUM");
		$evaluationList = D('Evaluate')->where($map)->field('id,user_name,user_avator,lesson_name,evaluate_score,createtime,evaluate')->limit('0,'.$page_num)->select();

		if(!empty($evaluationList) && is_array($evaluationList)){
			foreach($evaluationList as $k=>$v){
				$lesson_name_array = unserialize($v['lesson_name']);
				foreach($lesson_name_array as $key=>$name){
					if($key != 0){
						$evaluationList[$k]['lesson_name'] .= '/'.$name['lesson_name'];
					}else{
						$evaluationList[$k]['lesson_name'] = $name['lesson_name'];
					}
				}

			}
		}
		
		$mapCount = array();
		$mapCount['trainer_id'] = $t_id;

		//评论统计
		$all_num = D('Evaluate')->where($mapCount)->count();

		$mapCount['evaluate_score'] = $this->Config("EVALUATE_GOOD");
		$good_num = D('Evaluate')->where($mapCount)->count();

		$mapCount['evaluate_score'] = $this->Config("EVALUATE_MIDDLE");
		$middle_num = D('Evaluate')->where($mapCount)->count();

		$mapCount['evaluate_score'] = $this->Config("EVALUATE_BAD");
		$bad_num = D('Evaluate')->where($mapCount)->count();

		$tplArray = array('evaluationList'=>$evaluationList,'all_num'=>$all_num,'good_num'=>$good_num,'middle_num'=>$middle_num,'bad_num'=>$bad_num,'type'=>$type,'tid'=>$t_id);
		$this->assign($tplArray);
		$this->display();
	}

	/*
	 * ajax加载学生评价
	 * */
	public function ajaxTrainerEvaluation(){
		$error = new Error();

		if(IS_GET){
			$t_id =  I("get.tid","0","intval");
			if($t_id <= 0){
				$error->setError('102','数据错误');
			}else {
				$page_num = $this->Config("PAGE_LIST_NUM");
				$page = I('get.page');
				$start_num = intval($page) * $page_num;

				$map = array();
				$map['trainer_id'] = $t_id;

				$evaluation_score = I('get.evaluation_type');
				if (!empty($evaluation_score)) {
					switch ($evaluation_score) {
						case 1:
							$map['evaluation_score'] = $this->Config("EVALUATE_GOOD");
							break;
						case 2:
							$map['evaluation_score'] = $this->Config("EVALUATE_MIDDLE");
							break;
						case 3:
							$map['evaluation_score'] = $this->Config("EVALUATE_BAD");
							break;
					}
				}

				$evaluationList = D('Evaluate')->where($map)->field('id,user_name,user_avator,lesson_name,evaluate_score,createtime,evaluate')->limit($start_num . ',' . $page_num)->select();
				if (!empty($evaluationList) && is_array($evaluationList)) {
					foreach ($evaluationList as $k => $v) {
						$lesson_name_array = unserialize($v['lesson_name']);
						foreach ($lesson_name_array as $key => $name) {
							if ($key != 0) {
								$evaluationList[$k]['lesson_name'] .= '/' . $name['lesson_name'];
							} else {
								$evaluationList[$k]['lesson_name'] = $name['lesson_name'];
							}
						}

					}
				}
				$error->setError(0, "", $evaluationList);
			}
		}else{
			$trainerInfo = D('Trainer')->thinkfind(session($this->Config("SESSION_TRAINER_ID")));
			$error->setError(101, "服务当前不可用，请稍后再试",$trainerInfo);
		}

		$this->ajaxReturn($error->getResult());
	}

	/*添加关注*/
	public function  userFoucesTeacher_json(){
		$uid = I('post.uid');
		$tid = I('post.tid');
		$lessonid = I('post.lid');
		if(!$uid || !$tid){
			$json_array['status'] = '400';
			$json_array['text'] = '缺少参数，请退出刷新';
			echo json_encode($json_array);
		}
		$favourite_model = new FavouriteModel();
		$status  =  $favourite_model->getStatusByUidTid($uid,$tid,$lessonid);
		if(!$status){
			$pama['trainer_id'] = $tid;
			$pama['user_id'] = $uid;
			$pama['lesson_id'] = $lessonid;
			$res = $favourite_model->addByUid($pama);
			if($res){
				$json_array['status'] = '200';
				$json_array['text'] = '成功关注';
				echo json_encode($json_array);
			}
		} else {
			$json_array['status'] = '100';
			$json_array['text'] = '您已经关注过了';
			echo json_encode($json_array);
		}
	}

}