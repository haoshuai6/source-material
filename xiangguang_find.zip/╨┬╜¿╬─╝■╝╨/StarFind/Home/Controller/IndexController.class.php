<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/4
 */
namespace Home\Controller;

use Think\Controller;
use Common\BaseClass\WechatCallbackapiTest;
use Think\Log;


class IndexController extends Controller
{

	public function index()
	{
		echo "ok!";
		$this->display();
	}

	public function wxtoken()
	{
		$c = new Config();
		$config = $c->load();
		$wechatObj = new WechatCallbackapiTest($config);
		$wechatObj->valid();

	}
}