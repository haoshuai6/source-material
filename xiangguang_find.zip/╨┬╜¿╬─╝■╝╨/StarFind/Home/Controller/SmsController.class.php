<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/18
 */

namespace Home\Controller;

use Common\BaseClass\Config;
use Common\BaseClass\Error;
use Common\Model\SmsModel;
use Think\Controller;

class SmsController extends Controller
{

	protected $config;

	/**
	 * @return mixed
	 */
	public function getConfig()
	{
		return $this->config;
	}

	public function Config($key)
	{
		return $this->config[$key];
	}

	/**
	 * @param mixed $config
	 */
	public function setConfig($config)
	{
		$this->config = $config;
	}

	public function __construct()
	{
		$this->config = $this->loadConfig();
		parent::__construct();
	}

	private function loadConfig()
	{
		$c = new Config();
		$config = $c->load();
		return $config;
	}

	public function index()
	{
		$mobile = I('get.mobile', "", "checkMobile");
		$type = I('get.type', $this->getConfig("SMS_TYPE_LOGIN"), "intval");

		$error = new Error();
		if (($mobile) && ($type)) {
			$error = $this->sendSMS($mobile, $type);
		} else {
			$error->setError(100, "手机号输入不正确");
		}
		$this->ajaxReturn($error->getResult());
	}


	public function checkCode($mobile, $code, $type)
	{
		$error = new Error();

		if (($mobile) && ($type) && ($code)) {
			$smsmodel = new SmsModel();
			$expiredtime = time() - ($this->getConfig("SMS_EXPIRED_TIME") * 60);
			$sid = $smsmodel->getSms($mobile, $code, $type, $expiredtime);
			if ($sid) {
				$smsmodel->deleteSms($sid);
			} else {
				$error->setError(100, "验证码不正确或者已经过期");
			}
		} else {
			$error->setError(101, "验证无法通过");
		}
		return $error;
	}


	private function sendSMS($mobile, $type)
	{
		$ipaddr = get_client_ip();
		$smsmodel = new SmsModel();

		$error = new Error();
		if (($error->checkResult()) && ($smsmodel->getCountByMobile($mobile) > $this->getConfig("SMS_MAX_MOBILE"))) {
			$error->setError(101, "发送短信数量超过每天最大次数");
		}
		if (($error->checkResult()) && ($smsmodel->getCountByIP($ipaddr) > $this->getConfig("SMS_MAX_IP"))) {
			$error->setError(102, "发送短信数量超过每天最大次数");
		}

		if ($error->checkResult()) {
			$s = $smsmodel->getLastSms($mobile, $type);
			if ($s) {
				if ($s['createtime'] >= (time() - ($this->Config("SMS_MIN_TIME")))) {
					$error->setError(103, "请不要频繁获取验证码,请" . $this->Config("SMS_MIN_TIME") . "秒之后再试！");
				}
			}
		}


		if ($error->checkResult()) {
			$code = $this->genCode();

			// todo sent

			$sent = true;

			if ($sent) {
				$r = $smsmodel->addSms($mobile, $code, $ipaddr, $type);
				if (!$r) {
					$error->setError(200, "短信记录不成功");
				}
			} else {
				$error->setError(200, "短信发送不成功");
			}
		}
		return $error;
	}

	private function genCode($length = 6)
	{
		$num = "";
		if ($length > 0) {
			$num .= rand(1, 9);
			if ($length > 1) {
				$length--;
				for ($i = 0; $i < $length; $i++) {
					$num .= rand(0, 9);
				}
			}
		}
		return $num;
	}

}