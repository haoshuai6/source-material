<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/17
 */
namespace Home\Controller;

use Common\BaseClass\Error;
use Common\BaseClass\StarfindController;
use Common\Model\SmsModel;
use Common\Model\UserModel;
use Common\Model\TrainerModel;
use Common\Model\WxAutologinModel;

class LoginController extends StarfindController
{
	public function index()
	{
//		var_dump($_SESSION);
		$this->redirect("userlogin");
	}

	public function userlogin()
	{
		var_dump($_SESSION);
		var_dump($_COOKIE);
		$re = I('get.re');
		if ($re) {
			$re = urldecode($re);
		} else {
			$re = U("User/Center/index");
		}
		$this->assign('reurl', $re);
		$this->assign('smstype', $this->Config("SMS_TYPE_LOGIN"));
		$this->assign('smsurl', U('Home/Sms'));
		$this->assign('loginurl', U('Home/Login/doUserLogin'));
		$this->assign('smstime', ($this->Config("SMS_MIN_TIME")) * 2);
		$this->display();
	}

	public function doUserLogin()
	{
		$error = new Error();
		$mobile = I("post.mobile", "", "checkMobile");
		$code = I('post.code', "", "checkSmsCode");

		if (($mobile) && ($code)) {

			$smsmodel = new SmsModel();
			$sms = $smsmodel->checkSms($mobile, $this->Config("SMS_TYPE_LOGIN"), $code, (time() - ($this->Config("SMS_EXPIRED_TIME") * 60)));
			/*本地登陆测试，改为$sms = 1;*/
			$sms = 1;
			/**/
			if ($sms) {
				$error = $this->gotoUserLogin($mobile);
			} else {
				$error->setError(101, "短信验证码不正确或者已经过期");
			}
		} else {
			$error->setError(100, "手机号或者短信验证码不正确");
		}

		$this->ajaxReturn($error->getResult());
	}


	private function gotoUserLogin($mobile)
	{
		$error = new Error();

		$login = $this->setUserLogin($mobile, session($this->Config("SESSION_WX_USERID")));
		if (!$login) {
			// 没有手机号先注册，有手机号用户直接登陆
			$usermodel = new UserModel();
			$user = $usermodel->getUser($mobile);
			if (!$user) {
				// 注册手机号
				$uid = $usermodel->addUserByMobile($mobile, session($this->Config("SESSION_INVITE_CODE")));
				// 写入手机号到自动登录表
				if ($uid) {
					$wxusermodel = new WxAutologinModel();
					$wxusermodel->saveWxUser(session($this->Config("SESSION_WX_USERID")), $mobile);
				} else {
					$error->setError(202, "保存用户信息出错");
				}

				$login2 = $this->setUserLogin($mobile, session($this->Config("SESSION_WX_USERID")));
				if (!$login2) {
					$error->setError(212, "服务当前不可用，请稍后再试");
				}
			} else {
				if ($user['state'] != $this->Config("STATE_OK")) {
					$error->setError(201, "用户状态异常");
				} else {
					$error->setError(211, "服务当前不可用，请稍后再试");
				}
			}
		}

		return $error;
	}

	public function trainerlogin()
	{
		$re = I('get.re');
		if ($re) {
			$re = urldecode($re);
		} else {
			$re = U("Trainer/TrainerCenter/trainerHome");
		}
		$this->assign('reurl', $re);
		$this->assign('smstype', $this->Config("SMS_TYPE_LOGIN"));
		$this->assign('smsurl', U('Home/Sms'));
		$this->assign('loginurl', U('Home/Login/doTrainerLogin'));
		$this->assign('smstime', ($this->Config("SMS_MIN_TIME")) * 2);
		$this->display();
	}

	public function doTrainerLogin()
	{
		$error = new Error();
		$mobile = I("post.mobile", "", "checkMobile");
		$code = I('post.code', "", "checkSmsCode");

		if (($mobile) && ($code)) {

			$smsmodel = new SmsModel();
			$sms = $smsmodel->checkSms($mobile, $this->Config("SMS_TYPE_LOGIN"), $code, (time() - ($this->Config("SMS_EXPIRED_TIME") * 60)));
			if ($sms) {
				$error = $this->gotoTrainerLogin($mobile);
			} else {
				$error->setError(101, "短信验证码不正确或者已经过期");
			}
		} else {
			$error->setError(100, "手机号或者短信验证码不正确");
		}

		$this->ajaxReturn($error->getResult());
	}


	private function gotoTrainerLogin($mobile)
	{
		$error = new Error();

		$login = $this->setTrainerLogin($mobile, session($this->Config("SESSION_WX_USERID")));
		if ($login) {
			$trainermodel = new TrainerModel();
			$trainer = $trainermodel->getTrainerByMobile($mobile);

			if (!$trainer) {
				$error->setError(202, "用户信息不存在");
			} else {
				if ($trainer['state'] != $this->Config("STATE_OK")) {
					$error->setError(201, "用户状态异常");
				}
			}
		}else{
			$error->setError(202, "用户信息不存在");
		}

		return $error;
	}

	public function userLogout()
	{
		$this->setUserLogout();
		// 自动跳转到首页
		$this->redirect("Home/Index/index");
	}


	public function trainerLogout()
	{
		$this->setTrainerLogout();
		// 自动跳转到首页
		$this->redirect("Home/Index/index");
	}
}