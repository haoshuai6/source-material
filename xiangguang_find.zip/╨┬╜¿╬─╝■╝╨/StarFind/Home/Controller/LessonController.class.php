<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/24
 */
namespace Home\Controller;

use Common\BaseClass\StarfindController;
use Common\Model\AreaModel;
use Common\Model\FavouriteModel;
use Common\Model\LessonInfoModel;
use Common\Model\LessonModel;
use Common\Model\TrainerAddressModel;
use Common\Model\TrainerModel;

class LessonController extends StarfindController
{
	// http://127.0.0.1/201611_ThinkPHP_XingGuang_Find/Lesson/detail/id/40
	public function detail()
	{
		$lesson_id = I('get.id', 0, "intval");
		if (!$lesson_id) {
			$this->error("无法获取课程信息");
		}

		$lessonmodel = new LessonModel();
		$lesson = $lessonmodel->getLesson($lesson_id);
		if (!$lesson) {
			$this->error("无法获取课程信息");
		}

		$trainermodel = new TrainerModel();
		$trainer = $trainermodel->getTrainer($lesson['trainer_id']);
		$trainer_address_model = new TrainerAddressModel();
		$trainer_address_info = $trainer_address_model->getTrainerAdderss($lesson['trainer_id']);
		$area_info_str = '';
		$area_model  = new AreaModel();
		$area_info =  $area_model->getArea_recu($trainer_address_info['area_id']);
		$area_info_array = explode(',',$area_info);
		$area_info_array = array_reverse($area_info_array);
		if($area_info_array && is_array($area_info_array)){
			foreach ($area_info_array as $k => $a_list) {
				if($k==0){
					continue;
				}
				$area_info_str .= $a_list .' ';
			}
		}
		$area_info_str =  rtrim($area_info_str, ' ');
		$trainer['address'] = $area_info_str;

		if (!$trainer) {
			$this->error("无法获取培训机构信息");
		}

		$teacher = array();
		if ($trainer['trainer_classid'] == $this->Config("CLASS_TRAINER_ORGANIZATION")) {/*机构*/
			$teacher = $lessonmodel->getOrgLessonTeacher($lesson_id);
		} else if ($trainer['trainer_classid'] == $this->Config("CLASS_TRAINER_PERSON")) {
			$teacher[] = $trainer;
		} else {
			$this->error("无法获取老师信息");
		}
		
		$lessoninfomodel = new LessonInfoModel();
		$lesson_info = $lessoninfomodel->getLessonInfo($lesson_id);
       
		//$token = $this->token_get();
		$favourite_model = new FavouriteModel();
		/*当前用户是否关注*/
		$uid =  session($this->Config("SESSION_USER_ID"));
		$fens_status =  $favourite_model->getStatusByUidTid($uid,$lesson['trainer_id'],$lesson_id);
		if($fens_status){
			$tplArray['fens_status'] = 1;
		}
		if($trainer['trainer_classid']){
			if($trainer['trainer_classid'] == $this->Config('CLASS_TRAINER_ORGANIZATION')){/*机构*/
				$trainer['trainer_classid'] = 1;
			}else {
				$trainer['trainer_classid'] = 2;
			}
		}

		$ids = array();
		$ids['uid'] = $uid;
		$ids['tid'] = $lesson['trainer_id'];
		$ids['lid'] = $lesson_id;
		$tplArray['ids'] = $ids;
		$tplArray['lesson'] = $lesson;
		$tplArray['trainer'] = $trainer;
		$tplArray['teacher'] = $teacher;
		$tplArray['lesson_info'] = $lesson_info;
		$this->assign('data',$tplArray);
		$this->display();
	}
}