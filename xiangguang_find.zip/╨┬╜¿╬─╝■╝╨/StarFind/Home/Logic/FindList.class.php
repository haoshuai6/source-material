<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/8
 */
namespace Home\Logic;

class FindList
{

	public function getLessonList($lesson_class_id=0, $area_id , $page = 1, $prepage = 10)
	{
		return 'fl';
	}


}