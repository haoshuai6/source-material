<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/17
 */

namespace User\Controller;

use Common\BaseClass\OrderStatus;
use Common\BaseClass\StarfindUserController;
use Common\Model\AreaModel;
use Common\Model\ArticleClassModel;
use Common\Model\ArticleModel;
use Common\Model\EvaluateModel;
use Common\Model\FavouriteModel;
use Common\Model\LessonClassModel;
use Common\Model\OrderLessonModel;
use Common\Model\OrderModel;
use Common\Model\SigninModel;
use Common\Model\UserModel;
use Common\Model\UserVoucherModel;
use Common\Model\VoucherModel;


class CenterController extends StarfindUserController
{
	// http://127.0.0.1/201611_ThinkPHP_XingGuang_Find/User/Center
	public function index()
	{
		/*var_dump($_SESSION);*/
		$center_data = array();

		$center_data['user_id'] = $this->getUserId();
		$user_model = new UserModel();
		$user_info =  $user_model->getUserInfo($this->getUserId());
		$center_data['point'] = $user_info['point'];
		$center_data['user_name'] = $user_info['username'];
		$center_data['user_avator'] = $user_info['avator'];
		
		$center_data['voucher_nums'] = $user_info['voucher_nums'];
		if(!$user_info['invite_code']){
			$user_info['invite_code'] = '暂无推荐码';
		}
		$center_data['invite_code'] = $user_info['invite_code'];
		$center_data['service_phone'] = $this->Config('SERVICE_PHONE');
		
		$this->assign('center_data',$center_data);
		$this->display();
	}
	public function base64_to_img_local( $base64_string, $output_file ) {
		$ifp = fopen( $output_file, "wb" );
		fwrite( $ifp, base64_decode( $base64_string) );
		fclose( $ifp );
		return( $output_file );
	}
	public function edit(){
		$user_model = new UserModel();
		if(IS_POST){
			$p_data = I('post.');
			if(!empty($p_data['wximg_upload'])){
				$savename = uniqid().'.jpeg';
				$savedir = __ROOT__.'Uploads/ucenter/';
				$savepath = $savedir .$savename;
				if(is_dir($savedir)){
					//savedir is  exist
					//$image = $this->base64_to_img_local( $v, $savepath );
					$this->base64_to_img_local(trim($p_data['wximg_upload']), $savepath );
					$p_data['avator'] =  $savepath;
				}else{
					$p_data['avator'] =  '';
				}
			}

			if($p_data['age']){
				$p_data['age'] = intval(date('Y') - $p_data['age']);//年份
			}
		
			$res = $user_model->updateUserByuid($p_data['user_id'],$p_data);
			if($res !== false){
				session($this->Config("SESSION_USER_NAME"), $p_data['username']);
				session($this->Config("SESSION_USER_AVATOR"), $p_data['avator']);
				$this->success("信息修改成功！",U('User/Center/index'));
			}else {
				$this->error("信息修改失败！",U('User/Center/index'));
			}
		}else{
			$sid = I('get.id');
			if($sid != $this->getUserId()){
				$this->error("参数错误，请退出刷新页面！");
			}

			$less_class_model = new LessonClassModel();
			$less_class_list = $less_class_model->getLessonClassList();

			$user_data  = $user_model->getUserInfo(intval($this->getUserId()));

			if($user_data['age']){
				$user_data['age'] = intval(date('Y') - $user_data['age']);
			}

			$user_data['sex_show'] = $user_data['sex'] == 1  ?  '男': '女';
			$user_data['trained_show'] = $user_data['trained'] == 1  ?  '有': '无';

			if($user_data['want_class_id']){
				$user_data['ps_name'] = $less_class_model->getLessonParentClass($user_data['want_class_id']);
			}
			$area_info_str = '';
            $area_model = new AreaModel();
			$area_info = $area_model->getArea_recu($user_data['area_id']);//历下区 济南市 山东省 反转
			$area_info_array = explode(',',$area_info);
			$area_info_array = array_reverse($area_info_array);
			if($area_info_array && is_array($area_info_array)){
				foreach ($area_info_array as $k => $a_list) {
					if($k==0){
						continue;
					}
					$area_info_str .= $a_list .' ';
				}
			}
			$area_info_str =  rtrim($area_info_str, ' ');
			$user_data['area_info'] =  $area_info_str;

			$this->assign('user_data',$user_data);
			$this->assign('less_class_list',json_encode($less_class_list));
			$this->display();
		}
	}
	public function myOrderList(){
		$uid = I('get.id');
		if($uid != $this->getUserId()){
			$this->error("参数错误，请退出刷新页面！");
		}
		$order_model = new OrderModel();

		/*数量查询*/
		$order_info = array();
		/*待付款*/
		$waitpay_code = $order_model->getOrderstatus('waitpay');

		$order_info['waitpay'] = $order_model->getCountByState($waitpay_code);
		/*已付款*/
		$yetpays_code = $order_model->getOrderstatus('yetpays');
		$order_info['yetpays'] = $order_model->getCountByState($yetpays_code);
		/*已退课*/
		$refund_code = $order_model->getOrderstatus('refund');
		$order_info['refund'] = $order_model->getCountByState($refund_code);
		/*待评价*/
		$finish_code = $order_model->getOrderstatus('finish');
		$order_info['finish'] = $order_model->getCountByState($finish_code);

		$this->assign('order_info',$order_info);

		$this->assign('uid',$uid);
		$this->display();
	}
	public function myOrderList_json(){
		$uid = I('post.id');
		$state_order = I('post.state');
		if($uid != $this->getUserId() || !$state_order){
			$this->error("参数错误，请退出刷新页面！");
		}
         
		$order_lesson_model = new OrderLessonModel();
		$order_model = new OrderModel();
		$order_s_code = $order_model->getOrderstatus(trim($state_order));
		$myOrderList = $order_lesson_model->getLessonByUid($uid,$order_s_code);
		if($myOrderList && is_array($myOrderList)){
			foreach ($myOrderList as $m => $m_list){
				 $myOrderList[$m]['verify_wait'] = $this->Config('ORDER_VERIFY_WAIT');
				 if($m_list['state_verify'] == $this->Config('ORDER_VERIFY_WAIT')){ //等待审核
					$myOrderList[$m]['state_verify'] = '等待审核';
				 }
				 $myOrderList[$m]['verify_error'] = $this->Config('ORDER_VERIFY_ERROR');
				 if($m_list['state_verify'] == $this->Config('ORDER_VERIFY_ERROR')){ //审核不通过，显示已取消
					$myOrderList[$m]['state_verify'] = '未通过审核';
				 }
				 $myOrderList[$m]['state_verify_code'] = $m_list['state_verify'];
				 $os = $order_model->getOrderOpt($m_list['state_order']);
				 $myOrderList[$m]['state_order'] = $os;
				/* $orderstatus = new OrderStatus($order_model->getConfig());
				 $opt = $orderstatus->getOrderOperate($m_list);
				 $myOrderList[$m]['state_order'] = $opt;*/

				 $myOrderList[$m]['create_time'] = date('Y-m-d H:i:s',$m_list['createtime']);
				 $myOrderList[$m]['time_create'] = date('Y-m-d H:i:s',$m_list['time_create']);
			}
		}

		$json_array['lists'] = $myOrderList;
		echo   json_encode($json_array);
	}
	public function myFocusList(){
		$uid = I('get.id');
		if($uid != $this->getUserId()){
			$this->error("参数错误，请退出刷新页面！");
		}
		$this->assign('uid',$uid);
		$this->display();
	}
	public function myFocusList_json(){
		$uid = I('post.id');
		if($uid != $this->getUserId()){
			$this->error("参数错误，请退出刷新页面！");
		}
		$favourite_model = new FavouriteModel();
		$myFocusList = $favourite_model->getInfoByUid($uid);
		if($myFocusList && is_array($myFocusList)){
			foreach ($myFocusList as $m => $m_list){
				$myFocusList[$m]['trainer_type'] = $m_list['trainer_classid'] == $this->Config('CLASS_TRAINER_ORGANIZATION') ? '机构':'个人';
			}
		}
		$json_array['lists'] = $myFocusList;
		echo   json_encode($json_array);
	}
	public function myCouponList(){
		$uid = I('get.id');
		if($uid != $this->getUserId()){
			$this->error("参数错误，请退出刷新页面！");
		}

		/*优惠券使用帮助文章*/
		$article_class_model = new ArticleClassModel();
		$article_model = new ArticleModel();
		$pinfo = $article_class_model->getValByKey('CENTER_COUPON_PLAIN');
		$coupinfo = $article_model->getInfoByClassid($pinfo['value']);
		$this->assign('coupinfo',$coupinfo);

		$this->assign('uid',$uid);
		$this->display();
	}
	public function myCouponList_json(){
		$uid = I('post.id');
		if($uid != $this->getUserId()){
			$this->error("参数错误，请退出刷新页面！");
		}
		$UserVoucher_model = new UserVoucherModel();
		$voucher_model = new VoucherModel();
		$myCouponList = $UserVoucher_model->getVoucherByUid($uid);
		
		if($myCouponList && is_array($myCouponList)){
			foreach ($myCouponList as $m => $m_list){
				if($m_list['vou_info'] && is_array($m_list['vou_info'])){
					foreach ($m_list['vou_info'] as $mv=> $mv_list){
						$myCouponList[$m]['vou_info'][$mv]['pricelimit_text'] ='';
						if($mv_list['pricelimit'] >0){
							$myCouponList[$m]['vou_info'][$mv]['pricelimit_text'] = "满 ".$mv_list['pricelimit']."元使用，不可叠加使用。";
						}
						$type = $voucher_model->getVoucherType($mv_list['voucher_class_id']);
						$myCouponList[$m]['vou_info'][$mv]['voucher_class_type'] = $type['name'];
						$myCouponList[$m]['vou_info'][$mv]['start_time'] = date('Y-m-d H:i:s',$mv_list['giveout_starttime']);
						$myCouponList[$m]['vou_info'][$mv]['end_time'] = date('Y-m-d H:i:s',$mv_list['giveout_endtime']);
					}
				}
				if($m_list['voucher_state'] == $this->Config('VOUCHER_STATE_USED')){/*已使用*/
					$myCouponList[$m]['voucher_class_text']  = '已使用';
				}
				if($m_list['voucher_state'] == $this->Config('VOUCHER_STATE_EXPIRED')){/*已过期*/
					$myCouponList[$m]['voucher_class_text']  = '已过期';
				}

			}
		}
		$json_array['lists'] = $myCouponList;
		echo   json_encode($json_array);
	}
	public function myEvaluationList(){
		$uid = I('get.id');
		$level = I('get.level');
		if($uid != $this->getUserId()){
			$this->error("参数错误，请退出刷新页面！");
		}
		$eval_model = new EvaluateModel();
		$all_num = $eval_model->getCountEvalByLevel($uid,0);
		$bad_num = $eval_model->getCountEvalByLevel($uid,1);
		$center_num = $eval_model->getCountEvalByLevel($uid,3);
		$good_num = $eval_model->getCountEvalByLevel($uid,5);

		$eval_nums['all_num'] = $all_num;
		$eval_nums['bad_num'] = $bad_num;
		$eval_nums['center_num'] = $center_num;
		$eval_nums['good_num'] = $good_num;

		$this->assign('eval_nums',$eval_nums);
		$this->assign('uid',$uid);
		$this->assign('level',$level);
		$this->display();
	}
	public function myEvaluationList_json(){
		$uid = I('post.id');
		$level = I('post.level');
		if($uid != $this->getUserId()){
			$this->error("参数错误，请退出刷新页面！");
		}
		$eval_model = new EvaluateModel();
		
		$myevalList = $eval_model->getEvalByLevel($uid,$level);
		if($myevalList && is_array($myevalList)){
			foreach ($myevalList as $m => $m_list){
				$lesson_name = unserialize($m_list['lesson_name']);
				$lesson_name_str = '';
				if(is_array($lesson_name)){
					foreach ($lesson_name as $ls => $ls_list) {
						$lesson_name_str .=  $ls_list['lesson_name'] .'<br />';
					}
				}
				$myevalList[$m]['lesson_name'] = $lesson_name_str;
				$myevalList[$m]['user_name'] = $this->getUserName();
				$myevalList[$m]['createtime'] = date('Y-m-d H:i',$m_list['createtime']);
			}

		}

		$json_array['lists'] = $myevalList;
		echo   json_encode($json_array);

	}
	public function myPointList(){
		$uid = I('get.id');
		if($uid != $this->getUserId()){
			$this->error("参数错误，请退出刷新页面！");
		}
		/*积分说明文章*/
		$article_class_model = new ArticleClassModel();
		$article_model = new ArticleModel();
		$pinfo = $article_class_model->getValByKey('CENTER_VOUCHER_PLAIN');
		$pointinfo = $article_model->getInfoByClassid($pinfo['value']);
		$this->assign('pointinfo',$pointinfo);

		$user_model = new UserModel();
		$user_info =  $user_model->getUserInfo($this->getUserId());
		$this->assign('user_info',$user_info);
		$this->assign('uid',$uid);
		$this->display();
	}
	public function myPointList_json(){
		$uid = I('post.id');
		if($uid != $this->getUserId()){
			$this->error("参数错误，请退出刷新页面！");
		}
		$voucher_model = new VoucherModel();
		$myvoucher = $voucher_model->getVoucherList();

		if($myvoucher && is_array($myvoucher)){
			foreach ($myvoucher as $m => $m_list){
				if($m_list['points'] == 0){
					$myvoucher[$m]['points_text'] = '免积分兑换';
				}
				$myvoucher[$m]['pricelimit_text'] = '';
				if($m_list['pricelimit'] >0){
					$myvoucher[$m]['pricelimit_text'] = "满 ".$m_list['pricelimit']."元使用，不可叠加使用.";
				}
				$myvoucher[$m]['over_num'] = intval($m_list['total']-$m_list['giveout']);

				$myvoucher[$m]['start_time'] = date('Y-m-d H:i:s',$m_list['use_starttime']);
				$myvoucher[$m]['end_time'] = date('Y-m-d H:i:s',$m_list['use_endtime']);
				$myvoucher[$m]['give_start_time'] = date('Y-m-d H:i:s',$m_list['giveout_starttime']);
				$myvoucher[$m]['give_end_time'] = date('Y-m-d H:i:s',$m_list['giveout_endtime']);
			}
		}
		$json_array['lists'] = $myvoucher;
		echo   json_encode($json_array);
	}
    /*兑换优惠券json*/
	public function myChangeVouchar(){
		$vid = I('post.vid');
		if(!$vid){
			$json_array['status'] = '400';
			$json_array['text'] = '缺少参数，请退出刷新';
			echo json_encode($json_array);
			return;
		}
		$voucher_user_model = new UserVoucherModel();
		$voucher_model = new VoucherModel();
		$voucher_info = $voucher_model->getVoucherByid($vid);
		/*检测积分剩余*/
		$uer_model = new UserModel();
		$user_info =   $uer_model->getUserInfo($this->getUserId());

		/*领取时间*/
		if($voucher_info['giveout_starttime'] <= time() ) {
			if (time() <= $voucher_info['giveout_endtime']) {
				/*剩余数量*/
				if (intval($voucher_info['total'] - $voucher_info['giveout']) >= 1) {
					/*允许领取优惠券数量*/
					$already_num = $voucher_user_model->checkVoucherByUidVid($this->getUserId(), $vid);
					if ($voucher_info['eachlimit'] == 0) { /*不限制领取数量*/
						$pama = array();
						$pama['user_id'] = $this->getUserId();
						$pama['user_name'] = $this->getUserName();
						$pama['voucher_id'] = intval($vid);
						$user_model = new UserModel();
						$result = $user_model->addVoucherByUserPoint($pama, 0);
						if ($result) {
							$json_array['status'] = '200';
							$json_array['text'] = '兑换成功！';
							echo json_encode($json_array);
						} else {
							$json_array['status'] = '400';
							$json_array['text'] = '兑换失败！';
							echo json_encode($json_array);
						}
					} else {
						if($user_info && is_array($user_info)) {
							if ($user_info['point'] >= $voucher_info['points']) {
								if ($already_num < $voucher_info['eachlimit']) {

									/*给用户加优惠券*//*减去积分*/
									$points_v = intval($voucher_info['points']);
									$pama = array();
									$pama['user_id'] = $this->getUserId();
									$pama['user_name'] = $this->getUserName();
									$pama['voucher_id'] = intval($vid);
									$user_model = new UserModel();
									$result = $user_model->addVoucherByUserPoint($pama, $points_v);
									if ($result) {
										$json_array['status'] = '200';
										$json_array['text'] = '兑换成功！';
										echo json_encode($json_array);
									} else {
										$json_array['status'] = '400';
										$json_array['text'] = '兑换失败！';
										echo json_encode($json_array);
									}
								} else {
									$json_array['status'] = '150';
									$json_array['text'] = '优惠券单人限领量超限';
									echo json_encode($json_array);
								}
							}else {
								$json_array['status'] = '130';
								$json_array['text'] = '您的积分不足！';
								echo json_encode($json_array);
							}
						}else {
							$json_array['status'] = '120';
							$json_array['text'] = '参数错误';
							echo json_encode($json_array);
						}
					}
				} else {
					$json_array['status'] = '100';
					$json_array['text'] = '优惠券发放完啦';
					echo json_encode($json_array);
				}
			}else {
				$json_array['status'] = '50';
				$json_array['text'] = '优惠券领取时间结束';
				echo json_encode($json_array);
			}
		}else {
			$json_array['status'] = '10';
			$json_array['text'] = '优惠券还未开放领取';
			echo json_encode($json_array);
		}
	}
	public function sign_in(){
		$uid = I('post.id');
		if(!$uid){
			$json_array['status'] = '400';
			$json_array['text'] = '缺少参数，请退出刷新';
			echo json_encode($json_array);
			return;
		}
		if($uid!=$this->getUserId()){
			$json_array['status'] = '300';
			$json_array['text'] = '缺少参数，请退出刷新';
			echo json_encode($json_array);
			return;
		}
		$time = time();
		$sign_model = new SigninModel();

		$count = $sign_model->check_user_sign($uid,$time);
		if($count < 1){
			$param = array();
			$param['uid'] = $uid;
			$param['time'] = $time;
			$res = $sign_model->addSignin($param);
			if($res){
				$param['user_name'] = $this->getUserName();
				$points  = $this->Config('SIGN_IN_ADD_POINT_NUM');
				$day = date('Y-m-d H:i:s');
				$result = $sign_model->addPointBySign($param,$points,$day);
				if($result){
					$json_array['status'] = '200';
					$json_array['text'] = '签到成功,增加'.$points.'积分';
					echo json_encode($json_array);
				}else {
					$json_array['status'] = '160';
					$json_array['text'] = '签到失败';
					echo json_encode($json_array);
				}
			} else {
				$json_array['status'] = '150';
				$json_array['text'] = '签到失败';
				echo json_encode($json_array);
			}
		}else {
			$json_array['status'] = '100';
			$json_array['text'] = '每人每天限一次';
			echo json_encode($json_array);
		}
	}

	public function myInvite(){
		$this->config();
		/*uid*/
		$uid = I('get.id');
		if(!$uid || $uid!=$this->getUserId()){
			$this->error("参数错误，请退出刷新页面！");
		}
		$data = array();
		$sharedata = array();
		/*生成推荐码*/
		$new_invite_code = uniqid();
		/*检测推荐码*/
		$user_model = new UserModel();
		$uinfo = $user_model->checkInvite($uid);
		if($uinfo){
			if(empty($uinfo['invite_code'])){
				/*update用户的推荐码*/
				$up_res = $user_model->updateInviteByid($new_invite_code,$uid);
				if($up_res !== false){
					/*去拼接URL*/
					$re_url = U('User/Center/index',array('f'=>$new_invite_code),TRUE,TRUE); //url
					$sharedata['link'] = $re_url ;
					/*二维码保存路径 Uploads/qrcodes/*/
					$path = 'Uploads/qrcodes/';
					$img_name = md5($uid).'.png';
					$path_name = $path.$img_name;/* 'Uploads/qrcodes/qrcode.png'*/

					$renderer = new \BaconQrCode\Renderer\Image\Png();
					$renderer->setHeight(256);
					$renderer->setWidth(256);
					$renderer->setMargin(1);
					$writer = new \BaconQrCode\Writer($renderer);
					$writer->writeFile($re_url, $path_name);
					$data['qrcode_img'] = __ROOT__.'/'.$path_name;
				}
			}else {/*已经生成过推荐码*/
				$data['qrcode_img'] = __ROOT__.'/Uploads/qrcodes/'.md5($uid).'.png';
				$re_url = U('User/Center/index',array('f'=>$uinfo['invite_code']),TRUE,TRUE); //url;
				$sharedata['link'] = $re_url ;
			}
		}else {
			$this->error('参数错误，请退出刷新');
		}

		/*分享*/
		$signPackage = $this->getWechatSignPackage();
		$this->assign('signPackage',$signPackage);

		/**
		 * todo 待添加 sharedata
		 * 
		 *  */
		/*$sharedata['title'] = ;
		$sharedata['desc'] = ;

		$sharedata['imgUrl'] = ;*/
		$this->assign('sharedata',$sharedata);

		$this->assign('data',$data);
		$this->display();
	}

}