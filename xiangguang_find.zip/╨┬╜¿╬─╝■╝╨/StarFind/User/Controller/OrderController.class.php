<?php
/**
 * Created by Wang.Gang@SDTY
 * Mailto glogger#gmail.com
 * 2016/11/22
 */
namespace User\Controller;

use Common\BaseClass\Order;
use Common\BaseClass\StarfindUserController;
use Common\Model\EvaluateModel;
use Common\Model\LessonInfoModel;
use Common\Model\LessonModel;
use Common\Model\OrderLessonModel;
use Common\Model\OrderModel;
use Common\Model\OrderPayModel;
use Common\Model\PaymentModel;
use Common\Model\UserModel;
use Common\Model\VoucherModel;
use Common\BaseClass\Error;


class OrderController extends StarfindUserController
{

    //  http://127.0.0.1/201611_ThinkPHP_XingGuang_Find/User/Order

    // 测试下订单
    public function index()
    {
        $o = new Order();

        // id=>数量
        $lessonarray = array(
            '12' => 2,
            '15' => 3,
            '25' => 4
        );


        $address = array(
            'contact_name' => '',
            'content_mobile' => '',
            'content_address1' => '',
            'content_address2' => '',
        );

        $demo = "";

        $token = "OyO8aW1aOS25cuTJy3mPCod3a9kH6Gkb";

        if ($this->token_check($token)) {
            $e = $o->newOrder($this->getUserId(), $lessonarray, $address, $demo);
            if ($e->checkResult()) {
                $this->token_refresh();
                $this->success("订单成功生成");
            } else {
                $this->error("订单生成失败," . $e->getText());
            }
        } else {
            $this->error("订单生成失败,请不要重复提交订单");
        }
    }

    //订单确定
    public function orderConfirm(){
        $lesson_id = I('get.lesson_id',0,'intval');

        if($lesson_id > 0){
            $lessonInfo = D('Lesson')->getLesson($lesson_id);
            if(empty($lessonInfo)) {
                $this->error('数据错误');
            }else{
                $user = array();
                $user['username'] = $this->getUserName();
                $user['mobile'] = $this->getUserMobile();

                $this->assign('lessonInfo',$lessonInfo);
                $this->assign('userInfo',$user);
                $this->display();
            }
        }else{
            $this->error('数据错误');
        }
    }

    //学员下单
    public function ajaxCreateOrder(){
        $error = new Error();
        if(IS_POST){
            $lesson_id = I('post.lesson_id',0,'intval');
            $contact_name = I('post.contact_name','','trim');
            $contact_mobile = I('post.contact_mobile','','trim');
            $demo = I('post.demo','','trim');

            if($lesson_id > 0){
                $lessonInfo = D('Lesson')->getLesson($lesson_id);
                if(empty($lessonInfo)){
                    $error->setError('102','数据错误');
                }else{

                    $user = array();
                    $user['id'] = $this->getUserId();
                    $user['username'] = $this->getUserName();
                    $user['mobile'] = $this->getUserMobile();

                    $price = array();
                    $price['lesson'] = $lessonInfo['price'];
                    $price['shipping'] = 0;

                    $shop = array();
                    $shop['name'] = D('Trainer')->getFieldById($lessonInfo['trainer_id'],'title');

                    $address = array();
                    $address['contact_name'] = $contact_name;
                    $address['contact_mobile'] = $contact_mobile;
                    $address['contact_address1'] = '';
                    $address['contact_address2'] = '';

                    $order_sn = D('Order')->genOrderSn($user['user_id']);
                    $order_id = D('Order')->createOrder($user, $lessonInfo['trainer_id'], $price, $shop, $address, $order_sn, $demo);

                    if($order_id > 0){
                        $order_lesson = array();
                        $order_lesson[$lesson_id] = array(
                            'nums'=>1,
                            'name'=>$lessonInfo['title'],
                            'image'=>$lessonInfo['image'],
                            'price'=>$lessonInfo['price'],
                            'lesson_nums'=>$lessonInfo['lesson_nums']
                        );

                        D('OrderLesson')->createOrderLesson($order_id,$order_lesson);

                        $error->setError('0','成功创建订单',array('order_id'=>$order_id));
                    }else{
                        $error->setError('102','数据错误');
                    }
                }
            }else{
                $error->setError('102','数据错误');
            }
        }else{
            $error->setError('101','服务器错误');
        }

        $this->ajaxReturn($error->getResult());
    }

    // 订单准备支付页面,可以选择优惠券，使用积分
    //http://127.0.0.1/201611_ThinkPHP_XingGuang_Find/User/Order/payOrder/orderid/5
    public function payOrder()
    {
        $order_id = I('orderid', 0, "intval");
        /*判断该订单当前状态*/
        if ($order_id) {
            $o = new Order();
            $user_id = $this->getUserId();
            $pay = $o->getOrderInfo($order_id, $user_id);
            $errorinfo = $pay->getResult();
            if($errorinfo['result']) {
                $payinfo = $pay->getData();
                if ($payinfo['voucher_list'] && is_array($payinfo['voucher_list'])) {
                    foreach ($payinfo['voucher_list'] as $p => $p_list) {
                        $voucher_model = new VoucherModel();
                        $payinfo['voucher_list'][$p]['pricelimit_text'] = '';
                        if ($p_list['pricelimit'] > 0) {
                            $payinfo['voucher_list'][$p]['pricelimit_text'] = "满 " . $p_list['pricelimit'] . "元使用，不可叠加使用。";
                        }
                        $type = $voucher_model->getVoucherType($p_list['voucher_class_id']);
                        $payinfo['voucher_list'][$p]['voucher_class_type'] = $type['name'];
                        $payinfo['voucher_list'][$p]['start_time'] = date('Y-m-d H:i:s', $p_list['use_starttime']);
                        $payinfo['voucher_list'][$p]['end_time'] = date('Y-m-d H:i:s', $p_list['use_endtime']);
                    }
                }
                $need_point = floatval($this->Config('POINT_TO_MONEY'));
                $tomoney = floatval($payinfo['point_limit'] / $need_point);
                $money = round($tomoney, 2);
                $payinfo['voucher_money'] = $money;
                $payinfo['order_id'] = $order_id;

                $this->assign('payinfo', $payinfo);
                $this->display();
            }else{
                $this->error($errorinfo['text'],U('User/Center/myOrderList',array('id'=>$user_id)));
            }
        } else {
            $this->error("没有找到订单");
        }
    }

    // http://127.0.0.1/201611_ThinkPHP_XingGuang_Find/User/Order/doPayOrder/orderid/19/point/0/voucher/0/payment/1

    // 选择优惠后，点击支付
    public function doPayOrder()
    {
        // todo 正式使用时，改成post方式
        $order_id = I('post.orderid', 0, "intval");
        $point = I('post.point', 0, 'intval');/*使用积分*/
        $voucher = I('post.voucher_id', 0, 'intval');/*优惠券id*/
        $payment = I('post.payment', 0, 'intval');/*支付方式id*/
        $user_id = $this->getUserId();

        if ($order_id) {
            if ($payment) {
                $o = new Order();
                $user_id = $this->getUserId();
                $pay = $o->getOrderInfo($order_id, $user_id);
                if ($pay->checkResult()) {

                    $e = $o->doOrderPrice($this->getConfig(), $pay->getData(), $order_id, $point, $voucher, $payment, $user_id);
                    if ($e->checkResult()) {
                        $er = $o->doPayOrder($e->getData());
                        if ($er->checkResult())
                        {
                            $erd = $er->getData();
                            if ($erd['paid'])
                            {
                                if ($erd['payment']['payment_string'] == $this->Config("PAYMENT_OFFLINE_STRING"))
                                {
                                    $this->success("订单线下支付成功，请等待培训人员确认",U('User/Center/myOrderList',array('id'=>$user_id)));
                                }
                                else {
                                    $this->success("订单在线支付成功",U('User/Center/myOrderList',array('id'=>$user_id)));
                                }
                            }
                            else
                            {   // todo 跳转到在线支付页面
                                $order_pay = new OrderPayModel();
                                $order_data = $pay->getData();
                                $c_ip = get_client_ip(0);
                                $pay_info = $order_pay->getLastOrderPayByOrderId($order_id);
                               
                                $post_data['method'] = 'submitOrderInfo'; /*提交订单*/
                                $post_data['out_trade_no'] = $order_data['data_info']['sn_order'];/*商户订单号*/
                                $post_data['sub_openid'] = '';/*微信用户openid*/
                                $post_data['body'] = $order_data['data_info']['title_trainer'] . '--课程';/*商品描述*/
                                //$post_data['total_fee'] = $pay_info['pay_online'] * (10*10);/*总金额(以分为单位)*/
                                $post_data['total_fee'] = 1;
                                $post_data['mch_create_ip'] = $c_ip;/*订单生成的机器 IP*/
                                $callback_url =  U('User/Order/index','',TRUE,TRUE);
                                $notify_url =  U('User/Order/swiftPayNotify','',TRUE,TRUE);
                                $post_data['callback_url'] = $callback_url;//交易完成后前台页面显示 URL，需给绝对路径，
                                $post_data['notify_url'] = $notify_url;//结果作为支付最终结果
                                $swiftpay = new \Common\SwiftPay\Request();
                                $json_return = $swiftpay->s_request($post_data);
                                $back_array  = json_decode($json_return,TRUE);
                                if($back_array['status'] == 200){
                                    $to_swift_url = 'https://pay.swiftpass.cn/pay/jspay?token_id='.$back_array['token_id'].'&showwxtitle=1';
                                    //重定向到swiftpay在线支付页面
                                    header("Location: $to_swift_url");
                                } else {
                                  $this->error($back_array['msg'],U('User/Center/myOrderList',array('id'=>$user_id)));
                                }
                                exit;
                            }
                        }
                        else
                        {
                            $this->error($er->getText());
                        }
                    } else {
                        $this->error($e->getText());
                    }

                } else {
                    $this->error($pay->getText());
                }
            } else {
                $this->error("没有选择支付方式");
            }
        } else {
            $this->error("没有找到订单");
        }
    }
    public function order_info(){
        $order_id = I('orderid', 0, "intval");
        $order_model = new OrderModel();
        $order_info  = $order_model->getOrder($order_id);
        if ($order_id || !$order_info) {

            $order_info['order_state'] = $order_model->getOrderOpt($order_info['state_order']);
            $order_lesson_model = new OrderLessonModel();
            $lesson_list = $order_lesson_model->getLessonByOrderid($order_id);

            $lesson_info_model = new LessonInfoModel();
            $lesson_model = new LessonModel();
            if($lesson_list && is_array($lesson_list)){
                foreach ($lesson_list as $l => $lelist){
                    $lesson_content = $lesson_model->getLesson($lelist['lesson_id']);
                    $lesson_list[$l]['lesson_content'] = $lesson_content;
                    $class_info = $lesson_info_model->getLessonInfo($lelist['lesson_id']);
                    $lesson_list[$l]['lesson_info'] = $class_info;
                }
            }
            $order_info['time_cancel'] = date('Y-m-d H:i:s', $order_info['time_cancel']);
            $order_info['time_create'] = date('Y-m-d H:i:s', $order_info['time_create']);;
            $order_info['time_paid'] = date('Y-m-d H:i:s', $order_info['time_paid']);;
            $order_info['time_finish'] = date('Y-m-d H:i:s', $order_info['time_finish']);;

            $order_info['verify_ok'] = $this->Config('ORDER_VERIFY_OK');
            $order_info['yetpay_online'] = $this->Config('ORDER_STATE_PAID');
            $order_info['yetpay_offline'] = $this->Config('ORDER_STATE_OFFLINEPAY');
            $order_info['lesson_list'] = $lesson_list;

            if($order_info['payment_string']){
                $payment_model = new PaymentModel();
                $pstring = $payment_model->getPaymentByString($order_info['payment_string']);
                $order_info['payment_string'] = $pstring['title'];
            }
            /*var_dump($order_info);*/

            $this->assign('data',$order_info);
            $this->display();
        } else {
            $this->error("没有找到订单");
        }
    }
    public function order_cancel()
    {
        $order_id = I('orderid', 0, "intval");
        $order_model = new OrderModel();
        /*检测当前状态*/
        $order_info =  $order_model->getOrder($order_id);
        $os = $order_model->getOrderOpt($order_info['state_order']);
        if (in_array("cancel", $os['opt']['ucenter'])) {
            $uid = session($this->config("SESSION_USER_ID"));
            $uname = session($this->config("SESSION_USER_NAME"));
            $res = $order_model->changeOrderStatus($order_id, $order_info['state_order'], 0, '', $this->Config('ORDER_LOG_USER'), $uid, $uname, "用户取消订单", "用户取消订单");
            if($res !== false){
                $this->success('取消订单成功');
            }
        } else {
            $this->error('无操作权限');
        }
    }

    /**
     * 订单评价[课程]
    */
    public function toEvalauteOrder(){
        /*分数标签*/
        if(IS_POST){
             $data = I('post.');
             if(empty($data['evaluate'])){
                 $this->error('未填写评价内容');
             }
             $evaluate_model = new EvaluateModel();
             /*查订单信息*/
             $order_model = new OrderModel();
             $order_info = $order_model->getOrder($data['order_id']);
             if(!$order_info){
                 $this->error('获取订单信息错误');
             } else {
                 $order_lesson_model = new OrderLessonModel();
                 $lesson_info = $order_lesson_model->getLessonArrayByOrderID($data['order_id']);
                 $prama['operator'] = $this->getUserId();
                 $prama['trainer_id'] = $order_info['trainer_id'];
                 $prama['user_id'] = $this->getUserId();
                 $prama['user_name'] = $this->getUserName();
                 $prama['user_avator'] = $this->getUserAvator();
                 $prama['order_id'] = $data['order_id'];

                 if($lesson_info && is_array($lesson_info)){
                     $lesson_id = '';
                     $lesson_name = array();
                     foreach ($lesson_info as $l => $l_list){
                         $lesson_id .= $l_list['lesson_id'].',';
                         $lesson_name[$l]['order_id'] = $l_list['order_id'];
                         $lesson_name[$l]['lesson_id'] = $l_list['id'];
                         $lesson_name[$l]['lesson_name'] = $l_list['title'];
                     }
                     $lesson_id = rtrim($lesson_id, ',');
                     $prama['lesson_id'] = $lesson_id;/*多门课程id，用逗号分隔*/
                     $prama['lesson_name'] = serialize($lesson_name);
                 }
                 $prama['score_trainer'] = $data['score_trainer'] > 0 ? $data['score_trainer']  :'0';
                 $prama['score_teacher'] = $data['score_teacher'] > 0 ? $data['score_teacher']  :'0';
                 $score_tags = array();
                 if($data['ev_tags'] && is_array($data['ev_tags'])){
                     foreach ($data['ev_tags'] as $s => $s_val){
                         $tag_info = $evaluate_model->getTagEvaluateByid($s_val);
                         $score_tags[$s]['id'] = $s_val;
                         $score_tags[$s]['title'] =  $tag_info['title'] ;
                     }
                 }
                 $prama['score_tags'] = serialize($score_tags);/*快速标签组*/
                 /*5分制：1分差评 2-4中评，5好评*//*1差评 3中评 5好评*/

                 $score_trainer = $data['score_trainer'] > 0 ? $data['score_trainer']  :'0';
                 $score_teacher = $data['score_teacher'] > 0 ? $data['score_teacher']  :'0';
                 if(floatval(($score_trainer + $score_teacher)/2) <= 1){
                     $evaluate_score = $this->Config('EVALUATE_BAD');//差评
                 }elseif (2 <= floatval(($score_trainer + $score_teacher)/2) && floatval(($score_trainer + $score_teacher)/2) <= 4){
                     $evaluate_score = $this->Config('EVALUATE_MIDDLE');//中评
                 }else{
                     $evaluate_score = $this->Config('EVALUATE_GOOD');//好评
                 }
                 $prama['evaluate_score'] = $evaluate_score;
                 $prama['evaluate'] = $data['evaluate'];
                 
                 $res = $evaluate_model->addEvaluate($prama);
                 if($res){
                     $this->success('评价成功！',U('User/Center/myEvaluationList',array('id'=>$this->getUserId(),'level'=>0)));
                 }else{
                     $this->error('评价失败！');
                 }
             }
        }else {
            $order_id = I('get.orderid');
            $type_id_jigou = $this->Config('EVALUATE_TAG_JIGOU');
            $type_id_laoshi = $this->Config('EVALUATE_TAG_LAOSHI');
            $data['order_id']  = $order_id;
            $data['type_id_jigou'] = $type_id_jigou;
            $data['type_id_laoshi'] = $type_id_laoshi;

            $this->assign('data',$data);
            $this->display();
        }
    }

    public function getEvalauteTag_json(){
        $score = I('post.score');
        $score_type = I('post.score_type');

        $data['score'] = $score;
        $data['type_id'] = $score_type;
        /*分数标签*/
        $evaluate_model = new EvaluateModel();
        $Tag_list = $evaluate_model->getTagEvaluateByscore($data);
        $json_array['lists'] = $Tag_list;
        echo   json_encode($json_array);
    }

    /**
     * 实时显示积分兑换钱
     *
     */
    public function getPointToMoney(){
        $point = I('post.point',0,'floatval');
        $uid = session($this->config("SESSION_USER_ID"));
        $user_model = new UserModel();
        $user_info = $user_model->getUserInfo($uid);
        if($user_info && is_array($user_info)){
            if($user_info['point'] >= $point){
                /*POINT_TO_MONEY*/
                $need_point = floatval($this->Config('POINT_TO_MONEY'));
                $tomoney = floatval($point / $need_point);
                $money =  round($tomoney, 2);
                $json_array['status'] = '200';
                $json_array['text'] = $money;
                echo json_encode($json_array);
            }else {
                $json_array['status'] = '300';
                $json_array['text'] = '已超出您的积分总额';
                echo json_encode($json_array);
            }
        }else {
            $json_array['status'] = '400';
            $json_array['text'] = '请退出重试';
            echo json_encode($json_array);
        }
    }

    public function swiftPayCallback(){
             

    }
    public function swiftPayNotify(){
        $swiftpay = new \Common\SwiftPay\Request();
        $json_return = $swiftpay->callback();
        $back_array  = json_decode($json_return,TRUE);
        if($back_array['status'] == 200){ /*返回结果success*/
            echo 'success';
        } else {
            echo 'fail';
        }
    }
}